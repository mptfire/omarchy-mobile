<!-- SPDX-License-Identifier: MIT -->
# Pixel 9a (tegu): first light

2026-10-22: verified on one retail Pixel 9a, Tensor G4 (`zumapro`).
This is an experimental integration, not a supported release or installer
qualification. Kernel, image-tool and package changes need separate PRs.
The descriptor here intentionally fails closed with current public tools.

Tested kernel: `7.3.0-rc6-omamobile-tegu-tn3-g1cb4bd36f3be-dirty`, private
branch `omamobile-tegu-touch-power`, worktree/output `wt-touch-power` /
`out-touch-power`. Diagnostic Images are additionally distinguished by
hash/build ID; this dirty release is not a published kernel package.
`[V]` marks verified observations; `[I]` marks an inference still to test.
Raw captures, recordings, backups and vendor files remain off repository.

## 2026-11-08: swap on zram

Kernel `7.3.0-rc6-omamobile-push1-ge8d722982099`, a local build, with the
zram options of `kernel/configs/omamobile.config` (set in the device's
`kernel.config` for the test). They build only modules, so `zram.ko` and
`zsmalloc.ko` went onto the running release with `bin/omamobile
modules-push`, without a new boot image. Omarchy 4.0.6 on the phone.

- [V] **Before:** no swap (`CONFIG_ZRAM` not set; Omarchy 4.0.6 ships no
  zram-generator on aarch64). A `cargo build` of squeekboard on the phone,
  next to Brave and the shell, left 177 MB available: memory PSI `full`
  about 50 %, load 13, the session stuttering and SSH timing out in the
  banner exchange. The OOM killer ended `rustc` (1.2 GB anonymous), and
  systemd stopped the app scope it ran in, the terminal with it.
- [V] **Setup**, as a newer Omarchy does it on aarch64 (Omarchy v4.5.0):
  `zram-generator` 1.2.1 from Arch, Omarchy's `90-omarchy.conf` (zstd,
  `swap-priority = 100`) and the `vm.*` lines of its
  `99-omarchy-sysctl.conf` (`swappiness=150`, `vfs_cache_pressure=50`,
  `page-cluster=0`, the watermark and dirty settings). zram-generator
  loads the module itself.
- [V] **`zram-size = ram / 2` (3.6 GB), 5 GB more allocated** on top of
  about 4 GB in use: no OOM kill, PSI `full` peaked at 32 % and fell below
  10 %, and SSH answered throughout. zram held 3.2 GB in 1.7 GB; the test
  data compresses about 2:1, ordinary app memory closer to 3:1.
- [V] **`zram-size = ram` (Omarchy's default, 7.3 GB), 6 GB more
  allocated:** the phone stopped answering, ping included, and came back
  after a restart about six minutes later. The journal has no oops or
  panic and no OOM kill for this run; its last lines are the CP's PCIe
  link going down and brcmfmac failing to allocate RX buffers. [I] RAM ran
  out before zram filled, and reclaim spun instead of killing. Not a
  like-for-like comparison (5 GB against 6 GB), so this says only that a
  RAM-sized zram is not a safe default here yet.
- [V] **Stock Android on the 9a** (BP3A.250905.014 vendor image):
  `vendor.zram.size=50p` selects `fstab.zram.50p` (`zramsize=50%`, plus a
  1 GB `zram_backingdev_size` writeback file for idle pages), started at
  `sys.boot_completed` by `init.zumapro.board.rc` with `page-cluster 0`;
  no swap partition.
- [V] **After the hang:** `tools/nv-backup -d tegu --check`: every NV
  partition the same. `omamobile-tegu-modem-boot` refused to start (its
  latch for a boot that didn't shut down cleanly), as designed; the modem
  came up ONLINE once the logs were read and the latch removed.
- **By hand, until the image ships it:** build with the options, install
  `zram-generator`, put `[zram0]` with `zram-size = ram / 2`,
  `compression-algorithm = zstd` and `swap-priority = 100` in
  `/etc/systemd/zram-generator.conf`, then `systemctl daemon-reload` and
  `systemctl start systemd-zram-setup@zram0.service`. `zramctl` and
  `swapon --show` show it. Resize only while it is empty: stopping the unit
  removes `/dev/zram0`, and `cat /sys/class/zram-control/hot_add` brings
  it back.

## 2026-11-07: the main camera's autofocus (LC898129)

Kernel `7.3.0-rc6-omamobile-push1-gd00d9fd2272f`, a local build: `omamobile`
with kernel #178, #103 and #164's camera device tree merged, the lc898129
driver ([kernel #213](https://github.com/derekross/linux-omarchy-mobile/pull/213)) and a lens node for it (below).

- [V] **The controller:** the main module's focus and OIS controller is an
  onsemi LC898129 at `0x24` on the main camera's bus (`hsi2c_5`, i2c-3),
  stock's `act-nessie` / `ois-nessie`. 16-bit register addresses, 32-bit
  big-endian values. It shares the sensor's supplies and reset and NACKs
  unless the sensor is powered (a read while the camera is stopped gives
  ENXIO or a timeout).
- [V] **Where the register map comes from:** no public datasheet or driver
  for the part. The register numbers and the form of a move came from
  disassembling the LC898129 actuator code in Google's camera HAL,
  `liblyric_hwl.so` in the `com.google.pixel.camera.hal` APEX on the vendor
  partition of factory image BP3A.250905.014: it reads `0xf010` and
  `0x0548` and writes `0xf01a` as `0x0002` in the upper half and the
  target in the lower. No code was copied. What the registers do, the
  usable range and the direction below were measured on the phone.
- [V] **What was written while working it out:** only `0xf01a`, always
  `0x0002` in the upper half, with lower halves from 0 to 32000 (those
  above 4095 are the tries with the upper bits set). Every other access
  was a register read (the two-byte address, then a 4-byte read):
  `0x0000`, `0xf010`, `0xf01a`, `0xf01f`, `0xe00d`, `0xf000`, `0xf001`,
  `0xf008`, `0xf00a`, `0xf100`, `0x0538` and `0x0548`. Finding the
  address took only read probes: `i2cdetect -r` on the bus and a read of
  `0x0000` at four other candidate addresses. The module's calibration
  EEPROM, which stock puts at the same address, was never written, and
  the driver writes only `0xf01a`.
- [V] **Its focus registers:** after power-up it reads `0xf010` = 7 (servo
  on) and `0xf01a` = `0x00000fff` (focus target). Writing `0x0002xxxx` to
  `0xf01a` moves the lens. The corrected Hall position at `0x0548` (upper
  16 bits, signed) is `0xc005 + 8 * (target & 0xfff)`: linear from -16379
  at 0 to 16381 at 4095, the same up and down. Targets with bits above the
  low 12 also changed the framing and sharpness in ways that don't follow
  the Hall position, so the driver never sets them.
- [V] **Direction:** sweeping 0-4095 with a can at about 25 cm, sharpness
  rose steadily towards 0 and fell towards 4095; the picture before the
  first write matched 4095. So 0 is the near end and 4095 the far end
  [I: the far end not yet checked on a distant scene].
- [V] **The driver:** `lc898129` ([kernel #213](https://github.com/derekross/linux-omarchy-mobile/pull/213)) is a V4L2 lens subdev,
  `V4L2_CID_FOCUS_ABSOLUTE` 0-4095 with higher values closer (it writes
  4095 minus the value). The `s5kgn1` driver powers it through
  `lens-focus` while streaming, as for the 7 Pro's SEM1215SA. The node:

  ```dts
  main_lens: lens@24 {
  	compatible = "onnn,lc898129";
  	reg = <0x24>;
  	vio-supply = <&cam_1v8>;
  };
  ```

  with `lens-focus = <&main_lens>;` in `cam_main`. It isn't in #164; it
  can go there or follow it.
- [V] **Autofocus in omacam:** the phone ran libcamera 0.7.2-4.22 with the
  `Af` lines added by hand to its S5KGN8 tuning file, the same lines
  0.7.2-4.23's 0057 adds. libcamera's contrast autofocus scans and settles
  on the can in a little over a second, and a full-size photo (3000x3992)
  is sharp on it.
- [V] **2026-11-08, the driver as reviewed** (supplies `vio`, `vm`,
  `vdda`; kernel `7.3.0-rc6-omamobile-push1-ge8d722982099`, `lc898129.c`
  blob `50cce3a5f4c0`, the kernel #213 head): while the main camera
  streams, `focus_absolute` 0, 1024, 2048, 3072, 4095, 2048, 0 settles at
  Hall 16371, 8179, -7, -8197, -16383, -4, 16369, and the lens is
  runtime-suspended after the stream. libcamera's autofocus (still
  4.22 with the lines by hand) sweeps 8 coarse steps over the range,
  then finely around the peak, and settles there.

## 2026-11-03: the radio backup check with tools/nv-backup

- [V] **NV partitions unchanged (`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`):**
  `tools/nv-backup -d tegu --check` against the 2026-10-28 read-only
  backup, after the day's reboots (several with the modem ONLINE through
  #372's boot unit, two sysrq reboots after dead-storage wakes, and two
  kernel pushes): `efs`, `efs_backup`, `modem_userdata`, `persist`,
  `modem_a`, `modem_b` and `metadata` read the same; `devinfo` differs, as
  it does after any boot-success mark or fastboot write.

## 2026-11-02, evening: calls, Phone and Messages, echo, a restart and MMS

All on the daily kernel (`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`)
with the modem started at boot by `omamobile-tegu-modem-boot` (#372).

- [V] **Calls and texts from the apps:** Phone and Messages through
  `omamobile-mmd` (#371) placed and answered calls with speakerphone audio
  both ways and sent and received texts. Messages showed "service isn't
  running" until the user's `omatel-agent` unit was started and enabled.
- [V] **Signal and the airplane icon:** the modem sends its signal reports
  only after it is told the screen is on, and radio state 10 means on;
  with both in `omamobile-modem-sit` 0.3.15 and the bridge 0.1.2, the bar
  shows signal and no airplane.
- [V] **A sitd restart in the same boot (#376), a deliberate test:** sitd's
  unit says a second start-up isn't supported, and this checked what
  happens. It failed at once on
  leftovers in `/run/omamobile-sit` (the LTE-only setting's saved original,
  then the bearer records), though the modem had dropped the bearers when
  sitd stopped. With 0.3.18 a restart gets data and signal back, but IMS
  doesn't register again (no registration indication after the PDN
  information is accepted), so calls and texts need a reboot after a
  restart. [I] The modem's IMS stack is never told the old session ended.
- [V] **Echo cancellation (#374, #378):** the owner's tuning files from
  the factory image upload with the AoC's status 0. The AoC's reply
  rewrites the second header byte (0x01 sent, 0x3e back), which the first
  check took for an unknown outcome, so that call was silent (fixed in
  0.3.19). With the tuning alone the far end still heard its own voice;
  with `Audio DSP Mode` set to `Telephony_APMG3` (0.3.20) it heard no echo
  for the first few seconds and a new low hiss, then the echo again with
  the hiss. [I] The echo reference or the order of the setup is wrong.
- [V] **MMS (#380):** with the carrier's MMS APN equal to its internet APN,
  setting up the separate MMS bearer (CID 3) took the IMS bearer down:
  afterwards the modem listed bearers 1 and 3, not 2. sitd held the
  reservation as uncertain, as designed, and a reboot cleared it. 0.3.22
  sends MMS over the internet bearer instead; not yet tried.
- [V] **Wi-Fi after a sleep with the keep flag:** in a boot with the
  modem's boot start disabled and the CP never started (checked before the
  sleep test), after the shell's auto-sleep with
  `/etc/omamobile/wifi-keep-across-sleep` in place,
  brcmfmac didn't attach to the chip again; a reload, a bind and a PCI
  remove and rescan all left no interface. A reboot brought it back.

## 2026-11-02: the SIM, the in-tree modem stack with GNSS, and a pruned module tree

Boots as before: test kernels pushed, checked, and the daily kernel pushed
back. Details are on each pull request.

- [V] **The SIM (omarchy-mobile #356, the daily kernel):** LTE
  registration, mobile data over `rmnet0` and texts both ways, after five
  data setups refused with status 36 and a wait after the data permission
  in `omamobile-modem-sit` 0.3.8. The record is in
  [MODEM-PLAN](MODEM-PLAN.md), "SIM test results".
- [V] **GNSS driver first boot (kernel #185, G1,
  `7.3.0-rc6-omamobile-push1-g30e9d94b4a91`):** `gnss_spi` and `gnssif`
  bound with the modem off, `/dev/gnss_ipc` appeared, no request
  interrupts, wakeup armed only while the device was open, and an unload
  and reload were clean. Then a 10-minute session on the daily kernel with
  #185's modules built for it: 538 of 556 GGA sentences fixed.
- [V] **The modem's two-lane PHY (kernel #186, bench, the modem off):**
  the first bench locked every PLL on one cycle and then hung the SoC at
  the next cycle's first ELBI write: power-off left the controller on the
  PHY's stopped clock. With the clock parked on the oscillator first, as
  stock does, five cycles over two boots locked every time
  (`7.3.0-rc6-omamobile-push1-g909c8c8121bb`, which also showed both HSI2
  GPIO bus clocks held on with kernel #172's second commit).
- [V] **The in-tree modem stack (kernel #187):** the gs201-cp host with
  zumapro's channel 0 through #186's PHY linked to the modem's ROM three
  times at Gen1 x1 (`7.3.0-rc6-omamobile-push1-g1b270b5cc447`); then, with
  a cpif fix for an uncached link without IO coherency, CPIF booted the CP
  to ONLINE and a 10-minute GNSS session through #185 gave 543 of 549 GGA
  fixed, 1343 link power cycles, no reset (`7.3.0-rc6-omamobile-push1-gbaf1b52d1de5`).
  The first try's cpif probe had failed ("PCIe IOCC config and dt are
  inconsistent").
- [V] **A pruned daily module tree:** after six test kernels in one day,
  the push back to the daily kernel replaced its module tree with the
  kit's archive, without the hand-installed `extra/` and `updates/`
  modules, and the next boot stopped at the boot logo (display driver
  missing). The cause: `omamobile-modules-cleanup` keeps the running tree,
  the next boot's and the two newest others, so during a test boot it
  removed the older daily tree; the push back then found no marker and
  sent the archive. Restored from the backup in `/var/lib/omamobile-tegu/`;
  on the palmtop the cleanup now keeps 50 trees (a local drop-in) until a
  pin for named releases ships. Until then, check `ls
  /usr/lib/modules/$(uname -r)/extra` after any push back to the daily
  kernel.
- [I] **A leftover bring-up unit:** `/etc/systemd/system/omamobile-tegu-audio.service`
  (2026-10-28, before `omamobile-device-tegu` took over its steps) now
  fails at every boot: its script loads NFC's module by hand after the
  package already has. The package's units bring up the same hardware, so
  it should go, as AGENTS.md asks for bring-up files a package replaces.

## 2026-11-01, afternoon and evening: Wi-Fi from the package, the wake and the replug, storage idle, the panel ID

Boots as in the next section (published-style kernels, pushed, checked,
the daily kernel pushed back), plus fixes on the daily kernel. Details
are on each pull request.

- [V] **Wi-Fi from the package (omarchy-mobile #238, kernel #178 on
  #156, `7.3.0-rc6-omamobile-push1-g5312a5be1ffe`):** with only
  `tools/extract-vendor-firmware`'s files, `omamobile-device-tegu`
  0.2.4's boot step loaded `phy_zuma_pcie`, `pcie_gs201` and brcmfmac,
  the link trained at Gen2 x1 on the first try, and wlan0 joined a
  network and passed traffic. An unbind and rebind of the host ran the
  soft power reset and the oscillator step, and the link trained again.
  With Bluetooth up, brcmfmac failed after the rebind ("FW failed to
  initialize"); with kernel #178's FLR commit
  (`7.3.0-rc6-omamobile-push1-gd60d217db5c6`) three rebinds with
  Bluetooth up all brought wlan0 back and left Bluetooth powered.
- [V] **The power-key wake (omarchy-mobile #268 and #275, the daily
  kernel):** one press lights the lock screen. sleepd now reads the 9a's
  `Power` interrupt as a power-key wake, and `user.slice` thaws 0.14 to
  0.24 s after the resume, against 1.1 s while the Wi-Fi hook waited for
  brcmfmac.
- [V] **A replug the gadget didn't see (omarchy-mobile #280, the daily
  kernel):** with the switch opened as the chip does on an unplug and
  the gadget still `configured`, the rescue closed it 9 s later and USB
  came back.
- [V] **Storage idle (kernel #99, `7.3.0-rc6-omamobile-push1-g5894c5287770`):**
  clock gating with the Hibern8 sequences, a cold read of 20000 files,
  30 fsync'd writes read back identical, and an s2idle and power-key wake
  with no UFS errors.
- [V] **The panel ID (kernel #125, `7.3.0-rc6-omamobile-push1-g88a7314c6409`):**
  `panel ID 04 80 00 2d`, then brightness, DPMS off and on, and 120 Hz
  to 60 Hz and back.
- [V] **The RTC without the PMIC interrupt (kernel #55,
  `7.3.0-rc6-omamobile-push1-gc04142279ef4`):** rtc0 set the clock at
  boot, and `hwclock -r` and `-w` worked.
- [V] **A day of use with auto-sleep on:** seven real-use sleeps all
  woke ([SLEEP-PLAN](SLEEP-PLAN.md), "A day of use with auto-sleep on").

## 2026-10-31 and 11-01: every testing row on a published-style kernel

Each line is a boot of the named head on the palmtop, built with
defconfig + `kernel/configs/omamobile.config` (plus #227's options) +
`olddefconfig`, pushed with `bin/omamobile push`, results collected, then
the daily integration kernel pushed back. Each row gives the release of
its boot (`uname -r`; the hash is the built tree's commit). Details are on
each pull request.

- [V] **Kernel config gaps (#227, `7.3.0-rc6-omamobile-push1-g5628f1888904` with all four built in).**
  A build from the fragment booted with no USB: the eUSB2 PHY and the ACPM, mailbox and S2MPG14 path its rails
  come through were modules, and the initramfs loads none. The fragment
  also lacked the MAX77779 fuel gauge and charger, the RT6160 camera
  regulator, the zumapro PCIe host (as a module) and the TAS2572 driver.
- [V] **Display and GPU (kernel #96, `7.3.0-rc6-omamobile-push1-g5628f1888904`):** DSI-1 connected at 1080x2424, a
  panthor render node, from the package's graphics start.
- [V] **Bluetooth (kernel #122, `7.3.0-rc6-omamobile-push1-g6ec07aeee91d`):** hci0 up, host wake 6 interrupts idle and
  38 after a 12 s scan.
- [V] **Charging (kernel #161, omarchy-mobile #230,
  `7.3.0-rc6-omamobile-push1-g7dbac6f4e65c`):** the charger binds at
  0x69, and the charge limit holds charging off at 80 % through
  `charge_behaviour`.
- [V] **AoC, speakers, microphone, sensors (kernel #162, omarchy-mobile
  #234, `7.3.0-rc6-omamobile-push1-g922812d75006`):** the AoC from the device tree at boot (93 services), the sound
  card, a tone heard from the speaker, the microphone at -32 dBFS, and the
  sensor proxy with five sensors.
- [V] **NFC (kernel #104 rework, #105, omarchy-mobile #235,
  `7.3.0-rc6-omamobile-push1-gb45a0d400e49`):** the clock pad
  from clk-exynos-clkout, `nfc0` polling with no I2C errors, neard and the
  link opener from the package. The pad variant's optional parent needed
  `of_property_match_string()` first: `of_clk_get_by_name()` returns -EINVAL,
  not -ENOENT, when a node has no `clock-names`.
- [V] **Cameras (kernel #164, `7.3.0-rc6-omamobile-push1-g4023f585ccae`):** all three stream (19 fps main, 30 fps
  ultrawide and front, 1280x960) once PMU 0x3ebc, the DC-PHY's isolation,
  is in the zuma PMU allowlist; without it every `phy_power_on()` failed
  with -EIO.
- [V] **Fingerprint (kernel #165, `7.3.0-rc6-omamobile-push1-gb533af3f1cbc`):** goodix-fp binds from the device tree
  (`/dev/goodix_fp`, irq on gpa7-6); matching was not run, since the
  service writes Trusty's secure storage.
- [V] **Wi-Fi (kernel #168, omarchy-mobile #238,
  `7.3.0-rc6-omamobile-push1-g07bdf006cdc2`):** the new zumapro PCIe
  channel-1 host plus #56's brcmfmac: the link, the BCM4383 at
  `14e4:4449`, `wlan0` connected at boot, a ping over it.

## 2026-10-31 and 11-01: leftovers on the palmtop from bring-up

- [V] **A plugin link in `~/.config/omarchy/plugins/` outranks the package.**
  `omamobile.quicksettings` pointed at a 10-17 hand copy (no notification
  shade) and `omamobile.switcher` at a 10-22 copy; four plugins were not
  linked at all. Relinked with `omamobile-setup-user`'s loop (AGENTS, #243).
- [V] **NetworkManager was masked in `/etc` and iwd ran Wi-Fi,** so the
  quick-settings Wi-Fi tile had no device. The switch, under a two-minute
  dead-man unit that would have masked NetworkManager and started iwd
  again: remove `/etc/systemd/system/NetworkManager.service` (the mask, a
  link to `/dev/null`), `systemctl daemon-reload`, `systemctl disable --now
  iwd`, `systemctl enable --now NetworkManager`, then `nmcli device` showed
  `wlan0` managed, and a fresh SSH login stopped the dead-man. The
  bring-up start script on the palmtop that used to start iwd now leaves
  Wi-Fi to NetworkManager when it is enabled.
- [V] **`omamobile-aoc`, `omamobile-sensor-proxy` and `omamobile-nfc-open`
  were masked in `/etc`;** the three masks are gone, recorded in
  `/root/bringup-backup/etc-masks/`.
- [V] **A fastboot flash of slot B's images clears slot B's successful
  flag** (#224): the evidence, and the `devinfo` write that marked B again,
  are in the next entry.

## 2026-10-31: a fastboot flash of slot B cleared its successful mark, and B was marked again

[V] Linux-omarchy-mobile #96's test kernel came up without USB (the config
gaps in #227), so the palmtop went to fastboot by the buttons and got the
daily images back. Before the flashes, `fastboot getvar` read
`current-slot: b`, `slot-successful:b: yes`, `slot-unbootable:b: no`,
`slot-retry-count:b: 2`. The five commands, suffixed, with no
`--set-active`:

```sh
fastboot -s <serial> flash boot_b boot.img
fastboot -s <serial> flash init_boot_b init_boot.img
fastboot -s <serial> flash vendor_boot_b vendor_boot.img
fastboot -s <serial> flash vendor_kernel_boot_b vendor_kernel_boot.img
fastboot -s <serial> flash dtbo_b dtbo.img
```

After them, `slot-successful:b: no` and `current-slot: b`. The retry count
wasn't read again in fastboot; on the boot that followed, `devinfo` read B
active, not successful, `retry-count` 2.

[V] B was then marked successful again, a `devinfo` write against the 9a
rule's hold, made under the 10-22 approval that the hold had replaced. The tool
was `omamobile-bootctl` (`packages/omamobile-device-cheetah/src/omamobile-bootctl.c`,
a static arm64 build with its source and binary hashes pinned in the
runner). The steps: the live 8192 bytes copied off the palmtop and
compared with the backup taken after the 10-28 stock boot (only the
bootloader-owned slot bytes and the record at 0x6d-0x70 differed); a dry
run that planned one byte, 0x35 `1c` to `1e` (B's successful bit); a
detached relock armed for 30 s; then `blockdev --setrw` on the disk and on
`devinfo`, the write, and an EXIT trap that set both read-only again. The
read-back matched the predicted image in all 8192 bytes, so 0x35 is the
only byte that changed, slot A's bytes are unchanged, and both read-only
flags read 1 afterwards. No other backup was taken first. Until the
maintainer decides how B is marked on the 9a, there are no more `devinfo`
writes: with B unmarked, reboots stay few and images are tried with `push`.

## 2026-10-30, evening: GNSS gets a fix

The receiver gets a position fix on the owner's kernel: up to 13 satellites
used, HDOP 0.8-1.2, GPS, Galileo, BeiDou and GLONASS tracked, CHPP clean
for about a minute per boot. One fix did it: spi-s3c64xx
turned the channels off after clearing the packet count, which lost a few
bits per transfer on a streaming slave (linux-omarchy-mobile#150). A pin
drive change (linux-omarchy-mobile#151) was credited too and withdrawn on 10-31: at the
bootloader's drive 0 with linux-omarchy-mobile#150 alone, 50 of 53 fixed and every frame at bit
offset 0 with a valid CRC. What ends the fix is
the CP link under GNSS traffic: held up it crashes the CP 103-108 s after
ONLINE (six boots of six), left to cycle it hung the SoC 170 s to about 26 minutes
after ONLINE. That hang was the PERIC0 GPIO bus clock gate (found
2026-11-01, linux-omarchy-mobile#172); with the gate kept on and the link
left to cycle, a 30-minute session through the Location switch ran clean. Details, the configuration and the sweep in
[MODEM-PLAN](MODEM-PLAN.md) "G3, GNSS gets a fix" and G3-L1.

## 2026-10-30: the hands-on morning (fingerprint, card, USB-C host, GNSS)

Release `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`, device
package 0.2.0, the first morning of hands-on tests on the package boot. Each
run had one thing in its way that the package boot no longer does by itself.

- **Fingerprint (kernel #126's panel module, one-minute repeat): pass.** The
  enrolled finger lit the circle and unlocked on the first press; three
  presses of a wrong finger were refused; the right one matched again. Two
  things had to be done by hand first: the sensor driver is not under
  `/lib/modules` for this release (`goodix-fp.ko` lives in
  `/var/lib/omamobile-tegu/`, loaded by `insmod`), and the stack has to be
  started as `omamobile-fp-chroot start bridge`, not `start storage`. A
  hand unit, `tegu-fp-stage.service` (insmod the driver, then the bridge
  stage, after the graphics start), does both at boot since the afternoon,
  so the lock screen takes a finger without a hand step; it is not in the
  repository, like the clock-pad unit below.
- **No circle after a tap wake.** The power key turned the screen off, a
  tap woke it to the PIN pad, and there the panel's backlight device still
  read `bl_power` 4; setting it back to 0 was not enough, because the
  backlight core's blank bit stayed set, `backlight_get_brightness()`
  returned 0, and `local_hbm_mode` refused with EPERM (the driver's
  allow_lhbm-and-brightness check). A DPMS off and on through Hyprland
  cleared it, and so did a later power-key press, which is the wake the
  shell handles fully. Cause and fix are in omamobile-shell
  <https://github.com/derekross/omarchy-mobile/pull/183>: a touch wake from
  s2idle got no `omamobile-keys wake`, so Hyprland never re-enabled the
  display; it now runs the same wake as the power key. The panel driver
  refusing LHBM in that state is the safe behaviour and stays.
- **NFC card read (kernel #131's modules): pass**, after two misses. The
  controller answered every NCI command and neard reported Powered and
  Polling (Mode stayed "Idle"), but no card was ever seen, because the NFC
  clock pad (PMU 0x3e84) was off on this boot: the hand script that set it
  at boot no longer runs on the package boot. `tegu-nfc-clkpad extpad=1`
  (0x00000000 to 0x00010000) and a rebind of the driver, and the very next
  60 s `nfctool -d nfc0 -p Initiator` poll found the card. The tool is
  `tegu-nfc-clkpad.ko`, a bring-up kernel module (source in the owner's
  logs, `logs/tegu-nfc-20261026/clkpad/tegu-nfc-clkpad.c`, not in the
  repository): it takes the kernel's SMC-backed PMU regmap
  (`exynos_get_pmu_regmap()`), does one `regmap_update_bits()` on 0x3e84
  (EXTPAD_EN | PAD_EN), reads the register back, and is removed again;
  never `/dev/mem`. A hand unit, `tegu-nfc-clkpad.service`, runs
  `insmod … extpad=1 && rmmod` after `systemd-modules-load.service` and
  before `sysinit.target`, and leaves a hang marker
  (`/var/lib/omamobile-tegu/clkpad-started`, written before the insmod and
  removed after; a boot that finds it skips the write and logs it). It
  stays until kernel #100's in-driver handling is on the palmtop. Rule of
  thumb: a controller that talks NCI but never sees a tag is the clock pad.
- **USB-C host (H2b, H4, H5): recorded in [USB-HOST-PLAN](USB-HOST-PLAN.md)**
  (pull request #178). H2b passed (the PMIC block probes with its interrupt, the boost's
  watchdog is serviced from it); H4 showed that unbinding the charger takes
  the Type-C port down with it as a device-link consumer (a WARN in
  `tcpm_port_unregister_pd`, VBUS to 0, the laptop link gone until the
  dead-man reboot); H5 ran with its Expect not met, within the stop window
  (the boost stays on across a reset, read at 3.13 s of the next boot, and
  drops by itself when the RT9470's watchdog expires; the reworked driver
  then takes it over).
- **GNSS G3-A (automatic chip select, feedback delay 0): same CHPP failure,
  clean checksums**, recorded in [MODEM-PLAN](MODEM-PLAN.md) (pull request
  #179). G3-A2 (stock's 32-bit words) is the one boot left on that trace.
- **Pushes from the run kit are refused by its own guard.** The kit's
  `omamobile.local.conf` puts a `deny-hardware` directory of stubs (ssh,
  fastboot, dd, ...) first on PATH, from the hands-free packing days; every
  push since reads "phone not reachable". Today's pushes went through the
  repository's own `bin/omamobile push` from a scratch checkout of main
  carrying the kit's `device.conf`. After H5's boot the push wrote and
  verified slot B but its reboot command never reached the palmtop: the USB
  link had dropped again and Wi-Fi was unreachable too while touch still
  worked; the owner rebooted from the menu and the new slot booted.
- **Sleep:** `tegu-mif-sleep.ko` loads at boot from a hand unit since last
  night; a cable-out `power-ab` run with it is in progress (result in
  [SLEEP-PLAN](SLEEP-PLAN.md) S1).
- **UFS did not come back from an s2idle, and the root went read-only
  (afternoon).** A forced 10-minute `systemctl suspend` woke on its alarm
  with `link startup failed 1` / `Host init failed 1` five times and
  `ufshcd_wl_resume failed: 1` in the console; every disk read then failed,
  ext4 went `emergency_ro`, and for an hour the palmtop answered SSH from
  memory while `systemctl suspend`/`reboot` did nothing and the power key
  could not light the screen. A sysrq `b` reset recovered it with a clean
  journal replay. A palmtop that seems never to wake may be exactly this.
  Record and rule in [SLEEP-PLAN](SLEEP-PLAN.md) S1 (#166).
- **The GPU ran at a fixed 160 MHz on the package boot.** `omamobile-tegu-graphics`
  gives panthor the one inherited CMU point; the 10-27 table's 150-890 MHz
  came from the hand `tegu-gpu-dvfs-activate` overlay module (adds stock's
  G3D levels to `/opp-table-gpu`), which the package boot no longer applied.
  Since this evening a hand unit, `tegu-gpu-dvfs.service`, applies it after
  the graphics start with `activate=1` and re-binds `1f000000.gpu` before
  the session starts (the module refuses to apply before panthor is bound;
  the first two tries at boot failed on that), and devfreq shows 14 steps,
  150 to 890 MHz, `simple_ondemand`. Kernel #85/#87 carry the proper form.
  `tegu-gpu-dvfs.service` leaves no hang marker (its ExecStart checks panthor
  is bound, inserts the activate module and rebinds `1f000000.gpu`), a known
  gap; the `gpu-thermal` zone's passive trip at 85 °C (critical 105 °C), with
  `devfreq-1f000000.gpu` as its cooling device, is what throttles the GPU at
  890 MHz on that boot.
- **The lock's fingerprint state got stuck after the afternoon's sleeps.**
  With the owner on the desktop, `omarchy-shell lock status` said
  `locked:true, sessionLocked:true, fingerprint:true`, the lock's PAM
  fingerprint verify ran in a loop every few seconds (fprintd always
  claimed, `fprintd-verify` refused with AlreadyInUse), and
  `omarchy-restart-shell` refused "while the session is locked". A fresh
  `omarchy-shell lock lock` and a PIN unlock put the state back. Separately,
  the lock shows no fingerprint marker over the sensor (only the PIN pad's
  small icon), so the owner aims blind; the circle lights only on a touch
  inside the sensor's 101 px radius at (540, 1756), which is why the
  morning's unlock worked once the circle had shown the spot and the
  afternoon's attempts saw no finger down at all.

## 2026-10-29: the device package boot, and what this row rests on

The palmtop's bring-up runs from `omamobile-device-tegu` 0.2.0
(<https://github.com/derekross/omarchy-mobile/pull/152>) since the 12:28
local boot on 2026-10-29, release
`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty` (the unpublished
integration tree; the board device tree is in review as linux-omarchy-mobile
#80), with the hand copies the package replaces moved aside under
`/var/lib/omamobile-tegu/before-pkg/`. `tools/phone-smoke` on that boot:
19 of 19 (boot on slot B, the storage guard with only `userdata` and slot
B's images writable, the ext4 root, no oops or WARN, no failed units, the
USB gadget, the panel at 1080x2424, a render node on panthor, Hyprland and
the shell, the lock, Synaptics touch, gpio-keys, wlan0 up, hci0 powered,
the gauge, the AoC sound card, three sensors, three cameras, hottest zone
44 °C). Packages on it: omamobile-device-tegu 0.2.0-1, omamobile-audio
0.4.1-1, omamobile-fingerprint 0.1.8-1, omamobile-apps 0.2.0-1, hyprland
0.56.2-5.1, mesa 1:26.2.4-1.4, libcamera 0.7.2-4.22.

What each cell of the DEVICES row rests on, beyond the 10-27 and 10-28
list below:

- **Boot:** slot B marked successful by hand on 2026-10-28 (the `devinfo`
  write approved on 2026-10-22, now on hold, #125); the package does not
  mark it. A fallback to slot A would cost the Linux root.
- **Started by the package at boot** (`omamobile-tegu-graphics.service`):
  the display at 120 Hz (the start sets `allow_tx` for `google-tg4c`, with
  or without the bootloader's panel-id suffix), the GPU, haptics, the torch,
  the gauge and Bluetooth; the USB rescue helper. Everything else in the
  row that says "by hand" is not.
- **GPU:** on this boot devfreq reports `simple_ondemand` with min, max and
  current all 159.7 MHz and `runtime_status` suspended, so the desktop
  renders and the GPU sleeps when idle, but frequency scaling is not
  active on the published form and counts as in review (kernel #85, #87).
- **Battery through UPower, 2026-10-29 evening:** energy-rate 1.06 W, time
  to empty 18.5 h at 87 %.
- **Sensors:** accelerometer, ambient light and proximity, as every smoke
  report of the day lists them. No gyroscope or compass has been seen on
  this palmtop; the row no longer claims them.
- **Wi-Fi across sleep:** kept loaded by the package's sleep hook
  (`/etc/omamobile/wifi-keep-across-sleep` is set) through the 2026-10-29
  S1 sleeps ([SLEEP-PLAN](SLEEP-PLAN.md) S1).
- **NFC:** a payment card read on the morning of 2026-10-29 with the
  kernel #131 modules (its thread has the dmesg lines); neard started by
  hand, polling stopped before sleep by the package's hook.
- **Suspend:** with the `omamobile-sleep` toggle on (it ships off), the
  shell's sleep daemon (`omamobile-sleepd`) suspends the palmtop once the
  screen is off and locked; the power key and the RTC wake it, but three test
  sleeps have not woken, so sleep tests stay attended (SLEEP-PLAN S1); the
  drain is the S1 figure.
- **Speakers:** the -10 dB ceiling recorded below, by hand with the AoC.
- **GNSS, 2026-10-30 evening:** a position fix on a bring-up kernel (the gn3
  tree with the spi-s3c64xx swap-mode change and the flush-order fix of
  linux-omarchy-mobile#137, the GNSS SPI's pins at function 2, mode 0,
  32-bit words, feedback delay 0, automatic chip select, 64-byte reads; that boot also
  raised the pins' drive to 3, which the 10-31 check at drive 0 showed was
  not needed, linux-omarchy-mobile#151 closed):
  in a 3-minute session by a window, 23 of 25 GGA sentences with fix quality
  1, up to 13 satellites used, HDOP 0.8, every CHPP read at bit 0 with a
  valid CRC; started by hand through the modem bring-up, not by a package.

## 2026-10-29: two resets at about 34 s, right after Bluetooth started

[V] During the night's GNSS G3 tries (kernel
`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`, gn3 DTB), two
boots reset at about 34 s of uptime, right after Bluetooth started (01:41
and 03:03), before any GNSS step. The cause was not seen. Read again from
the journal on 10-29 afternoon (the 03:03 boot; the 01:41 one is out of the
journal and its console was rotated out): its last 34 s are the same
timeline, to the tenth of a second, as the two boots around it that
survived (the Bluetooth firmware at 27.9 and 31.4 s, MGMT at 33.0,
`tegu-curated-bluetooth-prepare` at 34.1, `bluetooth.service` at 34.2,
`systemd-hostnamed` at 34.4, then nothing), and it ends there. The curated
Bluetooth dead-man is armed for 120 s, so it was not that; the audio
bring-up script had not yet acted (its first action comes 5-7 s later in
the surviving boots); the only thing running in that window is bluetoothd
setting the adapter up over the UART. Without the console of the reset
there is nothing more to read. The night's other
resets came from the modem side (the CP link hang after Kepler's watchdog
resets) and are in [MODEM-PLAN](MODEM-PLAN.md) under "G3, twenty-fourth to
thirty-fourth tries" and "The CP link hang". Not a GNSS matter: if a boot
with nothing but Bluetooth starting resets again at that time, start here.

## 2026-10-29: the s2idle drain is the SoC floor, not the CPUs or the radios

- Cable out, screen off: 311 mA awake, 302 mA asleep (two 30-minute
  `systemctl suspend` rounds through `power-ab --suspend systemd`). The CPUs
  sleep (timekeeping suspended for the whole of a 60 s test, one deep-state
  entry per CPU); Bluetooth, NFC and Wi-Fi cost nothing measurable at idle.
  What stays on is MIF, the buses and the always-on rails: there is no
  system idle state in our kernel. `tegu-mif-sleep.ko` (MIF 421 MHz in
  sleep) saves about 60-75 mA by the coulomb counter; a hand unit loaded it
  at boot for one night and was disabled the next day (below).
  Details and method in [SLEEP-PLAN](SLEEP-PLAN.md) S1.
- `rtcwake -m freeze` written straight to `/sys/power/state` failed to wake
  again (the second time in two days); every `systemctl suspend` after
  `rtcwake -m no` had woken up to then. The next day showed the entry
  path isn't the whole story (the 2026-10-30 bullet).
- 2026-10-30: the cable-out `power-ab --suspend systemd` run with the
  module loaded never woke from its 30-minute sleep (not from the RTC, not
  from the power key; reset by hand), so the hand unit that loaded the
  module at boot is disabled. The same day a cable-in 30-minute systemd
  sleep with the module, its alarm logged as armed, woke on the alarm to
  the second, and the afternoon's repeat of the cable-out run with the
  module loaded by hand woke too: 273 mA awake with the screen off, 260 mA
  asleep, about 40 mA under the figure without the module. Three sleeps
  have never woken (two direct freezes, one systemd sleep with the module)
  and no single factor explains them, so sleep tests stay attended and the
  module stays off at boot; the shell's auto-sleep toggle is off on the
  palmtop since the 2026-10-30 shell reinstall, and unattended sleep stays
  off until the hangs below are understood.
- The 2026-10-27 "140 mA asleep" figure doesn't hold up against 2026-10-28
  (434-445 mA cable out, as-is) and tonight; treat about 300 mA cable out
  as the baseline.

## 2026-10-28: the second 9a (the phone behind #74)

These results are from a second retail Pixel 9a, the one behind
<https://github.com/derekross/omarchy-mobile/pull/74>. They don't replace
the palmtop's results in the entries around this one.

**Slot A, as it stands:** stock `CP3A.261005.005` (Android 17, October
2026). All five live slot A boot images match the official October images
by hash. Selecting A and asking for recovery reached Android's `No command`
screen, recovery ADB and its shell answered (slot A, `CP3A.261005.005`),
and recovery went back to fastboot and B back to Omarchy with no image
written and no userdata reset. That verifies stock's recovery boot, not a
full Android boot: Arch holds `userdata`, so going back to Android means
resetting it, as with the installer. An earlier draft of this entry said A
"is not currently a qualified rollback"; that was before the recovery check
and no longer holds. Recovery for these trials also relied on retained,
checksum-verified slot B image sets.

**Fastboot is by the buttons on this phone:** with the phone off, hold
Volume Down, add Power, and keep both held about 20 s. Software
`reboot-to bootloader` came back to a normal boot of B instead.

### Prototype kernel, simple framebuffer

Kernel `7.3.0-rc6-omamobile-push1-g9ea0e19f8dc2`, from an unpublished
branch on public `omamobile` `33267e524` plus the clock and binding changes
then in review and prototype board, USB, UFS and touch changes. It is not
the tree in linux-omarchy-mobile #80 and #81.

`DEVICE=tegu bin/omamobile flash` wrote only `boot_b`, `init_boot_b`,
`vendor_boot_b`, `vendor_kernel_boot_b` and `dtbo_b`, selected B and
rebooted; a second trial used an initramfs without builder SSH keys. Both
reached Arch, Hyprland and the Omarchy shell on the existing `userdata`.
The display was ABL's simple framebuffer with a DECON trigger write, on
October 2026 headers; none of that is in the shared descriptor.

`tools/phone-smoke`: boot, storage guard (62 guarded partitions), ext4
root, kernel health, USB and session passed; display 1080x2424 and
Synaptics touch found. No GPU render node; Wi-Fi, Bluetooth, battery and
charging, audio, sensors and cameras absent or skipped.

The touch start marker: a normal reboot registered touch and cleared the
marker; a reboot with the marker kept on purpose left touch off and logged
the skip; `--retry`, with kmsg streamed to the laptop and the watchdog
armed, brought touch back and cleared it. A fresh SSH login worked
afterwards.

### Public base, oldest headers

The public board and touch base `9386dfaa1d5d` with this directory's
`kernel.config` boots as `7.3.0-rc6-omamobile-push1-g9386dfaa1d5d`. With
Android 16 / September 2025 headers and no AVB footers, B went back to
fastboot (`bootfailure`, `enter-reason` "boot failure"), with no log that
names the cause. The same payloads, byte for byte, with hash footers
(the image tool's AOSP test key, rollback index 0, OS version 16, security
patch 2025-09-05) booted Arch with USB and SSH. ACPM reported 16 usable
channels at 0.22 s; touch registered at 36.1 s. Smoke at 97 s: boot, all 62
storage guards, root, kernel health, USB, touch and buttons passed.

So this newer phone boots the oldest shared header values with
index-zero footers. That says nothing about footers on the palmtop, and the
shared descriptor is unchanged. This base had no display driver (Plymouth
failed, the Google logo stayed).

### Native display

Display tree `1175a53bf9b2` booted as
`7.3.0-rc6-omamobile-push1-gde2e0689c517`, same headers and footers, no
trigger write. The first boot found that Arch's `kernel-modules-hook`
cleanup, during the previous kernel's boot, had deleted the unowned modules
of the next kernel; the package's `linux-modules-cleanup` drop-in (carried
into 0.2.0) skips that cleanup. With the modules restored: `card0-DSI-1`,
Omarchy on camera, touch confirmed by hand. A later reboot kept all 1,782
modules, brought up the panel at 3.66 s at 1080x2424, 60 Hz (the cap this
branch's package set; 0.2.0 drops it), and the lock screen came back on
DPMS wake. Smoke at 223 s: boot, storage guard, root, kernel health, USB,
the session, touch and buttons passed.

Still open on this phone: Plymouth's splash crashes in `strcmp` with no
console; no GPU render node (this kernel has no GPU node); Wi-Fi,
Bluetooth, battery and charging, audio, sensors and cameras unqualified; no
clean install; B not marked successful. Stock A was never written.

## 2026-10-28, evening: USB-C host mode through TCPM

Kernel `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty` (the
integration tree), DTB with the TCPC as a dual-role port.

- **USB-C host mode works end to end** [V]. TCPM runs the port as dual-role
  (try sink, source PDO 5 V 900 mA), with `vbus-supply` = the MAX77779
  charger's `chgin-otg` regulator (kernel #124) over the RT9470's OTG boost,
  and a graph to dwc3's role switch. A USB flash drive attaches as source
  (SRC_READY), VBUS holds at 5.2 V, the data role goes to host, and the
  drive enumerates at high speed (`sde: sde1 sde2`). With the drive out and
  the laptop back: sink, a PD contract, the gadget configured. Again after a
  fresh boot. Two parts of that setup aren't in a public tree yet: the DT
  fragment (the TCPC as dual-role with `vbus-supply`, the graph to dwc3) and
  the RT9470 bring-up module that writes OTG_EN, JEITA_EN and the watchdog
  bits. They are on the kernel bring-up branch
  derekross/linux-omarchy-mobile#127, with the plan and runbook in #136.
  This supersedes #100's "the eUSB2 repeater doesn't take the host role
  yet".
- **How the cable swaps were covered** [V]: attended, with W4HO at the
  palmtop for every swap. Taking the laptop out cuts the only link, so each
  sampling script carried its own dead-man: with no USB gadget configured 6
  to 8 minutes after the cable came out, it unloaded `tcpci_maxim` and set
  the role switch back to device, so the laptop would come back as a sink.
  It never fired, because the laptop came back every time. The DTB boot
  itself ran under a one-boot DTB dead-man. The next run uses a reboot
  timer armed before the unplug and stopped over a fresh login (#136's
  runbook). `tools/usbc-deadman` is written for the 7 Pro's MAX77759 and
  doesn't apply here.
- **Why VBUS collapsed at first** [V]: the RT9470's JEITA temperature
  control (0x0c bit 7) was on with STAT2 reading 0x80, and its I2C
  watchdog (0x01 bits 1:0) had expired (STAT3 0x20). That JEITA read "hot"
  is an inference [I]: the TS pin may have no thermistor on it, which
  hasn't been checked. With either set, the
  boost reported OTG (ICSTAT 0x0f) while VBUS fell from 5.2 V within ~60 ms,
  and TCPM retried every second. Google's `rt9471_charger` turns JEITA off
  on the 9a (`en-jeita` is unset in `zumapro-buck-charge-rt9471.dtsi`) and
  only runs the watchdog while it kicks it. With both off, VBUS holds under
  Rd and Rp, with and without AutoDischargeDisconnect. The boost's driver
  has to clear both.
- **What that leaves open** [I]: with the watchdog off, nothing turns the
  boost off after a crash. What a warm reboot with host mode on leaves
  behind (the RT9470's OTG bit and ICSTAT before any driver loads) hasn't
  been measured, so whether VBUS stays out across one is unknown. With
  JEITA off the RT9470 has no temperature cut-off of its own, which
  matters only if it charges. Its CE comes from the MAX77779's sGPIO 7,
  which hasn't been read. On the charger with the battery full, FUNCTION
  read 0x41 (`CHG_EN` set) and ICSTAT 0xf1 (VBUS ready, not charging), so
  whether it charges under our kernel isn't known yet.
- **The eUSB2 side** [V]: the PHY has to come out of reset with the device
  attached. A drive plugged into a port that's already host isn't seen
  (the TUSB2E11's attach-detect interrupt never latched). TCPM's flow
  (attach on CC, then the role switch, then `phy-snps-eusb2` resetting the
  PHY on the role change) does it in that order.
- **NFC after s2idle** [V]: the ST54L loses its NCI state across a
  suspend. The first command after resume gets no I2C ACK (`NFC: Error -6
  on I2C send`), and every NCI request times out after it. Powering the
  adapter off and on through neard (a fresh NCI init) brings it back, so
  the sleep hook has to power the adapter off before the sleep and on
  after it, not only stop polling (10-29: not needed with
  https://github.com/derekross/linux-omarchy-mobile/pull/131, and a
  power-off hook failed to wake once; see #137).
- **Fingerprint calibration** [V]: the HAL injects it itself
  (`injectMtCali`), reading a 112-byte header at offset 0 of
  `/dev/block/by-name/mfg_data`. The file `fastboot oem udfps get-cal-url`
  names has exactly that layout (magic `0xca11ca11`, version 1, and the
  payload length at 0x6c). Written into the chroot's private `mfg_data.img`
  copy (the partition itself untouched), it's accepted:
  `vendor.gf.cali.state = 1`, and the "No SA calibration present" line is
  gone. Later that evening enrollment completed, but matching doesn't work
  yet (#135; 10-29: it does now, see FINGERPRINT-PLAN F9/F10 in #138).
- **GNSS** [V]: telling the AoC the GNSS type (`gnss-type = <2>`, as
  Google's `zumapro-phone-ignss.dtsi`) doesn't change the fault. Kepler
  loads and goes OPERATIONAL, and the HAL starts a session, but every engine
  start still ends in "KEP M7 HARDFAULT ... LR,PC 600B5B39 0000062C"
  (20 in 4 minutes).

## 2026-10-26 and 2026-10-28: slot A fallbacks that cost userdata

Both times slot B was active but **not marked successful**, so each boot
used up one ABL retry. After `fastboot --set-active=b` the 9a's ABL gives
B **three** tries (10-28: retry 3 after the flash, 1 after two boots, from
the devinfo dumps below). A boot that never reaches the USB host is crashed
by the initramfs safety net about 65 s in, so a bad image uses up the tries
within minutes, and ABL then boots stock on slot A.

**2026-10-26.** The failing boot was a comparison run of Google's own
kernel (`6.1.134-android14-11-g2bae8aca899a-ab13800907`), written to slot B
by `omamobile flash` (so `--set-active=b`). It ran with a RAM-only
filesystem assembled from our initramfs files, with PID 1 replaced by a
static supervisor that opens no block device. Stock's own first stage didn't
run on slot B. It never brought up USB.
Fastboot (buttons) then showed A selected and B at retry 0. Stock's own
boot wasn't captured. Afterwards `userdata`'s ext4 and F2FS magics were
gone, with non-zero data in their place, `e2fsck -fn` failed, and `persist`
had changed. [I] Stock on slot A wrote over the start of `userdata`; nobody
saw its boot. At 16:35 MST the palmtop sat in stock recovery (USB 18d1:4ee7,
sideload-only adbd: every adb command answered `error: closed`). Nobody
chose anything in recovery. A fresh read-only backup of efs, efs_backup,
modem_userdata, persist, modem_a/b, devinfo and metadata was taken
(off-repo). Slot B came back by `omamobile flash` of the last good five
images (which set it active again). The root came back by streaming the
verified 10-25 recovery image over USB SSH into `userdata` from our
initramfs, with a readback hash and a read-only `e2fsck`. B was then on its
last try (byte 0x34 `00` in the "before" row below): one more unmarked
reboot would have fallen back again.

**2026-10-28.** Kernel `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`
(the release the day's run kit records; the string stays the same across
that tree's builds, so it names the tree, not one build) with our initramfs
(`bin/omamobile initramfs`, `initramfs/init`, packed by the kit), and a new
DTB (the TCPC as a dual-role port with a link to dwc3's role switch). In the morning, slot B was
written by `omamobile flash`, recovering from a test boot of kernel #55's
head that hung on the Google logo, and it was **not marked** afterwards.
Every `push` round after that ran unmarked, so the tries ran out on the
first round that failed. That's the situation the rule is there to prevent. The DTB round lost USB on its boot (`push`: "no SSH after
reboot"), and a few minutes later the palmtop was on stock. adb answered
`error: closed` again, the same sideload-only adbd as 10-26. The owner
doesn't remember what the screen showed, and nobody tapped anything.
Afterwards `userdata` read as non-zero data with no filesystem magic (the
first 64 KiB looks random), and the root wouldn't mount. Fastboot by the
buttons, `omamobile flash` of the last good images, the 10-25 recovery
image streamed to `userdata` and read back against its sha256, then a boot.
Fresh read-only backup of the same eight partitions, taken before the boot:
efs, efs_backup, modem_userdata, persist, devinfo and metadata differed
from the 10-26 backup, modem_a/b didn't. `fastboot getvar slot-*` wasn't
captured either day, apart from `current-slot: a` on 10-28.

So stock doesn't just stop at a recovery prompt: on both days `userdata`
was overwritten before anyone could choose anything. Treat a fallback to
slot A as losing the Linux root.

**Marking B both days** was the approved operation below, `omamobile-bootctl
mark-successful` for B. The binary was built statically from
`packages/omamobile-device-cheetah/src/omamobile-bootctl.c` (source sha256
`89d03460…`, binary `f44936d5…`), driven by a laptop script that:

1. reads a fresh full `devinfo` snapshot and checks its sha256 against live
   storage right before the write;
2. runs the tool's dry run, which must plan exactly one byte;
3. arms a 30 s timed read-only restore, writes, reads back all 8192 bytes
   against the predicted image, and checks the read-only flags over a fresh
   SSH login.

systemd's 10 s runtime watchdog was running throughout (the bring-up checks
for it). The script didn't arm anything beyond that.

The laptop keeps the command log. The 10-28 harness copy differed from the
10-26 one only in its baseline paths (slot A's bytes are read live).

| Moment | Bytes 0x30–0x37 |
| --- | --- |
| 10-26, before | `02 1a 00 00 00 14 00 00` |
| 10-26, after | `02 1a 00 00 00 16 00 00` |
| 10-28, before | `02 1a 00 00 01 14 00 00` |
| 10-28, after | `02 1a 00 00 01 16 00 00` |

Only byte 0x35 changed (bit 0x02), and slot A was untouched.

## 2026-10-28: what the device table's claims rest on

Each line is a run on this 9a, on `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`
unless it says otherwise; the kernel pull request has the details.

- **Display:** the published kernel drives the panel at 60 Hz. 120 Hz runs
  on the palmtop with kernel #88's two files (DECON timers per panel), in
  review.
- **Touch, sleep fix (kernel #82):** 20 s2idle cycles with RTC wakes in a
  row, no `bad message header`, touch working after each; without it touch
  broke at the 13th.
- **Buttons, Power wakes s2idle:** checked by hand on 2026-10-27, Power from
  a freeze back to the desktop.
- **Bluetooth, BCM4383 (kernel #94, merged):** `hci_uart` reloaded with that
  exact `hci_bcm.c`: the controller came up as `hci0` on its REG_ON latch.
  Pairing (A2DP) ran with the older form of the code.
- **Charging, status and inhibit (kernel #92):** the driver bound at 0x69;
  status, and inhibit through `charge_behaviour`, read and set on the
  palmtop.
- **Haptics, CS40L26 with VPBR (kernel #95, merged):** binds, loads its
  firmware with brownout prevention at 3.008 V, plays effects.
- **Torch, LM3644 (DT in kernel #96):** 25 brightness steps up to 75 mA on
  the torch LED.
- **Suspend, Power and RTC wakes:** Power by hand as above; RTC wakes in the
  #82 run and in the 2026-10-28 sleep tests, where one of four never woke
  (recorded in the camera switching entry below).

## 2026-10-28: camera switching, pstore, idle hints, sleep memory rate

Kernel `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`.

- **Camera switching works** (kernel #103). The first capture after a
  switch away from the ultrawide or front camera came back empty about
  half the time. The LoCH's EN_STATUS (0x0a8) stays active with the old
  link in its low bits after a stream that stopped cleanly, and a disabled
  LoCH ignores the abort, so the next stream on another link got no
  interrupts. Enabling it for the abort fixes it: nine captures, every
  switch order, all write frames.
- **pstore** (kernel #106): ramoops on stock's region survives a watchdog
  reset on zumapro (the bootloader writes its own log at the start of the
  console zone).
- **Core and cluster power-down hints** (the CPU_INFORM register Google's
  driver writes at every idle entry): powering down cluster 0 stops ACPM
  answering its DVFS channel, and the palmtop resets (pstore shows it);
  Google never powers down cluster 0. Clusters 1 and 2 are stable, but
  neither hint saves anything measurable, screen on or off. Dropped.
- **Memory rate in s2idle:** with the cable in and charging paused,
  10-minute RTC-woken freezes drew 371 and 373 mA at MIF 2028 MHz and
  314 mA at 421 MHz. One later freeze never woke (in s2idle the watchdog
  is stopped); a hand restart brings it back.
- **Link errors** on every camera are ERR_WRONG_CONFIG: packets on VC 0
  with a data type no channel takes (an embedded-data line a frame on the
  front and ultrawide, about 527 PDAF packets a frame on the main camera).
- **Fingerprint:** the trusted app's secure storage is up, with Trusty's
  stores at the paths stock uses (`0`, `persist/0`) but on loop devices of
  Linux-owned images under `/var/lib/omamobile-fp`, not on stock's
  `trusty_userdata` and `trusty_persist` (omarchy-mobile #101;
  FINGERPRINT-PLAN D1 and F4b). The factory
  calibration lives with Google: the bootloader names the file (its
  `get-cal-url` answer) and it comes from a manufacturing bucket. The panel's
  id isn't the key (omarchy-mobile #101).
- **GNSS:** the S2MPG15's three GNSS rails are off at hand-off and stock
  turns them on; they're now described (kernel #101) and on.

### Reserved memory beyond Google's map (kernel #80)

`zumapro-reserved-memory.dtsi` in #80 carries Google's fixed regions from
`zumapro-rmem.dtsi`, zuma's xhci pools, and three more:

- `abl@f8800000`: predeclared in stock's own factory base DTB as 32 MiB,
  which ABL shrinks to 16 MiB at hand-off.
- `0x913a0000` (+0x60000) and `0xfd7ff000` (+0x1000): two ranges the early
  bring-up kept reserved, next to GXP and the debug tail. They come from the
  private DRAM map the first boots were built from, not from a public
  source.

Keeping them reserved is the safe direction. What would free the two gaps
is stock's live `/proc/iomem` and reserved-memory nodes compared with ours;
this palmtop can't produce that (stock on slot A overwrites `userdata`
before it reaches recovery: [2026-10-26 and 2026-10-28](#2026-10-26-and-2026-10-28-slot-a-fallbacks-that-cost-userdata)),
so it needs a second 9a or a reinstall of stock.

## 2026-10-27: cameras, NFC, USB-C, storage power, fingerprint, drain

Kernel `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty` (the
integration tree; the pieces are kernel PRs, linked below) for everything
here. The 35 s2idle cycles in AGENTS.md's NFC entry ran on this release too.

**Cameras (kernel #63, #103).** `cam -l`:

    1: Internal back camera (/base/soc/usi@108c00c0/i2c@108c0000/camera@56)
    2: Internal back camera (/base/soc/usi@108900c0/i2c@10890000/camera@1a)
    3: Internal front camera (/base/soc/usi@108a00c0/i2c@108a0000/camera@1a)

`tools/phone-smoke`: `| cameras | ok | 3 listed by libcamera |`. With the
ultrawide's test pattern on, LoCH 0 on link 1 (CTL 0x01000200, RESOL
0x0c001070, 5312 bytes a line, format 4) wrote three 4208x3072 frames
(48955392 bytes) showing the sensor's eight colour bars, full width and
height; the solid-colour pattern (R 1023, Gr 0, B 341, Gb 682) reads back as
BGGR. The main camera (S5KGN8, C-PHY) delivers whole 4000x3000 frames once
gs201-csis raises the INT domain and the ISP front end's NOC clock while it
streams. The ultrawide and the front stream at about 29 fps through the
software ISP. The tested `phy-gs201-mipi-dcphy-rx.c` is #63's (ed3dacc7f958);
the tested `gs201-csis.c` (acd8d7d0987a) differs from #63's in one comment.
Open: the first capture after a camera switch is often empty.

**NFC (kernel #100).** The ST54L reads a contactless card through the
kernel and neard once nxp-nci sends ST's CORE_SET_CONFIG after init: an
ISO-DEP target on NFC-A, 15 activations in 45 s with the card held, neard
lists a tag, with no periodic discovery restart. NFC polling costs about
60 mA, so omamobile-shell 0.2.33 (PR #99 here) stops it with the screen off.

**USB-C.** tcpci_maxim (merged, kernel #97) loads at boot: a PD contract at
5 V 3 A, replug back within 1 s. Host mode: VBUS comes from the RT9470 on
USI10 (Google's ext-otg-only use case; USI10 clocks in kernel #102), the
TCPC sees VBUS, dwc3 goes host, but a flash drive never connects: the
eUSB2 repeater (hsi2c9 0x3e) doesn't take the host role yet. Plug-in wakes
s2idle once the TCPC's interrupt is armed.

**Storage power (kernel #99).** UFS idle clock gating: the cores spend
60-68 % of an idle minute in C2 with the core's latency request left on
(0 % with the clocks held on), no UFS errors under load.

**Fingerprint.** The sensor's 3.3 V is S2MPG15 LDO15S, off at hand-off
(kernel #101); with it on the trusted app finds the sensor and the HAL
reports it at (540, 1769), radius 113. Init still ends without factory
calibration: `mfg_data` is all zeros on this palmtop and the TA's
calibration objects don't open (FINGERPRINT-PLAN.md).

**Drain, cable out.** Awake with the screen off: 556 mA before UFS gating,
409 mA after it at MIF 2028 MHz and 366 mA at 421 MHz (ACPM lowers MIF on
request); NFC polling about 60 mA of that; Wi-Fi off and the CPUs at their
lowest changed little. s2idle: about 140 mA over 59 min. MIF stays at the
bootloader's 2028 MHz until something asks for less.

**Recovery.** A reboot stuck in `device_shutdown` needs Power held about
30 s, then Power; with a task stuck in D, reboot with `echo b >
/proc/sysrq-trigger` instead of `systemctl reboot`.

## 2026-10-26: audio (speakers, microphones, A2DP) with omamobile-audio 0.5.0

Kernel `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`: the private
integration tree for now (the pieces go to linux-omarchy-mobile one by one;
the S2MPG14 RTC is #54), with the AoC started by a staged script. The card
is `google,tegu-aoc-snd-card`; the TAS2572 amplifiers (I2C 19, top 0x48 and
bottom 0x49) take their gains from `tas2572RCA1.bin` at every playback
start (corrected 10-29: that file is linux-firmware's
`ti/audio/tas257x/tas2572-1-1amp-reg.bin`, byte for byte; stock's factory
image carries no RCA-format profile, only its own `ti_sp_tuning.bin`), and the codec exposes only `Top/Bottom Speaker Digital Volume` = 220
(0 dB; 232 is +6 dB), unchanged during a 1 kHz tone at 100 % PipeWire volume.
Without stock's speaker processing or protection in the path, PipeWire's
100 % is full scale into stock's amplifier gains, so the WirePlumber rule caps
the 9a's speaker sink at `channelmix.max-volume = 0.562` (a -10 dB ceiling, a
cautious number, not a measured one) until the speakers' limits are measured
or a protection path exists. PipeWire applies the clamp twice, to the master
volume and to each channel volume, and the channel mixer multiplies the two,
so the ceiling is the square of the value: the first cut of this rule used
0.316 and measured about 20 dB down, not 10. Checked on the phone: with the
sink at 100 % (`wpctl set-volume @DEFAULT_AUDIO_SINK@ 100%`) `pw-dump` still
reports `channelVolumes [1.0, 1.0]` (the cap is applied inside the channel
mixer, not to the reported volume), and a 440 Hz tone at -20 dBFS played at
100 % and recorded through the 9a's own microphone measured -43.6 dBFS RMS
at 0.316 and -24.0 dBFS with the line removed and WirePlumber restarted
(19.6 dB apart through an uncalibrated microphone path); at 0.562 it measures
-33.3 dBFS RMS, 9.7 dB below uncapped. The Pixel 7 Pro's speaker loudness filter is active
on the 9a too (`effect_input.omamobile_speaker_loudness` in front of
`alsa_output.platform-sound-aoc.HiFi__Speaker__sink`); it adds a bass boost
tuned for amplifiers with protection behind them, so it should be limited to
the Pixel 7 Pro's card.

Tested on the phone: speakers through PipeWire (a 2 s 440 Hz sine at -20 dBFS
played with `pw-play --volume 0.2`, then a 1 kHz tone at 100 % for the
amplifier readback, then system sounds; the owner heard them), both
microphones recording (EP1, `0,1,-1,-1`), Bluetooth A2DP endpoints registered.
The tested package was omamobile-audio 0.4.1 with this branch's four files
copied in by hand (remove them before installing 0.5.0, since pacman does not
overwrite files it does not own): `/usr/share/alsa/ucm2/conf.d/aoc-snd-card/`
`aoc-snd-card.conf` (b7bf918a…) and `google,tegu-aoc-snd-card.conf`
(b6033775…), `/usr/share/alsa/ucm2/Google/tegu/HiFi.conf` (a6d460f3…) and
`/usr/share/wireplumber/wireplumber.conf.d/52-omamobile-tegu-aoc.conf`
(a8b4e025…, sha256 prefixes of the committed files; the speaker and microphone
tests above ran before the cap existed, and the cap's own measurement came after). The AoC's own log for the third
microphone: `Could not enable power for PDM 2`, no fault. Cheetah's list
`0,3,2` kills the DSP: `FF1 (task=AUD_CAP_PDM): Assertion failed: asp_status
== ASP_SUCCESS, mic_compensation.cc, 99 [SetPdmMask]`, after which the AoC
needs a reboot (restarting the proxy does not help).

`tools/phone-smoke`, 2026-10-26T16:42Z:

### phone-smoke: tegu

Kernel `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`, tools at `7310611`, 2026-10-26T16:43Z.

| Check | Result | Detail |
| --- | --- | --- |
| boot (required) | skip | kernel 7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty, no slot on the command line |
| storage guard (required) | ok | 62 partitions; only userdata and slot B's boot images writable |
| root (required) | ok | ext4 on userdata, 22G free |
| kernel health (required) | ok | no oops or BUG; 0 WARN, 307 error lines in dmesg |
| systemd units | ok | none failed |
| USB gadget (required) | ok | bound to 11210000.usb |
| display | ok | card1-DSI-1 connected, 1080x2424 |
| GPU | ok | render node on panthor |
| session (required) | ok | Hyprland and the Omarchy shell running |
| touch | ok | Synaptics TouchComm Touchscreen |
| buttons | ok | gpio-keys |
| Wi-Fi | ok | wlan0 on brcmfmac, link up |
| Bluetooth | ok | hci0, powered true |
| battery | ok | 92% Unknown |
| sound cards | ok | googleteguaocsn |
| sensors | ok | Accelerometer AmbientLight Proximity |
| cameras | skip | no libcamera tools |
| thermal | ok | hottest zone 46 °C |

Packages: hyprland 0.56.2-5.1, libcamera 0.7.2-4.16, mesa 1:26.2.4-1.4, omacam 0.1.9-1, omamobile-apps 0.2.0-1, omamobile-audio 0.4.1-1, omamobile-device-tegu 0.1.0-1, omamobile-fingerprint 0.1.8-1, omamobile-firstboot 0.1.0-1, omamobile-gnss 0.2.1-1, omamobile-keyring 20261013-1, omamobile-mirror 0.1.1-1, omamobile-modem 0.1.4-1, omamobile-omarchy 0.1.4-1, omamobile-owl-widgets 0.1.1-1, omamobile-sensors 0.2.0-1, omamobile-shell 0.2.17-1, omarchy 4.0.6-1, quickshell 0.3.2.r7.g2b4501a-1

## 2026-10-25: display scale 8/3

On the reference 9a (`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`, 1080x2424 panel at
60 Hz), the owner compared the bring-up's scale 2 (540x1212 logical) with
8/3 (405x909) on the running desktop, side by side with an iPhone, and kept
8/3: "about right", about a third larger than 2. Hyprland reported no config
errors, and running apps fit. 3 (360x808) is the Pixel 7 Pro's default and
too small here. omamobile-shell 0.2.35 makes 8/3 the scale a new 9a user
gets (`omamobile-setup-user`, seeded once), so it's the default for every
new 9a install, not only this one; a user's own scale is kept.

## 2026-10-24: local curated candidate

[V] A later candidate, `7.3.0-rc6-omamobile-tegu-g7e457a96fc45`, reaches
native Arch on internal userdata and starts Panthor, the G715 Omarchy
session and the read-only fuel gauge locally. The laptop sends nothing
during the boot (no go-ahead, no driver load, no confirmation): the palmtop
finishes the recorded startup on its own.
Matching modules, storage guard, watchdog and protected-partition/image
checks pass. Physical gestures and unplugged cold boot were not requalified
by this test. The staged startup policy remains; this is not an installable public
kernel or device-package release.

[V] The same Image with board source `79288b2a3574` also registers the
ALIVE GPIO provider and native gpio-keys while preserving inherited pulls.
Input keycodes, IRQ ownership and shell bindings pass metadata/state checks;
physical presses, display wake and suspend remain unqualified. A later
boot removes both temporary reboot helpers, the out-of-tree modules
`tegu-reboot-probe` (writes the bootloader reason at PMU 0x810 through the
kernel's SMC-backed PMU regmap) and `tegu-reboot-normal` (its normal-mode
counterpart, a reboot notifier only), both in `device/tegu/probes/`.
Ordinary `systemctl reboot` with no reason returns to the native desktop
automatically; an explicit bootloader reboot reaches Fastboot, and flashing
the same five slot B images back (`bin/omamobile flash`: `boot_b`,
`init_boot_b`, `vendor_boot_b`, `vendor_kernel_boot_b`, `dtbo_b`, each
hash-checked against the candidate set) returns to the same native profile.
Fresh root, protected-data and image checks pass after each. That kernel
(`7e457a96fc45`) predates kernel #45's merge, and I did not record whether
its reboot-mode code matches #45, so the plain `systemctl reboot` result is
not evidence for #45. Unplugged cold boot and production packaging remain
open; these results do not qualify those gates.

The selected subsystem source and disabled board resources are being
curated for separate kernel reviews in [tracking #28](https://github.com/derekross/omarchy-mobile/issues/28).
Public main still lacks the complete board integration and install recipe.
Do not enable the staged descriptor or infer Wi-Fi, charging/thermal,
Bluetooth, haptics, sensors, audio, cameras or fingerprint support from this
local desktop result. Earlier prototype observations below remain attributed
to their original diagnostic kernel.

## 2026-10-24: read-only gauge review, temperature deferred

[V] Kernel PR38 driver blob `1e113081a07f0fc629842b31e3fb86b4f7c4fcdf`
(`drivers/power/supply/max77779_battery.c`) excludes TEMP reporting.
Google's GPL driver substitutes 22 C for firmware revision 1 with
subrevision below 15; this gate does not establish the
retail gauge firmware revision or a stock-temperature comparison.

The exact signed C source is compiled as an ARM64 W=1 module against the
running curated `7.3.0-rc6-omamobile-tegu-g7e457a96fc45` kernel. It uses
that integration's qualified USI6/HSI2C6 bus, not an installable public
kernel. The unchanged board node is:

```dts
fuel-gauge@36 {
    compatible = "maxim,max77779-fg";
    reg = <0x36>;
    shunt-resistor-micro-ohms = <2000>;
    status = "okay";
};
```

[V] Load by hand, read twice 31.11 seconds apart, unload and restore the
installed module all pass on one boot. Both snapshots report present,
Li-ion, MAX77779, status Unknown, 93%, voltage/average 4.340390 V, charge
4720 mAh, full 5045 mAh and design 5120 mAh. TEMP is absent. Relevant
kernel lines, excluding the laptop log nonce:

```text
[  442.171460] max77779_battery: loading out-of-tree module taints kernel.
[  442.174098] max77779-battery 0-0036: Read-only fuel gauge; firmware model retained
[  473.361184] tegu-gauge-clean-review: two read-only snapshots complete; unloading test module
[  473.419985] max77779-battery 0-0036: Read-only fuel gauge; firmware model retained
[  473.432595] tegu-gauge-clean-review: installed gauge restored
```

[V] Laptop kmsg, PID1 hardware watchdog and independent recovery cover the
test. Fresh root/guard, six protected checksums and five B payloads pass;
both recovery timers are canceled and confirmed inactive on a fresh login.
An earlier attempt also read and restored the module, but host cleanup
failed on a collected timer, leaving the emergency reset armed. It fired
(the controller's 150 s reset timer; it came back on slot B, the only
slot with the native desktop, on the same five images);
the owner confirmed the recovered desktop and full checks passed before
this clean repeat. This was a test-controller failure, not a demonstrated
gauge fault. No model, NVM, charging, current-direction, rail or voltage
setting is written. The original driver remains installed; production
package migration, thermal control and suspend remain separate.

## Sources and firmware gate

- `R0/`: private retail capture `tegu-20261020-1349`, before unlocking:
  selected `getprop` fields and `fastboot-getvar-all.txt`, 2026-10-20.
- `R1/`: guarded native Linux partition enumeration and off-repository
  protected backups, `tegu-protected-20261021T021535Z`.
- `R2/`: 2026-10-22 guarded read-only AVB and slot-A image reads;
  `avbtool` signature checks and comparison with the verified official OTA.
- `F/`: the user's stock `tegu-bp3a.250905.014` factory boot images,
  including `dtbo.img`; facts below are offline parses, not installed-build
  attestations. The later bring-up bundle is a different artifact.
- `G/`: Google's GPL manifest branch
  [`android-gs-tegu-6.1-android16`](https://android.googlesource.com/kernel/manifest/+/refs/heads/android-gs-tegu-6.1-android16),
  manifest revision `893fbfd2192bc1c4a921f5daf23ea8543c09670d`.
- `P/`: the prototype's private kernel, guarded captures and per-gate
  results; the kernel release is above. No raw captures or binaries ship here.

### Slot history and official OTA maintenance

| Slot | Observed bootloader | Stock Android build evidence | Evidence |
| --- | --- | --- | --- |
| A | `tegu-16.3-13642544` | `BP3A.250905.014` (Android 16, patch 2025-09-05) | R0/getprop: `_a`, `ro.bootloader`, `ro.build.id` |
| B | `tegu-16.0-13541477` | `BP2A.250805.005`, patch 2025-08-05, in signed AVB metadata; no successful stock-B boot attestation | P/ resident-B fastboot controls; R2/vbmeta_b and vbmeta_system_b |

[V] The numeric loader build identifiers are 13642544 and 13541477.
A factory archive or the firmware suffix does not establish B's Android
build ID. R2 instead identifies it from valid signatures on vbmeta_b and
vbmeta_system_b, whose keys match the official stock images. This verifies
those metadata declarations, not our modified B boot images, dynamic
snapshot contents or a successful stock-B boot. The slot mismatch should have stopped bring-up under
CONTRIBUTING §3.1. The prototype result does not waive that rule or show
that a zumapro-specific HCRX workaround is needed.

[V] On 2026-10-22 the official full OTA for `BP3A.250905.014` was
sideloaded through stock recovery twice; both passes completed with status
0. After the first pass the resident B loader reported
`tegu-16.3-13642544`; after the second, resident A reported the same
version. Stock A then booted successfully. Ordinary authorised ADB
confirmed `_a`, `BP3A.250905.014`, Android 16, patch `2025-09-05`,
`tegu-16.3-13642544` and `dtbo_idx=9`. This is not a stock-B boot
attestation. Live DT selector reads were unavailable without rooting;
artifact-derived selectors remain distinct from observed silicon.

[V] Guarded post-OTA readback verifies valid top-level and system AVB
signatures on both slots, flags 0, and declared image prefixes exactly
matching the official BP3A images. Fresh protected backups were taken
before peripheral startup. The first ordinary installed-B control boot
reached internal Arch/systemd root with normal HCRX initialization, KVM
enabled and CPU0-7 online, without a laptop RAM boot. A bounded real ARM64
KVM guest executed and trapped the expected virtual MMIO write of 42;
no host-device passthrough was used. Native guard and watchdog checks
passed, with no runtime kernel fault detected. Control GNU build ID:
`bd787a42658c58ed023e7bb6c203d46844e294b9` (same diagnostic release string).

This control needs no HCRX workaround. The earlier failure is specific to
the mismatched-firmware prototype evidence; it does not justify a
zumapro-wide kernel workaround. Two normal control boots have passed;
cold starts and desktop/peripheral requalification remain separate gates.
[BRINGUP-M1](BRINGUP-M1.md) records those gates; the workaround is not
proposed for upstream.

### Sanitised stock facts

[V] R0/getvar: `product:tegu`, `hw-revision:MP1.0`,
`secure-boot:PRODUCTION`, `current-slot:a`,
`version-bootloader:tegu-16.3-13642544`. This was a **pre-unlock** snapshot:
`unlocked:no`; both slots reported successful with retry count 2, A
unbootable=no and B unbootable=yes. These are historical values, not the
prototype's current flags. A single resident-loader version is not proof
of equal firmware on both slots.

[V] Each slot has `boot`, `vendor_boot`, `vendor_kernel_boot` at 64 MiB,
`init_boot` at 8 MiB and `dtbo` at 16 MiB; `devinfo` is 8192 bytes
(R0/getvar). R1 enumerates 62 named partitions across four LUNs, sda–sdd:

- Five slotted boot images: `boot`, `init_boot`, `vendor_boot`,
  `vendor_kernel_boot`, `dtbo`.
- Other slotted names: `bl1`, `ldfw`, `dpm`, `gcf`, `pbl`, `bl2`,
  `dram_train`, `abl`, `bl31`, `tzsw`, `gsa`, `gsa_bl1`, `vbmeta`,
  `vbmeta_system`, `vbmeta_vendor`, `pvmfw`, `modem`.
- Unslotted: `persist`, `metadata`, `fips`, `ufs_internal`, `klog`,
  `misc`, `super`, `userdata`, `frp`, `efs`, `efs_backup`,
  `modem_userdata`, `trusty_persist`, `trusty_userdata`, `devinfo`,
  `pinfo`, `blenv`, `mfg_data`.

Only the five B boot images and userdata are writable under the guard;
listing a partition here grants no write permission.

[V] F/dtbo has **10 entries**. Retail Android reported `dtbo_idx=9`
(R0/getprop); entry 9 has board ID `0x60b06`, revision `0x10000`.
The stock vendor-kernel boot base-DTB candidates carry these
`/soc_compatible` tuples (product_id, major, minor, pkg_mode):

| Base DTB | Candidates |
| --- | --- |
| 0, A0 FOPLP | `(0x9875, 0, 0, 0)` |
| 1, A0 IPOP | `(0x9875, 0, 0, 1)` |
| 2, A0/A1 FOPLP | `(0x9875, 0, 0, 0)`, `(0x9875, 0, 1, 0)` |
| 3, A0/A1 IPOP | `(0x9875, 0, 0, 1)`, `(0x9875, 0, 1, 1)` |

The prototype's IPOP pair matches base 3. This does not distinguish this
unit's A0 versus A1 silicon, nor replace an equalised-stock live-DT capture.
The descriptor keeps that pair **commented out**, using #27's syntax:
`a0-ipop:0x9875:0:0:1 a1-ipop:0x9875:0:1:1`. This device PR supplies
selector data only. Shared SOC_COMPATIBLE tooling and its images-layout
tests remain in the separate tooling PR, alongside zuma's requirements.
Both SOC_IDS and SOC_COMPATIBLE stay unset, so this descriptor remains
refused even when #27 accepts either selector. Activation belongs with the
public DTB and required AVB footer values in a later PR.

**Header values verified:** the descriptor uses OS_VERSION=16.0.0 and
OS_PATCH_LEVEL=2025-09 from this stock build’s init_boot header.
The full OTA for BP3A.250905.014 (matching captured A) is downloaded and
matches Google's published SHA-256. All five F/ stock boot-image sizes and
digests match its payload manifest. AOSP unpack_bootimg parses that stock
init_boot as Android 16.0.0 / patch 2025-09. These are verified candidate
header values, now backed by both OTA completions, both-slot signed AVB
metadata for BP3A and the successful stock-A build-property check. A
stock-B Android boot is not claimed.

## Verified before firmware equalisation (old B, HCRX bypass, KVM off)

| Area | Observation [V] |
| --- | --- |
| Boot | Ordinary installed B boot and subsequent phone-initiated Linux-to-Linux reboot; no laptop kernel download, module load, storage-enable approval token (the bring-up script called it `GO`) or root confirmation. Tests kept USB connected. |
| Root and CPUs | Arch on internal ext4 userdata, systemd/SDDM/UWSM/logind, CPU0-7 online. KVM disabled. |
| Protection | Whole main-LUN node absent; only five B boot partitions and userdata writable; protected partitions read-only; per-boot guard and watchdog checks pass. |
| USB | NCM, ACM and root SSH over the connected cable. |
| Display | Bootloader framebuffer through simpledrm, 1080x2424, then scale 2 (first light). Scale 8/3 since 2026-10-25, see that entry. Reported 60 Hz is not an independently measured panel rate. |
| Touch | Synaptics S3908 TouchComm v1: taps, long press, launcher, quick settings and all four swipe directions physically exercised by the owner. |
| GPU | Mali-G715 MC7: Panthor initialization, system Mesa GLES3.1 color readback, actual Hyprland/shell GPU rendering and automatic startup after local reboot. |

[V] Touch/GPU startup uses local prototype policy with matching pinned
modules, hang markers and timed recovery. No public tegu release package
provides it yet. The matrix remains **WIP** until the kernel and prerequisites are public.

[V] Horizontal swipes remain clunky and the clock card briefly shows a
jagged tail. Native display KMS, brightness, DPMS and GPU DVFS are not
qualified. Shader/top rates inherited from firmware are approximately
150/160 MHz, derived from qualified clock registers. A separate small
quick-settings first-frame flash was removed by selecting its screen
before showing the window, confirmed in recordings and physical swipes.

[V] Moving G4 UFS clock-stop register programming before host-clock disable
resolved a shutdown stall. The retained trace now completes both callbacks
and reaches `Restarting system`. An ordinary reboot without the extra
logging returns the native root/touch/GPU desktop: USB disconnects in
3.7 seconds and Linux USB returns in 28.9, versus 85/111 before the fix.
The prototype still has a 45-second storage qualification delay. Cold
power-on, unplug/replug, buttons, battery/charging/thermal policy, suspend
and the other phone peripherals are not qualified.

### Exact private restoration path

The post-OTA restore used a private checkout at
`/tmp/tegu-maintenance-tools`, based on this repository's main plus the
proposed #27 selector support and the previously qualified development
`flash` function. This was not the unchanged public `bin/omamobile`.
The command was `bin/omamobile flash --no-reboot --rootfs <verified-image>
--rootfs-sha256 <verified-sha256>`, with DEVICE=tegu and the pinned image
output selected. The regular ext4 image was 32 GiB, labelled
`omamobile-root`, reconstructed from the verified Linux file backup with
matching modules and checked ownership, ACLs, xattrs and special files.
It was flashed to shared `userdata`; no Android partition was mounted
read-write and no main-LUN device was recreated.

The retained flash log names exactly `boot_b`, `init_boot_b`,
`vendor_boot_b`, `vendor_kernel_boot_b`, `dtbo_b`, plus `userdata`.
The private flash function did **not** pass an explicit `-s <serial>`;
it relied on the connected-device/product check. I cannot confirm serial
binding for those historical writes. Future Fastboot operations will use
an explicit serial selection. No additional flash is needed to correct
this record. Slot selection and boot were separately performed by ABL's
Fastboot commands, not by a devinfo set-active write.

## Bring-up findings and descriptor facts

- [V] Initial malformed embedded AVB metadata failed before handoff.
  Stock-style child boot metadata passed an offline six-image load check;
  that repair alone did not resolve the older-firmware entry failure.
- [V] Entry recorders localized the older B firmware's failure to
  HCRX_EL2 access. Omitting that access permitted full Linux with all eight
  CPUs and KVM disabled. [I] Missing permission in the older firmware is
  the leading explanation; EL3's control register was not read. The
  completed equalised-firmware control passes normal HCRX and a real KVM
  guest, so the old bypass is not proposed for kernel review.
- [V] Both touch rails were off at handoff. The qualified ACPM/S2MPG14
  path, LDO4M/LDO25M and AVDD-before-VDD sequencing enabled v1 identification
  and the existing S3908 driver; this did not need a v2 protocol port.
- [V] G715 startup needed Google's GPL ASN/L2 hash values through Panthor's
  existing SoC-data mechanism (source below), plus the full upstream Mesa architecture 11
  backports. Tested system Mesa: `1:26.2.4-1.4`. No GPU protection-permission
  change was used.
- [V] Prototype container metadata: Android v4, five boot images,
  2048-byte vendor page size. Android 16 / 2025-09 are historical bring-up
  bundle header values only, not descriptor evidence. Retail
  MP1.0 board dtbo entry 9 selects ID `0x60b06`, revision `0x10000`.
  These are board values, not per-phone IDs.
- [V] Base-DTB selection uses soc_compatible, not the public packer's
  soc_id rewrite path. SOC_IDS is deliberately absent. The shared init is
  retained; no gs201 display probe or trigger write is requested.

The unit began with different slot firmware versions. Recorded prototype
image writes targeted B; no stock-firmware update or downgrade is recorded
in those tests. This does not establish that A was factory-identical.

[V] Before the OTA, R2 found A's vbmeta flags at 3, versus factory 0. In the declared
factory image prefix, only byte 123 differs. That captured header signature
did not verify as-is; resetting that byte in an **offline copy** exactly
matches the official factory image. No such change was written to the
phone during this audit; the history of the flag change is not established.
At that audit, all five actual A boot images separately matched the official BP3A OTA's
stock images. A's vbmeta_system signature was valid and its declared image
matched the official OTA. The two subsequent official OTA passes restored
flags 0 on both slots; the post-OTA signature/build checks are recorded
above. This does not imply the custom B images are verified by stock AVB.

An earlier private bring-up note from 2026-10-20 records that
`fastboot oem disable-verity` and `fastboot oem disable-verification`
returned OKAY after unlocking. This is a historical note, not a retained
before/after vbmeta comparison; it does not establish which command
changed A's header flags. It must not be omitted from the account of the
earlier verification changes. No such command is part of this maintenance.

This observation does not override CONTRIBUTING section 3.1: another
mismatched unit must stop for maintainer guidance before flashing.
Protected backups were kept off repository and checked against live
read-only partitions.

### devinfo write disclosure and stop

[V] `omamobile-bootctl` **wrote devinfo** to mark slot B successful.
Its `dump` reported layout version **3.15**. A fresh full 8192-byte backup
was checked before the write; host simulation and live readback verified
that byte `0x35` alone changed by setting B's successful bit (`OR 0x02`).
The full 8192-byte comparison verified slot A and every other byte unchanged;
devinfo was restored read-only and the storage guard checked over a fresh
SSH connection. The generic boot-success service remains masked.
After that earlier write, `fastboot getvar slot-successful:b` returned
`yes`: ABL read the same successful bit the marker had set. The retained
Fastboot captures confirm this independently of the Linux parser.
This was evidence of the bounded operation; further writes were held
while the maintainer reviewed the paired layout evidence below. On
2026-10-22 the maintainer agreed **mark-successful for B only**, after a
fresh backup and checksum immediately before the write. No set-active
or other devinfo write is agreed. Keep the generic service masked.

### Read-only layout evidence after official OTA maintenance

[V] Layout remains 3.15. Guarded Linux dumps followed by graceful returns
to Fastboot give these matching requested ABL observations, without an
intervening marking, slot selection or flash:

| Record | Bytes 0x30–0x37 | A successful / unbootable / retry | B successful / unbootable / retry |
| --- | --- | --- | --- |
| First normal B boot | `02 1a 00 00 02 14 00 00` | yes / no / 2 | no / no / 2 |
| One further normal B boot | `02 1a 00 00 01 1c 00 00` | yes / no / 2 | no / no / 1 |

The intervening boot used ordinary fastboot reboot, with no set-active or
retry refresh. Byte 0x34 decreased by one; successful/unbootable stayed
clear for B. This was not the only change: 0x35 XOR 0x08 matches the parser's
fastboot_ok field, and two opaque header offsets also changed. Their
values remain private and uninterpreted. No direct devinfo write was made.
The two pairs and these additional changes were posted to the maintainer
for layout agreement. The maintainer subsequently confirmed the retry
and fastboot_ok decoding and approved only B mark-successful, subject to
the fresh backup and before/after checks described above.

### Approved B-success operation after layout review, 2026-10-22

The maintainer approved only `omamobile-bootctl mark-successful` for B in
[review 5622088453](https://github.com/derekross/omarchy-mobile/pull/24#pullrequestreview-5622088453).
A further ordinary B boot used explicit Fastboot serial selection and no
slot reselection, flash or retry refresh. On the guarded native root, a
fresh full devinfo backup was saved privately and its checksum matched
live storage immediately before the write. The unchanged existing tool
performed the operation under a proven laptop log, watchdog and timed
read-only restoration.

| Moment | Layout | Bytes 0x30–0x37 |
| --- | --- | --- |
| Fresh backup immediately before mark-successful | 3.15 | `02 1a 00 00 00 1c 00 00` |
| Immediately after mark-successful | 3.15 | `02 1a 00 00 00 1e 00 00` |

All 8192 bytes were compared: only byte 0x35 changed, setting bit 0x02;
slot A and every other byte stayed unchanged. The devinfo partition and
its parent were temporarily writable for that tool operation, then
restored read-only; all original sibling read-only flags and the storage
guard passed a fresh SSH check. The generic boot-success service remains
masked. No set-active or other devinfo write was performed.

After graceful return to Fastboot, explicit serial-bound
`fastboot getvar slot-successful:b` returned **yes** and
`slot-unbootable:b` returned **no**. A remained successful and bootable.
This confirms ABL reads the same successful bit the marker writes.

### GPL source of the G715 cache-hash data

[V] G/ [`kernel/devices/google/zuma`, revision
`42395e8adcb880aa336f0da6bb2a19ed53929c40`, dts/zuma-gpu.dtsi](https://android.googlesource.com/kernel/devices/google/zuma/+/42395e8adcb880aa336f0da6bb2a19ed53929c40/dts/zuma-gpu.dtsi)
supplies `l2-hash-values = <0x0036db6d 0x005b6db6 0>`.
[`kernel/devices/google/zumapro`, revision
`8831630eee2ad095b85ed452944e6353940966a5`, dts/zumapro-gpu.dtsi](https://android.googlesource.com/kernel/devices/google/zumapro/+/8831630eee2ad095b85ed452944e6353940966a5/dts/zumapro-gpu.dtsi)
includes that zuma GPU description. Both are from branch
`android-gs-tegu-6.1-android16`. The same manifest's
[`kernel/google-modules/gpu`, revision
`696fc0246c17ba4270c11f88ab742ad4040938de`](https://android.googlesource.com/kernel/google-modules/gpu/+/696fc0246c17ba4270c11f88ab742ad4040938de/)
contains the GPL kbase property reader and L2 programming sequence.
The separate Panthor submission should cite these immutable sources;
no vendor binaries or GPU-permission changes belong in it.

## Meaning of the bring-up terms

**Qualified** means one named gate passed its stated checks on the tested
prototype/kernel; it does not mean release support, independent replication
or that unrelated peripherals work. **GO** was a temporary script's explicit
operator approval token before enabling storage; it is not required for
ordinary installed boot and is not a waiver of the safety model.

## Submission gates and follow-ups

[V] Offline: images/initramfs/flash/push each refuse the descriptor for
missing SOC_IDS before mocked hardware tools are called or images written.
The empty overlay passes strict checkpatch and dtc, its ID/revision read
back correctly, and applying it leaves a synthetic base unchanged.
These are low-risk checks with no phone rollback; stop if tooling proceeds.

Next: kernel drivers/bindings/DTS in linux-omarchy-mobile, one subsystem per
branch, with strict checkpatch, W=1 and binding/DT validation; generic DTB
selection/packing and a qualified device package here. Each hardware gate
needs protected backups, fresh logs, watchdog/dead-man recovery, a stop
condition and a known-good B rollback. Preserve stock A and the storage
guard. This entry is not an installation or diagnostic-flashing runbook.

The gated retest and required evidence are in [BRINGUP-M1](BRINGUP-M1.md).
