<!-- SPDX-License-Identifier: MIT -->
# Pixel 9a modem and GNSS plan (tegu, Samsung S5300)

Status (2026-10-27): M0.1, M0.4 and M2.2 passed; FAR_ALIVE (GPA5, the
modem's cp2ap lines) is bound with its EINTs in the base DT
(FAR-ALIVE-PLAN FA1, FA2). M2.0-M2.4 passed: the modem powers up,
trains Gen1 x1 and enumerates as 144d:a5a5; M3-M5 passed: CPIF and cbd
boot it to **ONLINE** (Gen3 x2) with working IPC (pktproc), no SIM yet;
G1-G2 passed: gnssd loads Kepler's firmware and talks CHPP over SPI;
**G3: a position fix on the owner's kernel (2026-10-30, evening).**
The CHPP link lost bits because spi-s3c64xx's flush cleared the packet
count before turning the channels off
(derekross/linux-omarchy-mobile#150). That fix alone does it: a pin drive
change (linux-omarchy-mobile#151) was credited at first and withdrawn on 10-31, see cause 2.
Fixed (2026-11-01): the SoC hang under GNSS traffic. The CP link powers
down and up about twice a second, as on stock, and cpif writes the AP2CP
lines on PERIC0 each time; the PERIC0 GPIO bus clock was a manual gate
that the pin controller switched off after every access, and that hung the
SoC within minutes. Kept on
(<https://github.com/derekross/linux-omarchy-mobile/pull/172>), five
sessions ran with no reset, the longest 30 minutes and 3759 link cycles
(G3-L1).
**The SIM (2026-11-02): registered on LTE, mobile data up, texts both
ways** on the owner's kernel, with `omamobile-modem-sit` 0.3.8 (its first
five data requests were refused with status 36 until the RIL let the
modem settle after the data permission; "SIM test results" below).
Left: the GNSS and CPIF drivers aren't in the published kernel, GNSS and
the modem still start by hand, and calls have no audio route.
The staged plan (sections F, K, U and runbooks M0.2-M6, G1-G4) is below,
with each step's results under it. Kernel branches `omamobile-tegu-modem` and `omamobile-tegu-gnssif`
(section K).

**The modem is an S5300, not an S5400** [V]: tegu builds Google's
`radio/samsung/s5300` CPIF (`devices/google/tegu/BUILD.bazel:62,108`,
`tegu_defconfig:4-16`), stock's `cpif` node says `mif,name = "s5300"`, the
vendor image's firmware is `g5300t-*` and cbd runs as `s5100sit`. "S5400"
appears only in the name of the GNSS include stock uses
(`zuma-cp-s5400-phone-gnss.dtsi`) and in a comment on AoC's `gnss-type`.
So the cheetah CPIF port (same S5300 driver) carries over almost unchanged.

The 9a's GNSS is the modem's own: stock's `cp_shmem` carries a
`GNSS_FW` region and its `gnssif` (`samsung,exynos-gnss`) talks to the modem
over SPI (`gnss@0`, `samsung,gnss-spi`, interrupt on gpa5-4). So GNSS needs
the modem up, but not a SIM. Following Derek's advice on issue #51, the
modem comes up for GNSS first, and the SIM (a prepaid physical one on a
T-Mobile-network MVNO) comes later. It is activated in another phone or
through the carrier's web activation, with its PIN turned off there, then
put in the 9a with the 9a off. Not on slot A: stock there overwrites
`userdata` before it reaches recovery ([NOTES, 2026-10-26 and 2026-10-28](NOTES.md#2026-10-26-and-2026-10-28-slot-a-fallbacks-that-cost-userdata)), so booting it loses the Linux
root. The backup check and a
fresh read-only backup before the first Linux modem session stay as below.

## Safety

As cheetah's MODEM-PLAN: Linux never writes the modem's NV (`efs`,
`efs_backup`, `modem_userdata`, `persist`); the chroot works on
checksum-verified RAM copies. The NV overlay of `omamobile-modem` 0.1.15
(cheetah MODEM-PLAN, "NV overlay": the modem's own writes to
`nv_normal.bin`, kept on userdata) runs the same profile here, off until
`/etc/omamobile/modem-nv-overlay-enable` exists; it hasn't run on the 9a. Check the partitions against the off-repo
backup before every modem session, and take a fresh read-only backup after
any stock Android boot (stock's modem stack writes them).

## M0.1, partitions against the backup (2026-10-27, passed)

Backup: `~/android/reference/tegu-protected-post-recovery-20261026T185656Z/`
(off-repo). On the palmtop, each partition found by `PARTNAME` in
`/sys/class/block/*/uevent`, read with `sha256sum` only:

| Partition | Matches the backup | Read-only | Mounted |
| --- | --- | --- | --- |
| efs | yes | ro=1 | no |
| efs_backup | yes | ro=1 | no |
| modem_userdata | yes | ro=1 | no |
| persist | yes | ro=1 | no |
| modem_a | yes | ro=1 | no |
| modem_b | yes (same as modem_a) | ro=1 | no |

---

Path abbreviations below:

- `G/` = Google's GPL zumapro kernel on omb, `~/tegu/kernel/private`
- `CP/` = `G/google-modules/radio/samsung/s5300` (tegu's CPIF, `CPIF-20220408R1`)
- `PC/` = `G/google-modules/soc/gs/drivers/pci/controller/dwc` (`pcie-exynos-gs.ko` +
  `pcie-exynos-zuma-rc-cal.ko`, `G/devices/google/zumapro/BUILD.bazel:132-133`)
- `GN/` = `G/google-modules/soc/gs/drivers/soc/google/gnssif_spi` (`gnss_spi.ko`, `gnssif.ko`)
- `D9/` = stock board overlay 9 (`~/android/reference/tegu-vendor-a-20261026/dtbo_a-9.dts`,
  "TEGU MP", board_id 0x60b06 rev 0x10000: the owner's board, AUDIO-PLAN)
- `T/` = our tegu tree on omb, `~/tegu/int-dt-20261026/kernel` (`991042e2e`)
- `L/` = our cheetah modem port, in `omamobile-int` (`~/android/mainline/linux`)
- `V/` = the owner-equivalent factory vendor image (cp3a.261005.005), read on
  omb with `debugfs` only; never committed

[V] = read in source, stock DT or our captures. [I] = inferred; each [I]
names the step that settles it.

## F. Facts the steps rely on

### F1. The modem link: PCIe channel 0 (HSI1 GEN3A_0)

Not the Wi-Fi channel. Wi-Fi is channel 1 (HSI2, `0x13120000`, PMU `0x3ec8`,
one lane), working through `probes/tegu-pcie1.c` (NOTES: wlan0 link up).

| Item | Value | Source |
| --- | --- | --- |
| Controller | `pcie@12100000`, `ip-ver` 0x987500, `ch-num` 0, max Gen3 | [V] `G/devices/google/zumapro/dts/zumapro-pcie.dtsi:11-58` |
| Regions | elbi 0x12100000+0x2000, soc 0x12110000+0x5000, udbg 0x12130000+0xd000, phy 0x12140000+0x3000, sysreg 0x12020000+0x2000, dbi 0x12400000+0x381000, pcs 0x12120000+0x5000, config 0x40ffe000+0x2000, ia 0x12170000+0x1000 | [V] same |
| Interrupts | SPI 414 (controller), 416-420 (MSI 0-4); 415 doorbell, 421 PCS unused | [V] `IRQ_PCIE_GEN3_2L_*_HSI1` in Google's `dt-bindings/interrupt-controller/zumapro.h` |
| Window | CPU 0x40000000, 0xff0000 bytes = PCI 0x14e00000 (board ranges); CPIF's doorbell `pci_db_addr` 0x14e60000 | [V] `zumapro-board-pcie-cp-s5300.dtsi`, D9/ `cpif` |
| Board | `num-lanes` 2, `use-sysmmu` true, `use-cache-coherency`, `use-msi`, `use-l1ss`, `perst-delay-us` 18000, `ep-device-type` 4 (modem) | [V] same file, D9/ fragment@61 |
| Pins | PERST# gph0-0 (output), CLKREQ gph0-1 (function 2, pull-up, drive X4); both power-down "previous" | [V] `zumapro-pinctrl.dtsi:840-854` |
| PMU | PHY control `0x3ec4` (bit 0 isolation bypass, bit 10 after PHY config, `rmw_priv_reg`) | [V] `zumapro-pcie.dtsi:56`, `PC/pcie-exynos-rc.c:3568` |
| Clocks | `pcie-clk-num = <0>`: stock's host names none; CMU_HSI1 gates at 0x2068-0x20e4 (DBI/MSTR/SLV ACLK, PHY APB/REFCLK, IA, UASC, SSMT) | [V] DT; offsets [I] from zuma's `cal-if/zuma/cmucal-sfr.c:1614-1635`, as HSI1-PLAN uses zuma CAL for G4 |
| Rails | LDO16M and LDO18M ("PCIE0") always-on in stock | [V] `zuma/dts/zuma-pmic.dtsi:411-440`; [I] left on, since our DT doesn't describe them (M0.2) |
| PHY sequence | channel 0's own branches of the CAL: external PLL (UDBG 0xC710/0xC700, lock poll 0xC704 bit 3), SOC 0x4004 selects it, ELBI 0x80 = 4, soft power reset 0x3a4, PMA reset 0x1400-0x1408, PMA/lane/PCS tables for 2 lanes, PLL/CDR/OC polls (PMA 0xA80 b0, 0x15C0 b4, 0x140C b7), PHY 0x32C = 0, ELBI 0x1078 = 1; power-down-clear and power-down differ from channel 1 | [V] `PC/pcie-exynos-zuma-rc-cal.c:38-225,276-724` (the `else` branches) |
| Host extras | UDBG 0xC800 &= ~(3<<5) for ch0 (ch1 writes 0x421); PCS 0x150 = 0x300D5 after power-on; APP_XFER_PENDING 1 before, 0 after each config access | [V] `PC/pcie-exynos-rc.c:3570-3576,3954-3962,1821-1832` |
| iATU | **no secure-ATU SMC on zumapro**: the host writes the unrolled outbound iATU itself (DBI + 0x300000) | [V] `PC/pcie-exynos-rc.h:299-309`, `PC/pcie-exynos-rc.c:1644-1690`; gs201's SMC 0x820020D8 is absent |
| IOCC | SYSREG_HSI1 + 0x704, bits 1:0 = 3 | [V] `PC/pcie-exynos-rc.h:240`, `:1988` |
| SysMMU / S2MPU | `sysmmu_hsi1` 0x12060000 (SPI 424) enabled by stock with CPIF's PCIe IOMMU (`CONFIG_LINK_DEVICE_PCIE_IOMMU=y`); S2MPU `s2mpu_s0_hsi1` 0x12090000 | [V] `zumapro-pcie.dtsi:60-73`, `tegu/dts/zuma/zuma-s2mpu.dtsi:85`; [I] both pass DMA untranslated under our boot, as HSI2's did for Wi-Fi and gs201's for cheetah's modem (M5) |

**What our tegu tree has (T/):** CMU_HSI1 (GPIO clock path only, no PCIe
gates registered), `pinctrl_hsi1` with gph0, `pinctrl_peric0` (gpp2/8/12/16),
`pinctrl_alive` (gpa3, gpa7), `pinctrl_far_alive` (gpa5, GPIO-only, its
EINTs not advertised: FAR-ALIVE-PLAN), and the four modem regions in
`zumapro-reserved-memory.dtsi` (F3). It has **no** `pcie_0`, PHY,
`sysreg_hsi1`, `sysmmu_hsi1`, CPIF or gnssif, no HSI0 USI3 (`spi_21`) and no
CMU_HSI0 USI3 clocks. The cheetah port (`L/drivers/soc/google/cpif/`,
`L/drivers/pci/controller/dwc/pcie-gs201-cp.c`) is in `omamobile-int`, not in
the tegu tree. The PMU owner routes only 0x3ec8 to the secure RMW for G4
(PMU-PLAN): 0x3ec4 needs the same routing.

### F2. Control lines (D9/ and `zumapro-board-cp-s5300-sit.dtsi`) [V]

| Line | Pin | Controller | Stock pin state |
| --- | --- | --- | --- |
| ap2cp_wake_up | gpp16-0 | PERIC0 0x10840000 | output, no pull, pdn previous |
| ap2cp_dump_noti | gpp16-1 | PERIC0 | same |
| ap2cp_pda_active | gpp16-2 | PERIC0 | same |
| ap2cp_cp_wrst_n | gpp16-3 | PERIC0 | same |
| ap2cp_cp_pwr_on | gpp12-2 | PERIC0 | same |
| ap2cp_nreset_n | gpp12-3 | PERIC0 | same |
| ap2cp_pm_wrst_n | gpp8-3 | PERIC0 | output (function 1), same |
| cp2ap_cp_ps_hold | gpa5-0 | FAR_ALIVE 0x154e0000 | input, no pull |
| cp2ap_wake_up | gpa5-1 | FAR_ALIVE | EINT, pull-down (**don't port the pull-down**: cheetah 2.1/6.3) |
| cp2ap_phone_active | gpa5-2 | FAR_ALIVE | EINT, no pull |
| cp2ap_cp_wrst_n | gpa7-3 | ALIVE 0x154d0000 | input, pull-down |
| gnss2ap_spi | gpa5-4 | FAR_ALIVE | EINT, pull-down, pdn previous |
| ap2gnss_spi | gpp2-3 | PERIC0 | output, no pull |
| S5910 SPMI clk/dat | gpa3-0/1 | ALIVE | bit-banged SPMI to the S5910 clock buffer |

Boot and power sequences are the same code as cheetah's [V]:
`CP/modem_ctrl_s5100.c:906-938` (`gpio_power_off_cp`, `gpio_power_offon_cp`)
is cheetah's section 1 to the millisecond; `start_normal_boot()` and
`s5100_poweron_pcie()` (`:1335`, `:1765`) likewise. The one addition: on
power-off stock first drives nreset low and runs the S5910's off sequence
(`:1081-1086`, `s5910,seq` = 0x215←0x0f, 1 s, 0x20e←0x04, 0x240←0x10). The
S5910 driver writes nothing at probe (`G/google-modules/soc/gs/drivers/misc/s5910/s5910.c:165-200`),
so the boot doesn't need it [V]; the modem stays on once up (cheetah M2.6),
so it isn't ported before a power-off test.

GPA5 is shared (WLAN host wake pin 3, TAS2572 pin 5, Bluetooth pin 6):
FAR-ALIVE-PLAN's bank-wide EINT ownership question is settled (FA2,
2026-10-27): the base DT gives Linux the whole bank, pins masked until a
consumer requests one.

### F3. Shared memory [V]

| Region | Address, size | Stock (`G/devices/google/zumapro/dts/zumapro-rmem.dtsi:96-118`) | Ours (`T/.../zumapro-reserved-memory.dtsi`) |
| --- | --- | --- | --- |
| cp_rmem | 0xea400000, 12 MiB | `exynos,modem_if`, rmem_index 0 | `cp@ea400000`, no-map (:159) |
| cp_msi_rmem | 0xf6200000, 4 KiB | rmem_index 1 | `cp-msi@f6200000`, no-map (:164) |
| cp_rmem_1 | 0xe8000000, 32 MiB | rmem_index 2 | `cp-extra@e8000000`, no-map (:154) |
| cp_aoc_rmem | 0x197fd000, 12 KiB | rmem_index 3 | `cp-aoc@197fd000`, no-map (:28) |

Stock's `cp_shmem` regions (D9/): IPC = cp_rmem +0, 8 MiB, cached; **GNSS_FW
= cp_rmem +0x800000, 4 MiB, cached** (why cp_rmem is 12 MiB here and 8 MiB on
gs201); MSI = cp_msi_rmem; PKTPROC = cp_rmem_1 +0, 0x1c00000; PKTPROC_UL =
cp_rmem_1 +0x1c00000, 4 MiB; VSS_AOC = cp_aoc_rmem (left out, as on cheetah:
never CPU-mapped). Our DT already matches; M0.2 checks them on the running
kernel.

### F4. CPIF: tegu against our cheetah port

[V] The same driver: 24 of the port's files are byte-identical to tegu's
`CP/`; in `modem_main.c` and `modem_ctrl_s5100.c` every difference is one of
the port's own changes (gpiod, no panics, permanent module, `allow_poweroff`,
the MSI and pktproc fixes). [I] the rest likewise (K4 diffs them all).

The stock nodes differ from cheetah's (`device/cheetah/overlays/modem-cpif-test.dtso`) only in:

- `mif,link_attrs` 0x37c8 vs 0x17c8: bit 13 `LINK_ATTR_XMIT_BTDLR_GNSS`
  ("GNSS FW on DRAM", `L/.../gs-include/dt-bindings/soc/google/exynos-cpif.h:146`).
  It makes CPIF map GNSS_FW and give the boot device the
  `IOCTL_LOAD_GNSS_IMAGE`/`READ_GNSS_IMAGE` ioctls (`CP/link_device.c:2124-2190,3746,3859`);
  already in our port, unused on cheetah. Bit 11 (SPI boot) is clear, so
  `cpboot_spi_bus_num = 15` is unused.
- two more iodevs: `gnss_boot` (ch 0xf0, raw, attrs 0x4200) and `gnss_dump`
  (ch 0xef, attrs 0x200).
- `cp_shmem` + GNSS_FW (F3); no `offset_boot_indicator` (cheetah 0x90);
  `mif_off_during_volte = 1`; `google,clk-buffer` (S5910, F2).
- line pin states and GPIO banks (F2). Everything else (legacy buffers,
  SBI fields, `pci_db_addr`, all 33 `pktproc_*`) is identical.

[V] Userspace is cheetah's shape (V/ `etc/init/cbd.rc`, `rfsd.rc`,
`build.prop`): `cbd -d -t s5100sit -P by-name/modem${slot} -s 2`, `rfsd -d`,
`/mnt/vendor/modem_img` = by-name/modem (ext4, `fstab.modem`). The
partition is the same tar/ext4 polyglot as cheetah's (ext4 magic at 0x438
of the backup's modem_a [V]). cbd's strings add `nv_5g_data.bin`,
`nv_data.bin`, and TN/NTN image selection (`vendor.cbd.modem_bin_type`,
`/vendor/firmware/{stable,ntn}_modem`): keep type 0. It still reads
`ro.boot.cdt_hwid` / `persist.vendor.modem.cdt_hwid` (present in the private
2026-10-20 getprop capture) and `/chosen/{plat,config}`.

### F5. GNSS

[V] Kernel (`GN/`, `CONFIG_EXYNOS_GNSS_IF_SPI`, about 1,300 lines):
`gnss_spi.ko` binds `samsung,gnss-spi` on `spi_21`; `gnssif.ko` binds
`samsung,exynos-gnss` ("KEPLER") and creates `/dev/gnss_ipc`: an SPI byte
pipe with a request/ready handshake (gnss2ap_spi gpa5-4 high-level IRQ, wake
source; ap2gnss_spi gpp2-3 output, starts 0). No regulator, clock or PMU of
its own: the Kepler core is inside the S5300, runs firmware the AP puts in
GNSS_FW, and needs the CP ONLINE.

[V] `spi_21` = HSI0 USI3 at 0x111e0000, SPI 409, `sysreg_hsi0` + 0x1020,
`pd_hsi0` (`G/devices/google/zumapro/dts/zumapro-usi.dtsi:1184-1201`);
CMU_HSI0 USI3 mux 0x1020, div 0x1820, gates 0x2124/0x2104/0x2108/0x20d0
(zuma CAL, USI2's +4, and USI2 is qualified for touch on SPI20). Stock MP
board: `gnss@0` at 3.125 MHz, `swap-mode`, no DMA (D9/ fragment@110).

[V] Userspace (V/): `/vendor/bin/hw/gnssd` (Samsung's engine, user `gps`),
bionic only (`libc++ liblog libm libandroid_net libssl libcrypto libcurl libz
libcutils libdl libc`): **no binder**, so it fits the vendor chroot as lhd/gpsd
did on cheetah. `/vendor/etc/gnss/gps.cfg`: device K041, patch file
`/vendor/firmware/kepler.bin` (about 1 MB), data port CHPP over
`/dev/gnss_ipc`. Its strings open `/dev/gnss_boot` (`GNSS_IOCTL_LOAD_GNSS_IMAGE`),
`/dev/gnss_dump`, `/dev/umts_boot0` (it waits for the CP to boot) and
`/dev/umts_ipc0` (SIT, control-plane assistance), and use `/data/vendor/gps`,
`/sys/power/wake_lock`, `/sys/devices/soc0/{machine,revision}` and
`/sys/devices/system/chip-id/evt_ver`. The framework HAL
(`android.hardware.gnss-service`) needs binder: not used. [I] NMEA leaves
gnssd through its HAL socket and, optionally, a `%s/nmea` output and
`gnss_nmea_<time>.txt` logs (`NmeaBitmask`, `SpotLogger_Allowed` in gps.cfg);
which one Linux can read is G0's question.

## K. Kernel work (offline, omb)

Branch `omamobile-tegu-modem` in `~/tegu/wt-modem`, output
`~/tegu/out-modem`, based on `T/` (`991042e2e`); GNSS in its own branch
`omamobile-tegu-gnssif` (`~/tegu/wt-gnssif`, `~/tegu/out-gnssif`). Each piece
builds `W=1` clean, passes `checkpatch --strict` (imported Google files keep
Google's style, as on cheetah), `dt_binding_check` and `dt-validate`.

- **K1, the link driver.** The cheetah driver's state machine and CPIF API
  (`pcie-gs201-cp.c`: steps `cp_on`/`cp_off`/`link_up`/`link_down`/`bus`,
  `allow_hw`, faults, the DBI guard `4b1364136`) with a zumapro variant,
  `google,zumapro-pcie-cp`: channel 0's CAL tables extracted mechanically
  into a `tegu-pcie0-seq.h` as was done for channel 1; the ELBI quirks
  `tegu-pcie1` already proved (APP_XFER_PENDING); PMU 0x3ec4; IOCC through
  `sysreg_hsi1`; and, instead of the SMC, the DesignWare core's own unrolled
  iATU (config window 0x40ffe000, memory window 0x40000000 → PCI 0x14e00000).
  The PHY tables belong in the planned `google,zumapro-pcie-phy` variant
  (WIFI-PLAN "Host glue"), as per-channel data.
- **K2, PMU.** Route 0x3ec4 to the secure RMW as PMU-PLAN does for 0x3ec8.
- **K3, DT (base, all disabled).** `sysreg_hsi1` (0x12020000); `pcie_0` +
  its PHY; the documented `samsung,s5300-modem` child with the eleven lines
  and the three regions (cheetah's binding, 2.1 "where the lines live");
  `pcie0_clkreq`/`pcie0_perst` pin states; no `sysmmu_hsi1`. Runtime
  overlays as tegu does (`tegu-pcie1-enable.dtso` + an activate module): the
  tegu base has symbols, so `cpif` and `cp_shmem` can be an overlay with
  phandles (`tegu-modem-cpif.dtso`, stock's nodes from D9/ minus VSS_AOC,
  pktproc in a second overlay as on cheetah).
- **K4, CPIF.** Bring the port from `omamobile-int`
  (`L/drivers/soc/google/cpif/`, `shm_ipc`), rename the compat layer to a
  link-neutral API (`pcie-gs201-compat.c` calls whichever link driver
  registered), diff every file against tegu's `CP/`, and build
  `EXYNOS_MODEM_IF=m`, `SEC_MODEM_S5100=y`, `SHM_IPC=m`,
  `CH_EXTENSION=y`, `CP_PKTPROC(_UL)=y`, `LINK_DEVICE_PCIE_IOCC=y`, no
  `S5910`, no PCIe IOMMU.
- **K5, gnssif.** Import `GN/` verbatim (one commit), then port: gpiod, no
  `BUG()`, IRQ requested at open rather than probe (so loading it can't
  take a GPA5 interrupt early), Linux 7.3 API drift. Module
  `gnssif`, blacklisted until G1.
- **K6, the GNSS SPI.** CMU_HSI0 USI3 clocks (USI2's code, +4), `usi3_hsi0`
  + `spi21` (disabled) beside the touch's USI2/SPI20.

## U. Userspace work (offline, this repo)

- **U1, `omamobile-modem` for tegu.** Today it is cheetah's: it loads
  `pcie-gs201-cp` (`lib/omamobile-modem-start:29-37`) and its props say
  `ro.boot.hardware.platform=gs201`, `ro.hardware=cheetah`
  (`modem/props.conf:10-11`). Make the link module and those two values
  per device (zumapro, tegu), add `nv_5g_data.bin`/`nv_data.bin` to what
  the profile expects in the efs copy (checksums only where stock has a
  salted one), and blacklist `cpif`, `shm_ipc` and the link module in
  `omamobile-device-tegu`. NV handling, start order, stop rule and markers
  stay exactly as cheetah's.
- **U2, the chroot image.** `tools/extract-vendor-chroot -p modem` on the
  owner's tegu factory image (on maclab, small result back), plus a new
  profile `gnss-kepler`: `gnssd`, `kepler.bin`, `gps.cfg`, `ca.pem`, and
  stand-ins for `/sys/devices/soc0/*` and `chip-id/evt_ver` (values from the
  private stock capture, never committed).
- **U3, the GNSS package.** `omamobile-gnss` (cheetah: Broadcom lhd/gpsd) gets
  a Kepler backend: start gnssd only after `omamobile-modem` reports
  ONLINE, then the same NMEA → gpsd → GeoClue bridge (`omamobile-gnss-nmea`)
  and Location tile. Which NMEA source the bridge reads is G0's answer.

## Runbooks

Every step: kmsg streamed to the laptop first (`tools/phone-ssh 'cat /dev/kmsg' > logs/tegu-modem-<step>.log &`),
the UFS check after it (`dmesg | grep -c ufshcd_err_handler` and the
13200000.ufs debugfs stats against the count before), and M0.1's checksums
before any step that runs a modem daemon. Stop rule everywhere: an Oops,
an I/O error, a UFS handler pass outside a modem power change, or an NV
mismatch. A hang: wait for the watchdog; if it doesn't come back, the human
forces a restart (the only physical action in this plan).

### M0.2-M0.4: read-only, current kernel (risk: none)

```sh
# M0.2 memory, chosen, packages
tools/phone-ssh 'ls /sys/firmware/devicetree/base/reserved-memory | grep -E "^cp"; grep -iE "e8000000|ea400000|f6200000|197fd000" /proc/iomem'
tools/phone-ssh 'ls /sys/firmware/devicetree/base/chosen'          # names only: plat, config present?
tools/phone-ssh 'systemctl is-enabled omamobile-modem omamobile-gnss 2>&1; ls /etc/modprobe.d'
tools/phone-ssh 'ls /sys/bus/platform/drivers | grep -iE "pinctrl|gpio"; ls /sys/kernel/debug/pinctrl'
# M0.3 the lines, where their controller is bound (record, change nothing)
tools/phone-ssh 'P=/sys/kernel/debug/pinctrl; grep -hE "\((gpp16-[0-3]|gpp12-[23]|gpp8-3|gpp2-3)\)" $P/*10840000*/pins;
  grep -hE "\((gpa3-[01]|gpa7-3)\)" $P/*154d0000*/pins; grep -hE "\((gpa5-[0124])\)" $P/*154e0000*/pins;
  grep -hE "\((gph0-[01])\)" $P/*12040000*/pins'
```

- Expect: the four `cp*` nodes, none listed as System RAM; omamobile-modem
  and omamobile-gnss disabled (they are cheetah's builds; leave them
  installed and disabled); outputs low or inputs, cp2ap inputs low (the CP
  is unpowered).
- Record: `PUD` of gpa5-1 (cp2ap_wakeup) as left by the bootloader: keep it
  (cheetah lesson). `plat`/`config` presence decides U1's chosen binds.
- Stop: an ap2cp output high or a cp2ap input high (the bootloader left
  the CP powered): record it; plan a power-off step before M2.
- **M0.4 (one probe build, read-only):** a fixed CMU-only observer, as
  WIFI-PLAN W2, for the CMU_HSI1 PCIe gates (F1), and the existing PMU
  regmap reader, as W3, for 0x3ec4. Expect gates on (`clk_ignore_unused`
  is on the command line), 0x3ec4 bit 0 clear (isolated). Stop on any
  read of a controller/PHY block: not in this step.

### M1: build (offline; risk: none)

K1-K4 and U1-U2; boot nothing. Pass: builds and checks above; `modinfo`
dependencies `cpif` → `shm_ipc`, the link module; the overlay applied to the
DTB offline with `fdtoverlay` matches D9/'s `cpif`/`cp_shmem` property by
property except the documented gaps; `git merge-tree` against the tegu int
branch clean.

### M2 results (2026-10-27, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`)

[V] K1 is `probes/tegu-pcie0-cp.c`: cheetah's `pcie-gs201-cp.c` with
channel 0's CAL tables (`tegu-pcie0-seq.h`) in place of the PHY driver,
the host's own unrolled iATU in place of the SMC, APP_XFER_PENDING raised
for training and dropped after, no CMU_HSI1 clocks and no IOCC sysreg yet.
Runtime overlay `overlays/tegu-modem-link.dtso` through
`probes/tegu-modem-link-activate.c`. Builds W=1 clean; checkpatch: two
alignment checks. Logs: `logs/tegu-modem-20261027/` (m2-, m23-kmsg).

- **M2.0 passed.** Overlay id 11, the driver binds: every line as M0.3,
  PERST# asserted, PMU 0x3ec4 0xc0, "steps enabled, modem lines here". The
  overlay's `pcie0-clkreq`/`pcie0-perst` pin groups are refused ("invalid
  function ... in map table"): Samsung pinctrl takes groups only at its own
  probe. PERST# works as a plain GPIO; CLKREQ# stays an input. Both groups
  go in the base DT with the next DTB.
- **M2.1 failed, then passed.** With ABL's pulls (every GPA5 pin
  pull-down) the outputs switched (CON 1, DAT 1 on pwr-on, nreset, wrst,
  pm-wrst, pda-active) but all four cp2ap lines stayed 0 for 10 s. With
  cp2ap-wakeup pulled up and ps-hold and phone-active floating (stock's
  "no pull"; the new `bias` step), **cp2ap-wakeup and cp2ap-phone-active
  went to 1 within 0.5 s** and back to 0 at `cp_off`. ABL's pull-down
  hides the modem's lines, as stock's pull-down did on cheetah (2.1).
  cp2ap-ps-hold and cp2ap-cp-wrst stay 0 (no firmware yet).
- **M2.2 passed** earlier (0xc0, set 0x1, cleared 0xc0).
- **M2.3 passed.** `link_up`: PHY out of isolation (0x3ec4 = 0x1, 0x401
  after bit 10), no PLL, CDR or offset-calibration poll missed, DBI ID
  0xa5a5144d, **"link up: Gen1 x1 (target Gen1), try 1"**, LTSSM 0x11.
  `atu`: config 0x40ffe000 to bus 1, memory 0x40000000 to PCI 0x14e00000.
  `id`: **endpoint 144d:a5a5**, the S5300's ROM.
- **M2.4 passed.** `bus`: 0001:00:00.0 root port 144d:ecec, 0001:01:00.0
  144d:a5a5 class ff0000, BAR 0 (64-bit) and BARs 2-5 1 MiB each at
  0x40000000-0x404fffff, "MSI ready, irqs on". `link_down`: PHY isolated,
  0x3ec4 back to 0xc0; `cp_off`. No `ufshcd_err_handler` line through the
  whole session; Wi-Fi (0000:01:00.0) stayed up.

Next: the base DT gets the pull fix (FAR_ALIVE hog: gpa5-0 and gpa5-2 no
pull, gpa5-1 pull-up) and the PCIe0 pin groups; then K4 (CPIF) and M3.

### M3-M5 results (2026-10-27, same kernel)

[V] K4 is cheetah's CPIF port built unchanged against the tegu tree
(`cpif.ko`, `shm_ipc.ko`, with `tegu-pcie0-cp.ko` in one M= build,
`CONFIG_` choices as cheetah's fragment), W=1 clean. Overlay
`overlays/tegu-modem-cpif.dtso` through `probes/tegu-modem-cpif-activate.c`.
U2: `tools/extract-vendor-chroot -p modem -d tegu` on the BP3A.250905.014
factory image (slot A's build) on maclab: 30 files, 12 MB, installed in
`/usr/lib/omamobile-vendor/modem/` on the palmtop (never committed).
Per-palmtop props: `ro.hardware=tegu`, `ro.boot.hardware.platform=zumapro`
and `ro.boot.cdt_hwid` from the private capture; NV checksums from the
2026-10-26 backup.

- **M3 passed.** CPIF binds with the modem off: `umts_boot0`, `umts_ipc0/1`,
  `umts_rfs0`, `umts_router`, `gnss_boot`, `gnss_dump` and the rest, 30
  rmnet, "GNSS_FW 0xeac00000 0x00400000", "gnss_v_base=", PMU 0xc0, every
  output low.
- **M4 passed** after one profile fix: tegu's `persist` is f2fs, not ext4
  (`profiles/modem.conf` now mounts the RAM copy by type). Five RAM copies
  match the backup, the three salted NV checksums match, baseband
  g5300t-250605-250630-B-13713258; rfsd: Touch, IsCsumCorrect, Verified,
  "file is ok"; no Expand, Create or Clear.
- **M5, first try: the ROM stopped.** ROM link Gen1 x1, s51xx probe and
  doorbell fine, boot image at 0xEA410000, then boot_stage 0xFF -> 0x1FF and
  "check_cp_status fail", err_report 0x2000. The port maps cached regions
  write-back because stock's link is I/O coherent; ours has no IOCC yet, so
  the ROM could read stale memory. The profile's stop left the CP in
  BOOTING; `omamobile-modem-cp power-off` turned it off cleanly.
- **M5, second try: CP ONLINE.** IPC and GNSS_FW marked `region,cached = 0`
  (write-combine): boot_stage 0xFF -> 0x3FFF, "link up: Gen3 x2 (target
  Gen3), try 1" for the boot loader, PHONE_START, INIT_END, "CP ONLINE (cbd
  exit 0)" about 2 s after the power-on. No SIM. No UFS error-handler pass,
  no SysMMU or S2MPU fault, Wi-Fi unaffected.

- **The CP's IPC needs the packet processor.** With legacy buffers only
  the AP advertised capability 0x2 (stock 0x3), and the CP never took a
  frame: NORM_RAW tx 432/0, rfsd idle, CP2AP_WAKEUP held high (cheetah's
  pre-M4.1h picture). With stock's pktproc properties in the overlay (all
  regions uncached, `use_hw_iocc` 0, as the link has no IOCC): within 60 s
  FMT rx 1712/1712, NORM_RAW tx 10912/10912 and rx 690480/690480 (rfsd's
  traffic both ways), "cp2ap_wakeup:0 ap2cp_wakeup:0 pcie_powered_on:0" (the
  idle link power-down) and seven clean link cycles ("link up: Gen3 x2",
  "bus already registered, MSI re-armed", "PHY isolated"), UFS 0.
- A second CP boot in the same Linux boot, after IPC had run, stopped in
  the ROM (boot_stage 0x0, err 0x0: the ROM never answered). After a CRASH_EXIT
  without IPC a second boot worked. Until that is understood: reboot
  before booting the CP again.
- The profile's stop is the unit's ExecStop; my first test units had none,
  which is why the CP stayed up after `systemctl stop`.

Open: IOCC (SYSREG_HSI1 + 0x704) so IPC and pktproc can be cached as
stock; the second-boot stall; M6 (reboots with the CP up) not run: stop
the unit (its ExecStop powers the CP off) before a reboot.

On the palmtop, `/usr/local/bin/omamobile-tegu-modem-up` (source
`logs/tegu-modem-20261027/phone/`) does M5 in one step: the modules from
`/var/lib/omamobile-tegu/modem/`, the profile as the transient unit
`omamobile-tegu-modem` with the profile's stop as ExecStop, ONLINE within
about 10 s; it refuses a second start in the same boot.

### G1-G2 results (2026-10-27, same kernel plus the GNSS1 Image)

[V] K6: CMU_HSI0 USI3 clocks (IDs 28-32: mux 0x1020, divider 0x1820, gates
0x2124, 0x2104, 0x2108, USI2's layout), `usi3_hsi0` and `spi21` in
zumapro.dtsi, `gnss@0` and `gnssif` in the board dtsi
(`patches/zumapro-tegu-gnss-kernel-20261027.patch`). K5: `gnssif/` is
Google's gnssif_spi ported: GPIO descriptors (`gnss2ap-spi-gpios`,
`ap2gnss-spi-gpios`), 8-bit SPI words (stock's 32-bit words with the vendor
SPI driver's byte and half-word swap put bytes on the wire in memory
order; mainline has no swap mode), sscoredump stubbed, the remove() API,
W=1 clean. U2: `-p modem -d tegu` also extracts gnssd, kepler.bin, gps.cfg,
ca.pem and the CA store (188 files, 22 MB).

- **G1 passed.** spi21.0 at boot; gnss_spi and gnssif bind with the CP off:
  `/dev/gnss_ipc`, gnss2ap on gpa5-4 as EINT (Linux IRQ 87), ap2gnss gpp2-3
  output low. USI3 ipclk 24.96 MHz (399.36 / 16), SPI about 3.1 MHz.
- **G2 passed** after two fixes. Started 0.6 s after ONLINE without pktproc,
  gnssd's first message on gnss_boot (cmd 0xC2) was followed 0.8 s later
  by the CP's CRASH_EXIT (crash reason empty). With pktproc and gnssd 20 s
  after ONLINE: "pcie_init modem available", two `IOCTL_LOAD_GNSS_IMAGE`
  (kepler.bin into GNSS_FW), "state: CODELOAD->OPERATIONAL", then "GNSS
  ASSERT: chppPlatformNotifierWait in STATE_PERMANENT_FAILURE": about half
  the bytes from Kepler arrived one bit late ("68 43" read as "34 21",
  gnssif's packet dump), Kepler changing its data on our sampling edge.
  With `samsung,spi-feedback-delay = <2>` (DTB GNSS2): every frame starts
  "68 43", CHPP sequence numbers advance, no assert, and the chip reports
  itself in `/data/vendor/gps/chip.info`: "S.LSI,K041,
  SPOTNAV_4.15.4_5_250417_R1".
- **G0, found:** gnssd listens on the abstract Unix socket `@GNSSND` (and
  `@GNSS_ISM_CAPTURE_PLAYBACK`); stock's `android.hardware.gnss-service.pixel`
  connects there. Positions need a client that speaks that protocol, or
  gnssd's NMEA file output (`%s/nmea`, `SpotLogger_Allowed`, overlay config
  `/data/vendor/gps/overlay/gps_overlay.conf`). Next GNSS step.

### G3, partial (2026-10-27)

[V] Stock's chain is gnssd <- `@GNSSND` <- Samsung's AIDL HAL
`/vendor/bin/hw/android.hardware.gnss-service` (init `slsi_gnss_service`,
registers `android.hardware.gnss.IGnss/vendor`) <- the Pixel HAL
(`IGnss/default` for the framework). Ours: the `gnss-slsi` chroot profile
(packages/omamobile-gnss) runs servicemanager, the image's
vndservicemanager (vendor processes use `/dev/vndbinder`; the system
servicemanager refuses their "VNDR" parcels) and the Samsung HAL, and
`omamobile-gnss-client` (bionic/gnss-aidl, NDK, transactions written by
hand from the frozen AIDL V3: setCallback 1, start 14, setPositionMode 20,
startNmea 25; callbacks location 4, NMEA 5).

- The HAL registers ("IGnss V3 service added successfully"), the client
  connects, capabilities 0xe7df, setCallback, setPositionMode, start and
  startNmea all ok, status SESSION_BEGIN, then ENGINE_ON / ENGINE_OFF
  every few seconds and no NMEA.
- Why: at each engine start **Kepler's M7 hard-faults**, the same way every
  time ("KEP M7 HARDFAULT ... LR,PC 600B5B39 0000062C", gnssd logs a 1 MB
  fault dump through SIT), gnssd goes UNUSABLE, reloads the patch and the
  next start faults again. The CP stays ONLINE. Seven faults in 3 minutes
  (`logs/tegu-modem-20261027/g5-gnssd.log`).
- Just before it: "aiding_timemark_reader_thread: open() errno:2" (gps.cfg
  `ChipCfg_Timemark_Option=1`, `Is1PPSTimeSyncEnable=1`), and gnssd reads
  `/sys/devices/soc0/{machine,revision}` and
  `/sys/devices/system/chip-id/evt_ver`, which neither our kernel nor the
  chroot has. Also unknown: the GNSS RF front end's clock (the S5910
  buffer's outputs; stock has only its off sequence) and whether GNSS_FW
  must be cached and coherent as on stock.
- Kepler's soft watchdog wrote two 6 MB RAM dumps
  (`/data/vendor/gps/soft_dog_*_system_ram.bin` in the modem chroot's state,
  private). Their formatted text has "TEST4 ENB ACQCLK and RF", "TEST2 ENB
  ACQCLK" and **"Error: FCAL Part 1 is not done yet."**: the RF front end's
  frequency calibration hasn't finished when the engine starts. persist has
  no GPS files (read-only copy, 2026-10-27), so its calibration is likely in
  the modem's NV, which the CP has, or comes from a step stock's HAL or RIL
  triggers.
- Not the SIT channel itself: with umts_ipc0/1 bound into the chroot,
  gnssd still never opens them (its SIT traffic goes through RIL,
  libsitril-gps) and the fault is unchanged. The CP, meanwhile, sends
  unsolicited SIT messages to umts_ipc0 that nobody reads ("umts_ipc0->recv_skb
  fail (-19)"). It may need a RIL up before it powers the GNSS RF path:
  that ties G3 to the SIT client (cheetah's omamobile-modem-sit) the SIM
  stage needs anyway.
- **The SIT stack works on the 9a unchanged** (omamobile-modem-sit 0.3.3,
  plain `omamobile-sitd` without `--bringup`): "SIM: absent; radio: off",
  GET_RADIO_POWER, GET_PS_REG_STATE and GET_SIM_STATUS all error 0. With
  sitd up, and after `omamobile-sit radio on` (no SIM: the CP stays in
  POWER_OFF), Kepler still faulted on engine start; after six faults gnssd
  gave up ("chppPlatformNotifierWait in STATE_PERMANENT_FAILURE").
- Correction (2026-10-27, night): a stock reference can't come from this
  palmtop. Arch is on `userdata`, and stock Android on slot A overwrites
  `userdata` before it reaches recovery
  ([NOTES, 2026-10-26 and 2026-10-28](NOTES.md#2026-10-26-and-2026-10-28-slot-a-fallbacks-that-cost-userdata)),
  so booting it loses the Linux root. It needs a second 9a. Was: boot slot A once with
  root and capture `logcat -b all` and dmesg while an app gets a fix (gnssd, the HAL, CPIF's gnss
  lines, the timemark device it opens), then compare; or decode the fault
  dump. Then the NMEA FIFO into omamobile-gnss-nmea, as cheetah.

### G3, second try (2026-10-27, night, same kernel plus the fp1 DTB)

- **The SoC identity files are not it.** gnssd reads
  `/sys/devices/soc0/{machine,revision}` and
  `/sys/devices/system/chip-id/evt_ver`. `probes/tegu-socinfo.c` registers
  them with stock's values in the formats of Google's GPL `gs-chipid.c`
  (machine "ZUMA PRO TEGU MP on ZUMA PRO", revision 16, EVT1.0; fixed, no
  register read). With them present, every code reload after a fault still
  ended in the same "KEP M7 HARDFAULT ... LR,PC 600B5B39 0000062C". The
  `%s/dcxo` path in gnssd is its own store of learned oscillator corrections
  (`cm_dcxo_corrections.bin`), not an input. Stock's S5910 node has only an
  off sequence (Google's driver also reads an optional `s5910,on_seq`,
  which tegu doesn't set), so the AP doesn't switch the RF clock on either.
  G3 stays blocked on a stock capture.
- **gnssd's exit took the modem down.** After about ten faults gnssd gives
  up and exits; the vendor-chroot supervisor then stops the whole modem
  profile (rfsd too), and the unit's ExecStop runs the CP power-off. On
  the second try the CP stayed ONLINE (power-off didn't complete); on the
  first, the profile stopped the same way about 20 s after ONLINE and the
  palmtop hard-reset with the journal's last 40 s lost, a file written just
  before it empty. Suspect: the CP power-off path on tegu, untested so far.
  omamobile-modem 0.1.7 runs gnssd as an optional daemon, so its exit no
  longer stops the profile. Until M6 qualifies the power-off, don't stop the
  modem profile by hand; reboot with someone at the palmtop.
- **gnssd's custom GNSS library (2026-10-28, omamobile-modem 0.1.8).** An
  `strace` of gnssd found two gaps. gps.cfg sets
  `GlueLayer_IsUseCustomGnssLib=1`, and gnssd `dlopen()`s
  `/vendor/lib64/libcustomgnss.so` (ENOENT), which waits for the CP at
  `/sys/bus/platform/devices/cpif/modem_state` and then `dlopen()`s
  `libsitril-gps.so`, which uses `libsitril-client.so` (RIL's GPS channel,
  over binder to the radioExternal HAL). Nothing links the three, so the
  extractor never copied them; they are `VENDOR_LIBS` of the tegu modem
  profile now, and the chroot binds cpif at its bus path too. With both,
  libcustomgnss logs "Modem state ONLINE"; `GpsOpen()` still fails (no
  radioExternal HAL in the chroot: no binder), and Kepler still faults at
  every engine start. A re-run of the extractor on the BP3A factory image
  (2026-10-29) resolves everything: 195 files against 188, the three
  libraries plus libbinder, libbinder_ndk, libapexsupport and the
  radioExternal NDK library, nothing new to stub. **An existing 9a chroot
  gets the libraries only when its owner re-extracts** (`tools/extract-vendor-chroot
  -p modem -d tegu` on the factory image, then the install line from its
  usage text); a chroot from before 0.1.8 keeps running without them, as
  before. The second `/sys` bind is in every phone's modem profile and is
  harmless on the 7 Pro and the 6 Pro: cbd never looks there.

### G3, third try: rails on (2026-10-28, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`, round ps1 DTB with ldo9s-11s on)

[V] With LDO9S-11S on, Kepler loads, reaches OPERATIONAL and no longer
logs "FCAL Part 1 is not done yet": the RF front end calibrates now. The
gnss-slsi HAL and our client start a session (capabilities 0xe7df, start
and startNmea ok, status SESSION_BEGIN then ENGINE_ON), but every engine
start still ends in the same fault: "KEP M7 HARDFAULT ... LR,PC 600B5B39
0000062C" (16 times in 10 minutes, ENGINE_ON/ENGINE_OFF each time), no
NMEA. So the rails were one missing piece, not the fault itself. Indoor or
outdoor doesn't matter yet: the engine crashes before it searches.
The G3 script's HARDFAULT count missed these (gnssd wrote them outside its
window).

### G3, fourth try: the AoC told the GNSS type (2026-10-28, evening, gn3 DTB)

[V] With `&aoc { gnss-type = <2>; }` (kAOCGnssType, as Google's
`zumapro-phone-ignss.dtsi`), Kepler loads, goes OPERATIONAL, and the
gnss-slsi HAL and our client start a session (startNmea ok, "the HAL asks
for a location"). But every engine start still ends in the same "KEP M7
HARDFAULT ... LR,PC 600B5B39 0000062C" (20 in 4 minutes), so the type isn't
it. In the register dump, R3 = 0x62D and PC = 0x62C: the M7 jumped
through a function pointer holding 0x62D, a Thumb address near zero, which
looks like an entry nobody filled in. Other leads from the logs:
`aiding_timemark_reader_thread: open() errno:2` (gnssd can't open its
time-mark device), `TGT_MEMS initInterface: fromBinder() failed` (the HAL's
sensor service is missing), and `libsighandler.so` not found. Next, attended
and on the charger, with the modem up: `strace -f` gnssd across one engine start, to see which
files and devices it opens or fails to open (observation only).

### G3, fifth to eighth tries (2026-10-29, night, same kernel, on the charger, outdoors spot)

- **strace of gnssd across engine starts** (the g7 scripts, commit 8d77391d9 of [linux-omarchy-mobile#137](https://github.com/derekross/linux-omarchy-mobile/pull/137)):
  the HAL's request reaches gnssd, gnssd talks CHPP to Kepler over
  `gnss_ipc` normally (the all-zero reads after each write are the SPI
  full-duplex bytes Google's `send_betp` passes up by design), and Kepler
  stops answering a few seconds after the engine start; gnssd then reads the
  GNSS image back (`IOCTL_READ_GNSS_IMAGE`) and dumps RAM. `umts_boot0`
  ioctl 0x28 (EINVAL, not in our CPIF) comes after the fault, in the crash
  path.
- **Missing libraries**: gnssd `dlopen()`s `libcustomgnss.so`
  (`GlueLayer_IsUseCustomGnssLib=1`), which needs `libsitril-gps.so` and
  `libsitril-client.so` (RIL's GPS channel, binder to radioExternal). All
  three were missing from the chroot. With them in, libcustomgnss reads the
  CP state from `/sys/bus/platform/devices/cpif/modem_state`, which the
  chroot lacked; with that bound, it logs "Modem state ONLINE". `GpsOpen()`
  still fails (no radioExternal HAL). Kepler's fault is unchanged (PR #141).
- **DVS and DFS off** through gnssd's `/data/vendor/gps/overlay/gps_overlay.conf`
  (read 27 times): the fault is unchanged (9 in 4 minutes).
- **Stock's rails are Kepler's to control**: LDO9S-11S carry
  `channel-mux-selection` 0x29-0x2b (subsys GPS) in stock's DT, with
  LDO9S ranging 0.725-1.3 V; our DT holds them on at fixed voltages.
- **Hazard found**: after the modem profile has stopped (gnssd's exit),
  starting the profile again in `OMAMOBILE_MODEM_STAGE=rfsd` reset the
  palmtop silently (watchdog, no pstore). Reboot instead.
- **Where the fault is** (local disassembly of the soft-watchdog RAM dump,
  which is kepler.bin as loaded at 0x60000000; private, never committed):
  the patch code at 0x600B5B34 calls a veneer at 0x600E143C that jumps to
  0x200005B5 (R12 at the fault), code in Kepler's SRAM (the main stack is at
  0x2002FF38). That code branched through R3 = 0x62D, and the M7 faulted
  fetching 0x62C, low memory that isn't in the image. So something maps or
  powers Kepler's low memory, or fills that pointer, and it hasn't happened
  by engine start. `umts_boot0` ioctl 0x28 (gnssd's "SHMEM_SIZE -1") is
  not defined in Google's tegu CPIF either, so stock gets EINVAL too and it
  isn't the cause.
- **The loaded image is intact.** The dump differs from kepler.bin in 17
  words, all in the configuration header below 0x390, and they are gps.cfg's
  values that gnssd writes before the load (RfMiscCtrl 0x80008001 at 0x10,
  AidingConfiguration 0x20046 at 0x1c, the VDR 200/20 limits at
  0x344-0x350). So the write-combine mapping of GNSS_FW (stock: cached,
  over an I/O-coherent link) doesn't corrupt the load. The layout matches
  stock too: GNSS_FW at cp_rmem + 8 MiB, 4 MiB long. The missing piece is
  on the core's side (its low memory at engine start), which the AP can't
  see; the next step is Kepler's own debug log (`gps_overlay.conf.next`).

### G3, ninth to fourteenth tries: the "hardfault" is gnssd's watchdog (2026-10-29, night)

[V] With gnssd's debug log on (`gps_overlay.conf`: `debug_enable=1`,
`debug_console=1`, `chpp_log_level=4`), the engine is seen **working**: it
tracks satellites (SVIDs 5, 11, 12, 13 at C/N0 29-35 dB-Hz) within ~10 s
of the start. The fault that follows is gnssd's own: its soft watchdog
logs "KEP soft_dog pos req timeout", then "sw version timeout", resets
Kepler and sends BLC ID 6 ("Try and trigger hard fault to see if CPU is
locked up or maybe we can get RAM dumps"), which is the "KEP M7
HARDFAULT" with PC 0x62C. The watchdog fires because the CHPP link over
the GNSS SPI loses packets: thousands of "ACK timeout" and 244 "Rx BAD
checksum" in one run. In the raw reads, frames that should start with the
CHPP preamble `68 43` often read `34 21`, the same bits one bit late, and
long frames end in zeros.

The SPI settings tried, each on a fresh boot (the CP boots once per boot):

| SPI mode | rx chunk | feedback delay | RX bad checksums | Kepler |
| --- | --- | --- | --- | --- |
| 0 (as ported) | 64 | 2 (as ported) | 244 | tracks, then the watchdog |
| 0 | 32 | 2 | 17 | opstate 0 |
| 0 | 32 | 0 (stock's value) | 93 | opstate 0 |
| 1 | 32 | 0 | 34 | opstate 0 |
| 1 | 64 | 0 | 0 (RX clean) | TX lost: Kepler never sees our RESET-ACK |
| 0, 1 MHz | 64 | 0 | 63 | opstate 0 |
| 3 | 64 | 0 | 32 | opstate 0 |
| 0, 32-bit words (swapped in gnss_spi) | 64 | 2 | 1 | RX transfers time out (-110), opstate 0 |
| 0, 32-bit, auto CS (`google,gs101-spi` only) | 64 | 2 | 0 | RX transfers time out (-110), opstate 0 |
| 0, auto CS | 64 | 2 | 274 | tracks, then the watchdog (as ported) |

So RX samples the core's data a bit early in mode 0, mode 1 fixes RX but
breaks TX, and neither the feedback delay nor a slower clock fixes it.
Stock drives this SPI with 32-bit words, `swap-mode = <1>` and DMA
(`dma-mode`, PDMA 0x14/0x15); our port uses PIO. 32-bit words alone (byte
order fixed in gnss_spi) time out in PIO, so the next step is DMA for this
SPI. Google's driver uses auto CS for this device (no
`samsung,spi-chip-select-mode`), but auto CS changes nothing with 8-bit
words. Our DT has no PDMA controller (stock's overlay uses `pdma1`), so DMA
means a PL330 node for zumapro first. The palmtop is back on the as-ported setting (mode 0,
64-byte reads, delay 2, the gn3 DTB).

Next steps for the link, from the night of 10-29 (not tried yet):
- **32-bit words in PIO time out** (`res -110`, every 64-byte read) under
  mainline spi-s3c64xx. Not its FIFO-level check: Google's driver makes the
  same `RX_FIFO_LVL < xfer->len` comparison for 32-bit words and works, so
  the level counts bytes. -110 is mainline's interrupt wait
  (`wait_for_completion_timeout` in `s3c64xx_wait_for_pio()` with
  `use_irq`), which Google's driver doesn't have: it polls. The FIFO
  trigger interrupt with 32-bit words is the next thing to read
  (spi-s3c64xx is built in, so a change is a kernel push).
- **DMA:** stock's `pdma1` is a PL330 at 0x10130000 (SPI 806, a 200 MHz
  fixed clock, Samsung's 36-bit address wrappers, which mainline doesn't
  have), with the GNSS SPI on channels 0x14 (tx) and 0x15 (rx). A
  read-only probe (2026-10-29) read its PrimeCell IDs (periph 0x30 0x13,
  cell 0x0d 0xf0) from Linux without an abort, so a DT node can probe it.
  Mainline uses DMA only for transfers longer than the 64-byte FIFO, so the
  64-byte reads would stay PIO.

**What the link does (10-29, night), cause still open:** mainline spi-s3c64xx cuts
every PIO transfer of 64 bytes or more into 63-byte pieces
(`xfer->len = fifo_len - 1`), stopping and flushing the FIFO between them.
So each 64-byte read of Kepler becomes 63 + 1 bytes, and each longer write
is cut mid-frame; 32-bit words then can't work at all (63 isn't a multiple
of 4: the `len-63` timeouts). Stock never splits: it uses DMA. But the
split isn't shown to be the cause: with gnss_spi cutting every transfer
into 60-byte pieces itself (one message, CS held, every pause on a 32-bit
boundary, so the controller never cuts), the link garbled just the same
(369 bad checksums, Kepler tracking, then the watchdog). Progress: a runtime test module
registered stock's pdma1 (PL330 at 0x10130000, SPI 806) and the built-in
pl330 driver probed it and ran a 256-byte memcpy correctly; a DTB with the
node probes it at boot. But with `dmas` on the GNSS SPI (0x14/0x15, either
order), RX DMA moves nothing (residue 64): the SPI's DMA requests don't
reach pdma1, so some routing stock sets up is still missing (a sysreg or
USI DMA select, or the PL330's peripheral security setting). The palmtop
is back on gn3 without the node. A one-boot reset at 69 s happened on the
second boot with the node, cause not seen.

### G3, fifteenth to twenty-third tries: the SPI runs at twice stock's clock (2026-10-29, small hours)

[V] Each try on a fresh boot of the gn3 kernel, gnssd's debug log on, a test
`gnss_spi.ko` with module parameters (feedback delay, chip-select setup,
clock, `HIGH_SPEED_EN`), raw RX bytes taken from strace of gnssd's reads of
`/dev/gnss_ipc`. Results:

| Try | Setting | Bad checksums | Kepler |
| --- | --- | --- | --- |
| baseline (control) | as ported: 8-bit, 64-byte reads, delay 2 | 46 | tracks (C/N0 29-34), then the watchdog |
| w32p32 | 32-bit words, 32-byte pieces in one message | 19 | no watchdog, stops after RESET-ACK |
| w32rx32 | 32-bit, 32-byte reads | 7 | same |
| fb3 | 32-bit, feedback delay 3 | 5 | same |
| cs200 | 32-bit, delay 3, 200 us CS setup | 0 | same |
| osc | 32-bit, USI3 mux on OSCCLK, about 1.5 MHz | 0 | same |
| acs | 32-bit, auto CS DTB | 0 | same |
| osc8 | 8-bit, OSCCLK, about 1.5 MHz, delay 0 | 1 | same |
| hs | 8-bit, `HIGH_SPEED_EN` forced, 32-byte transfers | 17 | same |
| hs60 | 8-bit, `HIGH_SPEED_EN`, 60-byte reads | 408 | tracks, then the watchdog (38) |

What the raw bytes show:

- **The real SPI clock is 6.24 MHz, not 3.125.** USI3's mux (`zumapro_mout_hsi0_usi3_local`) is read-only in clk-zumapro and sits on the 399.36 MHz parent; the 4-bit divider stops at /16, so the IP clock is 24.96 MHz and the SPI clock 24.96 / 4, whatever spi-s3c64xx asks for. The "1 MHz" try of the night before ran at 6.24 MHz too.
- **The baseline's errors are per byte:** one byte of a repeated frame arrives with its top bit taken from the previous byte's last bit (`10 01 00 0a ... 4f b6 25 9c` read as `08 00 00 05 ... 27 db 12 ce`), and the rest of the frame is right. That is the controller sampling before Kepler's data has settled: too little margin at 6.24 MHz, as mode 1 (which samples half a clock later) showed.
- **Every changed setting broke the framing instead:** with 32-bit words, with the OSCCLK mux, and with chip select toggled every 32 bytes, CHPP frames arrive at any bit offset (8-bit baseline: always 0 or 1), the link stops after RESET-ACK, and the bad-checksum count drops only because few frames are recognised. A chip-select toggle in the middle of a frame drops one byte from Kepler at the break. So the low counts in this table are not improvements.

The next step is the clock itself, in the kernel: let spi-s3c64xx reach 12.5 MHz on USI3 (3.125 MHz SPI) from a parent that can give it, as stock does, with nothing else changed. The OSCCLK try isn't a fair test of that (24.576 / 4, about 1.5 MHz, switched behind the clock framework's back). The palmtop is back on the baseline (`gnss_spi` aa4618bb, `gnssif` eb0f3d9a, gn3 DTB, no debug overlay). One reset at 348 s, after the hs60 run had ended, came during modem PCIe link activity ("PHY isolated"), not in the SPI path.

### G3, twenty-fourth to thirty-fourth tries: stock's clock, mode 1 reads, where the bytes go (2026-10-29, small hours)

**Stock's clock, tried (twenty-fourth try):** Google's zuma CMU table (`cmucal-vclk.c`, `div_clk_hsi0_usix_12mhz_lut_params` = div 1, mux 1) makes USI3's 12 MHz from OSCCLK / 2 (12.288 MHz, a 3.07 MHz SPI clock). A test module set exactly that (mux to OSCCLK, divider held at /2, 8-bit, delay 0). Framing broke as in the other OSCCLK try: Kepler resent one frame (`68 43 00 20 01 00 0a ...`) for seconds, and every copy arrived shifted by the same 4 bits across many separate reads, then by 5, then 6. So Kepler's bit counter runs on across chip-select cycles, and on OSCCLK it gains or loses clocks; on the 399.36 MHz parent (baseline, 6.24 MHz) the frames stay at bit 0 and only single bytes are misread. A clk-zumapro change that lets USI3 reach OSCCLK / 2 is drafted but not worth a kernel until the slip is understood; it would reproduce this test (later: [linux-omarchy-mobile#138](https://github.com/derekross/linux-omarchy-mobile/pull/138)). The palmtop is on the baseline again.

**Read in mode 1, write in mode 0 (twenty-fifth and twenty-sixth tries).** The baseline's raw reads show more than single bytes: about 80% of CHPP frames arrive one whole bit late (the preamble found at bit offset 1, so CHPP never sees it), which is where most ACK timeouts come from. Feedback delay 3 at 8 bits changed nothing (57 bad checksums, same split of offsets). A test module that switches `spi->mode` per transfer (read-only transfers in mode 1, writes in mode 0; spi-s3c64xx reconfigures on every transfer because its `cur_speed` never equals the rate asked) put every frame at bit offset 0 for the first time on the as-ported clock: short frames pass, the engine reports satellites, the watchdog fires later. Long frames (279 bytes) still fail: the first byte or two after each read's chip select are damaged (in one string Kepler resent, the byte after a 60-byte boundary read `6` in one copy and `8` in the next, and `11 00 11` became `41`). 60-byte reads, so spi-s3c64xx never splits a read, didn't change that. Two resets came from the modem side, not the SPI: after Kepler's watchdog resets, gnssd reloads the image over the CP's PCIe link (`IOCTL_READ_GNSS_IMAGE`, then "PHY isolated"), and the SoC reset within a second (03:15, and 02:43 after the hs60 run). Frequent Kepler resets are therefore a crash risk until the link is fixed; keep GNSS runs short. Separately, two boots reset at about 34 s, right after Bluetooth started (01:41, 03:03), before any GNSS step.

**Where the bytes go (twenty-seventh try, mode 1 reads with 50 us chip-select setup):** 101 bad checksums (260 without the setup), and the palmtop stayed up through 14 Kepler watchdog resets with omamobile-modem 0.1.9's slower CP watcher (#148). Comparing the copies Kepler resends: short frames inside one 64-byte read agree byte for byte, and every copy of a long frame loses the same one or two bytes at each 64-byte read boundary (`11 00 11 00 10 00 01` read as `11 00 00 | 00 01`, `00 00 31 2e 30 2e 30` as `00 00 2e | 2e 30`). So in mode 1 Kepler's stream drops bytes when chip select is released between reads, deterministically, not by timing. In the as-ported mode 0 the copies disagree mostly at byte 63, the one-byte tail spi-s3c64xx splits off each 64-byte read. Next: hold chip select across rx_work's consecutive reads of one Kepler message (one long transfer while gnss2ap stays high), which also removes the split.

**Chip select held across a message (twenty-eighth try):** mode 1 reads with chip select kept asserted between rx_work's reads (released when gnss2ap drops or before a write) made it worse: 292 bad checksums, and the 279-byte frames now end in zeros (footer 0). Kepler wants chip select released between its 64-byte reads, as stock does, so the bytes lost at each release in the mode 1 tries have another cause. What's left untried needs stock evidence: a logic-analyzer capture of stock's SPI21 (CS, SCLK, MISO timing between reads), or stock's register state for SPI21 and CMU_HSI0 USI3 while GNSS runs.

**One bit late, cleanly, with feedback delay 3 (twenty-ninth to thirty-second tries, offline checks on the saved reads with CHPP's CRC32 over the 8-byte header and payload):** at feedback delay 3 (mode 0, 8 bits, the as-ported clock) Kepler's frames are intact but one bit late: shifting the reads left one bit turns 11 valid frames into 123 (at delay 2 the same shift recovers nothing). Kepler is on time just after it starts and one bit late later, so a fixed shift lost its first RESET-ACKs for 2 s and set off a reset storm (125 RESETs from Kepler, 144 RESET-ACKs from gnssd); delaying our writes by one bit as well killed the link outright, so writes are right as they are. A per-read choice (a preamble at bit 0 keeps the read, at bit 1 shifts it, a read without one keeps the last choice) gives clean short frames and the engine reporting satellites, but 279- and 361-byte frames still fail: setting the one dropped bit at each 64-byte boundary every possible way repairs none of them, so more than a bit goes missing at each chip-select release, as in the mode 1 tries. The test module (`gnss_spi.c` with `fb_delay`, `realign`, `rx_cpha`, `hold`, `osc`, `div` parameters) is the `realign` commits of linux-omarchy-mobile#137 (b5229f35d, ff0eadd34, dacf3e304, a0877abc3); the palmtop is back on the baseline.

**Stock's clock again, read correctly (thirty-third and thirty-fourth tries):** the OSCCLK frames are not garbled: every read that holds a frame has a valid one at some bit shift (offline: 32 of 33 valid when each read is shifted to its preamble). But at OSCCLK / 2 (3.07 MHz) Kepler's bit offset walks by one or two bits about every 100 ms (0, 2, 3, 5, 6, 7, 0, 1, 3 in the first second), roughly a clock edge gained or lost per transfer; with the offset tracked per read and our writes delayed by it, 20 frames came through clean but Kepler only answered RESETs. At OSCCLK / 1 (6.14 MHz) the offset changed twice in 100 s. So the drift grows as the clock slows, the opposite of a too-fast slave; a clock edge seen twice (or a glitch) at each transfer's start or stop would fit. The 05:02 reset (CLUSTER0_NONCPU_WDTRESET) came with #148's watcher installed: in its last minute the CP link cycled twice a second in step with gnssd's `IOCTL_LOAD_GNSS_IMAGE` calls, so the watcher was one source of link cycling, not the only one, and the hang (CPIF's link power-down racing an access, presumably) is still open. Keep GNSS runs short until it is fixed.

### The CP link hang (2026-10-29, read from the CPIF source, offline)

**The CP link hang, read from the source (offline):** our `tegu-pcie0-cp` guards DBI and configuration space while the PHY is isolated (accesses return 0 or are dropped), but not the CP's BAR window, which CPIF uses for its doorbell. CPIF's main doorbell path (`link_device.c`) looks safe: it rings under `pcie_tx_lock` after checking that `pcie_onoff_lock` is free and `pcie_powered_on` is set, and `s5100_poweroff_pcie()` takes `pcie_onoff_lock` first and then waits for `pcie_tx_lock` before it powers the link down, so a doorbell either finishes before the power-off or is reserved for later. `IOCTL_LOAD_GNSS_IMAGE` only copies into the GNSS_FW carve-out in AP memory (no link access); the reloads matter because the Kepler reset around them makes IPC traffic, so the link wakes and idles twice a second. I found no unguarded BAR access by reading; the other doorbell callers (`modem_ctrl_s5100.c`) are the CP boot and the power-on path. The step that would find it is below, gated; it has not run, and GNSS is parked (see "Parked" under the morning of 10-29), so it runs only if GNSS is ever resumed.

**What the kept consoles say (2026-10-29, read offline from `/var/log/omamobile/ramoops/`,
the 24 boots between 07:34 and 09:19 local; the extracts are in `logs/tegu-review-20261029/hangs/`,
not committed).** Each saved console holds the bootloader's log of the boot
that wrote it, the kernel's console, then the next boot's bootloader log,
whose `[PRE] RST_STAT` names the reset. The morning's resets sort into
three kinds:

- `SYSTEM_SWRESET_SYSTEM` after `sysrq: Resetting` with a `---[ end trace ]---`
  just before (eight boots): the curated start's fault check tripping on the
  `OF: overlay` WARNING and resetting, as item 7 of the morning list says;
- `SYSTEM_SWRESET_SYSTEM` after `reboot: Restarting system with command
  'bootloader'` (two) or `'omamobile'` (six): the 150 s dead-man and the
  pushes;
- `CLUSTER0_NONCPU_WDTRESET` (eight, at 07:37, 07:42, 07:48, 07:51, 08:45,
  08:52, 08:56, 09:09): the real hangs. Every one of them ends the same way.
  The last line is the pair `samsung-pinctrl 154e0000.pinctrl: wake disabled
  for irq N` / `wake enabled for irq N` (N = the `cp2ap_wakeup` line on
  FAR_ALIVE, 85, 84, 70, 76 or 96 depending on the boot), which is CPIF's
  `ap_wakeup_handler()` flipping the line's trigger after an edge; what
  should follow 5 ms later, `tegu-pcie0-cp: PHY out of isolation`, never
  comes. Before it the link was cycling once every half second: `PHY out
  of isolation`, `link up: Gen3 x2`, 55 ms, the toggle (the CP releasing
  the line), `PHY isolated`, 350 ms, the toggle (the line asserted again),
  and so on, eight to twenty toggles in the last minute. One console (07:42)
  caught the hang's shape: an `rcu_preempt detected stalls` report with
  CPUs 0, 3 and 7 stuck (`idle=...1/0x4000000000000002`, 5255 jiffies,
  detected by CPU 4) 22 s after the modem went ONLINE, i.e. right when
  gnssd starts (`OMAMOBILE_MODEM_GNSS_DELAY` is 20 s), with no backtrace,
  which is what a load that never completes looks like. Another (07:48)
  has, as its last lines before the toggle, gnssd's `lal_state_thread`
  opening `gnss_dump` and `gnss_boot` and CPIF answering `pcie_send_ap2cp_irq:
  Reserve doorbell interrupt: PCI not powered on`: an AP-to-CP interrupt
  asked for while the link was down, which CPIF parks and answers with
  `s5100_try_gpio_cp_wakeup()`.

  So the hang falls in the window after the CP (or the AP's own wake
  request) asserts `cp2ap_wakeup` and before the link is back, and it
  happens only while something cycles the link quickly: the old watcher's
  open/close (the 07:37-07:51 boots, before #148's watcher, omamobile-modem
  0.1.9, in review) or
  gnssd's Kepler loads (the later ones). In that window the paths that run
  are CPIF's `cp2ap_wakeup_work()` to `s5100_poweron_pcie()` and our
  `gs201_pcie_cp_poweron()`, whose first hardware step is the PMU bypass
  write that logs `PHY out of isolation`; nothing before that line touches
  the PCIe block. A load that hangs the CPU therefore comes from another
  thread in that window: a read of the modem's BAR window while the PHY is
  isolated, as the cheetah gotcha describes, from a path that doesn't take
  the link first. The GNSS image itself goes to DRAM (`SHMEM_GNSS_FW` through
  `gnss_v_base`), so the candidates are the IPC paths that follow it:
  `pcie_read_thread` on the shared-memory queues, `s51xx_pcie_restore_state()`
  and the MSI set-up on the way back up, and CPIF's own status reads.

  Two things follow for G3-L1. First, a cheaper step before the trace: a
  cpif module parameter that makes `s5100_poweroff_pcie()` keep the link
  up (Google's own "Skip pci power off" path, taken unconditionally), on a
  bring-up branch, then three 12-second sessions. If the hang goes away
  with the link held, the cause is a link-down access and the trace knows
  where to look; if it stays, the link is not it. Second, the trace points:
  `s5100_poweron_pcie()` entry and `gs201_pcie_cp_poweron()` entry (to see
  whether the power-on path is ever entered before the hang), and every
  `readl` of the BAR window in CPIF (the `s51xx_*` helpers and
  `pcie_read_thread`'s queue reads) with `pcie_powered_on` in the line.

**G3-L1: which BAR access lands after isolation (attended, on the charger; risk: medium-high).** It starts with the hold-the-link step from the section above: a cpif built with `keep_link_up=1` (kernel branch `tegu-cpif-keep-link`, commit 3f76f123b, the module staged on the palmtop as `modem/cpif-keep-link.ko`), three 12-second sessions, under exactly the frame below (M0.1 before and after, attended on the charger, kmsg to the laptop with `--watchdog`, the same Stop and Rollback); its sessions count toward the cap of three sessions, and a hang in them counts toward the two resets, so if the link held up still hangs, the trace gets what is left of the cap or waits for the next day. Then the trace: at each BAR access in CPIF and at `cp_phy_isolate()` (the caller, the lock state and `pcie_powered_on` in the kernel log), to see which access lands after isolation. The tracing change goes on a kernel branch first (`omamobile-tegu-modem`, or a bring-up branch on the fork, linked by commit), is built there and reaches slot B through `bin/omamobile push`; nothing is patched on the palmtop by hand, and the kernel never boots before the branch is pushed. Before the step: M0.1's partition check, the kmsg stream to the laptop with `--watchdog`, the palmtop on the charger with someone at it the whole time, and a 12-second GNSS session (as the morning's) to bring on Kepler's watchdog resets and the link cycling. Expect: the log names the access that follows `cp_phy_isolate()`, or the link cycles through Kepler's resets without a hang. Stop: two SoC resets (a hang with no record in pstore counts as one), or any `ufshcd_err_handler` line in dmesg, or an NV partition that reads `ro=0` or mounted; after a stop, no further boot of the tracing kernel that day. Cap: two resets per session and three sessions in all, then the step is closed and the hang waits for a stock capture. Rollback: `bin/omamobile push` of the previous images (the gn3 kernel), then M0.1 again, as after any reset with the modem up. Risk: medium-high, because each reset is a hang with the modem up, which has been followed by a recovered UFS error-handler pass on cheetah; the partition check afterwards is not optional.

### G3, the morning of 10-29: the clock fixed, the cut fixed, and what is left (thirty-fifth to forty-fourth tries)

[V] Two kernel changes, built from the gn3 source (`~/tegu/int-dt-20261026/kernel` on maclab, the reproducible build; the first attempt from `wt-modem` carried an older USI4 clock table and broke the audio I2C) and pushed as boot images only: spi-s3c64xx no longer cuts a transfer that fills the FIFO (64 bytes in one polled piece; the 32 + 32 test had shown every frame crossing a piece boundary failing with chip select held, so the cut, not the chip-select release, lost the bytes), and clk-zumapro lets USI3 reach OSCCLK (`nMUX`, so the framework may reparent, plus `CLK_SET_RATE_PARENT` on the divider and the source gate): `zumapro_gout_hsi0_usi3_ip` now reads 12.288 MHz after the first transfer, a 3.072 MHz bus, stock's rate. Both are in [linux-omarchy-mobile#138](https://github.com/derekross/linux-omarchy-mobile/pull/138) (in review; branch `tegu-spi-word-pieces`, replacing the closed #135). The morning's tries (thirty-fifth to forty-fourth) ran on those images; their `uname -r` is the night's string, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`, because the build fixes LOCALVERSION, so the release does not change between these builds and the Image's sha256 tells them apart: `Image-osc` (sha256 7d620900…, the first attempt) and `Image-osc2` (75a44a1a…, the one the tries ran; `Image-nosplit` in the same directory is that same image), with the repack scripts in `logs/tegu-gnss-w32-20261029/`. Graphics, audio bring-up and touch are unaffected on that kernel. The SPI block's own prescaler does not exist on this IP (CLK_CFG reads 0 and ignores writes).

[V] Reads, with every byte dumped to the kernel log (a gnssif built with `GNSS_PKT_DEBUG`, 64 bytes per line) and short 12-second sessions so Kepler's watchdog does not pile up resets:
- Mode 0 at stock's clock is marginal at every feedback delay: the per-read detector flips between "on time" and "one bit late" within a session, and long frames fail wherever it flips. (Delay 3 at 6.24 MHz had looked stable only because the session was short.)
- Mode 1 reads (writes stay mode 0) are byte-aligned and intact, but every block after the first one of a message loses its first byte: inserting one byte (0xAA) at the first position of block 1 makes Kepler's constant version frame pass its CRC. With a 100 us chip-select setup the protocol was the healthiest seen (0 ACK timeouts, our packets acknowledged), the first-byte loss unchanged. A 500 us gap before each read made Kepler stop sending long frames; a 50 us chip-select hold did nothing.
- Padding each write to a whole 64-byte exchange (gnssif) changed nothing measurable.
- CHPP's checksum is CRC32 over the 8-byte header and the payload (checked on short frames); the offline checks are in commit 8d77391d9 of linux-omarchy-mobile#137 and the captures in `logs/tegu-gnss-w32-20261029/`.

So with the clock and the cut right, what is left is one byte per back-to-back chip-select cycle in mode 1, or a half-bit sampling margin in mode 0, which is exactly the kind of question a logic analyzer on SPI21's SCLK, CS and MISO answers in a minute and software guessing does not. The palmtop runs the new kernel with the as-ported modules. The resets during this morning's sessions were mostly the curated startup's 150 s dead-man after its own false-positive fault check (an `OF: overlay: WARNING` line), rebooting through `reboot-to bootloader`; a few hard resets with no record in pstore remain unexplained (`logs/morning-20261029.md` item 7).

**The night's test code and the partition check** (the maintainer's points 4 and 5 on #138):
- bring-up branch: [linux-omarchy-mobile#137](https://github.com/derekross/linux-omarchy-mobile/pull/137) (draft, `tegu-gnss-spi-bringup` on the owner's fork, head 8d77391d9, on top of the two kernel fixes): the gnssif_spi driver as ported (bb9999570), then one commit per variant in the order of the tries: 32-byte reads (401016f37), spi_mode and speed_hz (21cea1dd0), 32-bit words (45b492116), 60-byte pieces (7eec92532), w32p32 (c5223f5fc), the `fb_delay`/`cs_setup_us`/`osc` parameters with the USI3 mux write (cc78f333d), 8-bit words (840cac155), `hs` (e497c8be0, f8013d08b), the USI3 divider hold of the twenty-fourth try (b587e76f4), `rx_cpha`, the per-transfer `spi->mode` switch (f2dcd5241), `hold` (e8d4d64e2), `realign` 1-3 and `txshift` (b5229f35d, ff0eadd34, dacf3e304, a0877abc3), and the morning's `piece`, `carry`, `rx_gap_us`, the byte dump, `tx_gap_us`, padded writes, `psr` and `cs_hold_us` (dae13a1f9 to b8c423dda); the pdma1 ID probe and the runtime PL330 memcpy module (5f786c818, 288a87ecc); the feedback-delay-0, auto-CS, pdma1 and pdma1-swapped overlays (4d5548b4d); the g7 scripts and the offline CRC and bit-offset checks (8d77391d9). There was no separate USI3 mux-and-divider module: the mux write is the `osc` parameter and the divider hold the `div` parameter inside gnss_spi. Each test DTB and each of the morning's images reached slot B through our `bin/omamobile push`, run by a local wrapper that first runs `bin/omamobile images` with the base DTB and the overlays; `push` writes the `_b` images with `dd`, verifies them by sha256 and reboots with `reboot-to omamobile`. Never fastboot.
- partition check (2026-10-29 10:20, after the night's sessions and resets, release `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`): `efs`, `efs_backup`, `modem_userdata`, `persist`, `modem_a` and `modem_b`, each found by `PARTNAME` and read with `sha256sum` only, all match the 10-28 read-only backup (`tegu-protected-post-android-20261028T174253Z`, off-repo), all `ro=1`, none mounted. The boots from 07:34 to 09:19 local, the morning's tries among them, ran before this check, so it covers them and their resets too; the next modem session starts from this baseline.

**Stock's SPI configuration, read from the sources (2026-10-29, afternoon; no
hardware).** Three things settle what stock does on this link, none of which
the tries above reproduced together:

- The board overlay (the private capture, fragment@110) gives the GNSS node
  `swap-mode = <1>`, `spi-max-frequency = <3125000>`, `controller-data {
  samsung,spi-feedback-delay = <0> }`, no `cs-gpios`, no `dma-mode` (the
  SoC dtsi has the `dmas` line commented out: stock runs this SPI in PIO),
  and no `samsung,spi-chip-select-mode`.
- Google's `spi-s3c64xx.c` (google-modules/soc/gs at 183509aff980) makes
  `cs_mode = AUTO_CS_MODE` the default when that property is absent
  (`s3c64xx_get_slave_ctrldata()`), so stock drives chip select from the
  controller (`SLAVE_SEL |= SLAVE_AUTO | NSC_CNT_2`): nCS asserted by the
  hardware for the packet count and released with a two-clock inactive
  gap, never by software around each transfer. Our zumapro port uses
  manual native chip select (the SPI core asserts and releases it around
  every 64-byte transfer). With `swap-mode` and 32-bit words Google's driver
  programs `SWAP_CFG` (TX and RX byte and half-word swap); mainline has no
  swap support and our 32-bit tries swapped in software.
- Our running tree's node has `samsung,spi-feedback-delay = <2>`; stock's
  is 0.
- The gnssif port itself is byte for byte Google's (`gnss_link_device.c` and
  `gnss_spi.c` differ from google-modules' gnssif_spi only by one include;
  `gnss_main.c` by the platform glue), so the protocol handling, the
  `gnss2ap_spi` ready handshake included, is stock's. Everything that differs
  is in the SPI controller driver and the node.

The "auto CS" try (`acs`, the night) ran with 32-bit words at 6.24 MHz,
before the clock fix, and no try has run auto chip select at stock's clock
with 8-bit words and feedback delay 0. That is the next boot when GNSS
resumes (G3-A, attended, one DTB round): the `autocs` and `fb0` overlays from
linux-omarchy-mobile#137 on the current kernel, 8-bit words, 3.07 MHz; then,
if the first byte of a back-to-back block still goes missing, 32-bit words
with the controller's own swap (`SWAP_CFG` as Google programs it, a small
addition to the zumapro port) rather than a software swap. No analyzer in
either.

**Parked (2026-10-29, the owner's decision):** no logic analyzer, and no more module-level guessing. The two kernel changes stay ([linux-omarchy-mobile#138](https://github.com/derekross/linux-omarchy-mobile/pull/138), the signed-off replacement of #135); the as-ported gnssif and gnss_spi run on the palmtop. GNSS resumes when either a stock capture of SPI21's timing or a new idea about the first byte of a back-to-back block turns up.

### G3-A, forty-fifth try: automatic chip select at stock's clock (2026-10-30, morning, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`)

[V] One DTB round, attended, on the charger, as the paragraph above set it
out: the gn3 DTB plus the two overlays from
[linux-omarchy-mobile#137](https://github.com/derekross/linux-omarchy-mobile/pull/137),
`gnss-spi-autocs` (the SPI node's compatible becomes `google,gs101-spi`, so
the controller drives nCS itself) and `gnss-spi-fb0` (feedback delay 0),
8-bit words at 3.07 MHz. The boot's device tree read back `google,gs101-spi`
and `samsung,spi-feedback-delay` 0. On the method: the kit's push was
refused by its `deny-hardware` guard (the hands-free tool stubs on its
PATH since 10-26), so the images the kit packed went to slot B through the
repository's own `bin/omamobile push` from a scratch checkout of main
carrying the kit's `device.conf`.

- The modem came up (`preconditions met`, `CP ONLINE`), the 12-second
  session ran, and every counter the script keeps stayed at zero: BAD
  checksum 0, ACK timeout 0, soft_dog 0, HARDFAULT 0, RX RESET-ACK 0, RX
  packet len 0; `ufshcd_err_handler` 0; `rx.txt` empty (nothing captured
  on the SPI).
- gnssd: `Modem state ONLINE`, then `state: UNUSABLE->CODELOAD tx=3 rx=3`,
  `pcie_init modem available (0)`, `state: CODELOAD->OPERATIONAL tx=1
  rx=1`, then `GNSS ASSERT: chppPlatformNotifierWait in
  STATE_PERMANENT_FAILURE`; gnssd exited, the profile logged `a service
  exited` and stopped itself. The HAL saw `lal_device_error: Connection
  lost`, `Error creating IO port` and `GNSSWaitAck: Timed out`. The kernel
  logged only CPIF's `Load GNSS images` (127.7 s) and the gnss devices'
  release (142.7 s); nothing from the SPI controller. The palmtop was
  rebooted afterwards, as the rule for a stopped profile says; no hang, no
  reset.

**Reading.** This is the failure mode already recorded for about half the
earlier tries (CODELOAD to OPERATIONAL, then the CHPP permanent failure),
reached this time without a single bad checksum, so the automatic chip
select and feedback delay 0 change the checksum picture but not the CHPP
outcome. What this round still doesn't reproduce is stock's word size: the
kernel moved 8-bit words with its own swapping, where stock moves 32-bit
words with `swap-mode` and the controller's `SWAP_CFG`. That is G3-A2, and
it needs two things built before a boot: the swap-mode Image (the
`swap-mode` property and `SWAP_CFG` by word size, commit 11ea0ef5e on the
bring-up branch, built as `logs/tegu-review-20261029/g3a/Image`, sha
ff9aceacb40286f6) and a gnss_spi variant that asks for 32-bit words and
does no software swap, which is not built yet. One session, no reset: this
was G3-A's own one DTB round, not a G3-L1 session, so the trace's cap of
three sessions and two resets is untouched. GNSS stays parked otherwise.

### G3, GNSS gets a fix (2026-10-30, evening, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`)

[V] **The receiver gets a position fix.** On the owner's kernel with the
two fixes below and stock's SPI configuration: a 3-minute session by a
window with 36 of 38 GGA sentences at fix quality 1, 13 satellites used,
HDOP 0.8; a 10-minute session with 38 of 43 fixed, 10-13 satellites, HDOP
about 1; GPS, Galileo, BeiDou and GLONASS tracked at C/N0 up to about
41 dB-Hz. CHPP clean in both: no ACK timeout, no bad checksum, no permanent
failure, no Kepler fault, no CP link isolation, no UFS error, no reset (11
minutes of uptime at the end of the long one). No position or height is
recorded here.

**Cause 1, the flush order (kernel, [linux-omarchy-mobile#150](https://github.com/derekross/linux-omarchy-mobile/pull/150)).**
`s3c64xx_flush_fifo()` cleared PACKET_CNT, and with it PACKET_CNT_EN, while
RXCH_ON was still set. For that one write the controller received with no
packet count and ran SCK freely, and with automatic chip select the slave
stayed selected and shifted out bits the flush threw away. Kepler streams
CHPP across chip-select cycles, so every transfer lost 2-6 bits: each read
arrived at a different bit offset (0, 2, 4 or 6, changing from read to read),
the data inside a read was intact, and frames that crossed reads failed
their CRC. Google's driver turns the channels off first; linux-omarchy-mobile#150 does the same.
Found by comparing Google's and mainline's transfer paths register write by
register write, after the sweep below had shown the slip per transfer.

**Cause 2, the pins: withdrawn ([linux-omarchy-mobile#151](https://github.com/derekross/linux-omarchy-mobile/pull/151), closed 2026-10-31).**
SPI21 has no pinctrl, so the bus runs on the bootloader's pin state, read
from PERIC1's pin registers on the palmtop: gpp22-0..3 in function 2 at
drive 0, gpp22-2 (data in) pulled down. Raising the drive to 3 (as gpp21,
the touchscreen's SPI) seemed to clean the data inside each read, and linux-omarchy-mobile#151
put that in the board DT. The maintainer's reading of Google's tegu tree
said gpp22 is the eSE's SPI15 (chip select on gpp22-3) and stock's SPI21
has no pin group at all, and asked for a check with linux-omarchy-mobile#150 alone at drive 0.
That boot (10-31, `DRV(0x0)` on all four pins read back from the
controller) gave 50 of 53 GGA fixed in a 3-minute session, 0 bad
checksums, 0 ACK timeouts, 0 permanent failures, and all 41 received
reads holding a frame at bit offset 0 with a valid CRC32: the same quality
as at drive 3. The improvement was linux-omarchy-mobile#150's throughout; the drive-3 run that
looked cleaner had been compared against reads with the flush bug still in
place. linux-omarchy-mobile#151 is closed, `overlays/gnss-spi-pins.dtso` stays in the tree as
a record only and is not in the palmtop's boot set.

**The configuration that works is stock's**: SPI mode 0 (stock's node has
no spi-cpha or spi-cpol), 32-bit words, feedback delay 0
([`overlays/gnss-spi-fb0.dtso`](overlays/gnss-spi-fb0.dtso)), automatic chip
select ([`overlays/gnss-spi-autocs.dtso`](overlays/gnss-spi-autocs.dtso), the
`google,gs101-spi` compatible), 64-byte reads (`gnss_spi piece=64`, one
transfer that fills the FIFO, polled whole since #138), no software realign.
**The byte swap needs no new DT property**: Google's `swap-mode` (the
controller's SWAP_CFG, commit 11ea0ef5e on the bring-up branch) works, and so
does swapping in gnss_spi (`word32=2`, commit 734f5f8c8 on
`tegu-gnss-spi-bringup`): 54 of 56 GGA fixed, 10 satellites, HDOP 1.2, no
errors, on a boot without the swap-mode property. The palmtop runs the
software swap.

**G3-L1, the L1 substates on for real (2026-10-31, one boot, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).**
The controller module's v8 bring-up build (sha256 `dbbb6f5f335f7640…`)
logs each step of its L1SS path behind `trace=1` and with `l1ss=2` enables
the substates at every link-up. The trace answered why the earlier runs
showed nothing: with `l1ss` at its default 0 the requests were dropped. With
`l1ss=2` both ends read back enabled at every link-up (root CTL1
`0x40a3200f`, endpoint `0x40a3000f`, capability at 0x160 on both). The
cycling did not stop, and that is by design: cpif's `cp2ap_suspend`
handler, the CP saying it sleeps, disables the substates in
`s51xx_pcie_save_state()` and calls `s5100_poweroff_pcie()` about 90 ms
after each enable, so the link powers down and up about twice a second as
on stock. So the substates are not what the cycling lacks. With them on,
one 240 s Location session gave 87 of 155 fixed and the palmtop survived
the session, `omamobile-gnss off`, and minutes of idle cycling, then hung
about 630 s after ONLINE (cycle 1083, last line `up: dbi allowed`, nothing
in pstore). Earlier hangs came about 170 s after ONLINE. One boot each way,
so the substates may delay the hang; they do not prevent it. The next step
is the hang inside one cycle: what follows `up: dbi allowed`.

**G3-L1, where in the power-down the SoC hangs (2026-10-31, evening, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).**
A copy of the palmtop's own cpif (the K4 build, `5a10811b940d51ff`) with
eight trace lines around `s51xx_pcie_save_state()` and
`exynos_pcie_poweroff()`, nothing else changed, and one GNSS session with the
kernel log streamed: the hang came about 11 minutes in, and the last line
before it was "master cleared" with no "config saved" after it, so the SoC
hangs inside `pci_save_state()`. cpif reads the endpoint's config space
after the CP has asked for the power-off (it is going to sleep), and an
unanswered config read on this controller hangs the SoC. A second build
keeps probe's saved config and skips every config access in that path
("kept the saved config"): that boot hung too, about 90 s after ONLINE,
after its third completed power-off ("link off") and before the next
power-on, so the next trace goes on the power-on path
(`s51xx_pcie_restore_state()` and the link-up). The save-once change alone
does not fix the hang.

**G3-L1, the power-on trace (2026-11-01, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).** With the
save-once build plus trace lines through `s5100_poweron_pcie()`, the session
went through 53 power-off/power-on cycles (the previous build 3) and then
hung; the last line was "link ack doorbell", printed after a complete
power-on (link on, config restored, MSI set, RX queues kicked), so the SoC
hung in the link-ack doorbell: the controller's `gs201_pcie_cp_doorbell()`
writes the BAR register under `cfg_lock` and reads it back. Both hangs are
non-posted reads to the endpoint (a config read, a BAR read-back). The root
port's completion timeout is enabled (DEVCAP2 `0x00010c1f`, DEVCTL2
`0x0405`: range B, 16-55 ms, not disabled), so an unanswered read should
end in an error, not a hang; a silent hang there points at the access
reaching the controller with its clocks or PHY already off (a fabric-level
hang below PCIe) rather than at the endpoint. Next: read the controller's
clock and isolation state at the doorbell (in the controller, under the
same lock), and check whether `cp_link_down()` can run from the
controller's own link-down path without `pcie_onoff_lock`.

**G3-L1, save-once plus a write-only doorbell (2026-11-01, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).**
Both changes together (cpif and the controller from the build tree of the
v8/v9 traces, which drives the PHY from `tegu-pcie0-seq.h`; the tree that
expects a separate PHY driver fails with "no PHY" and then "no PCIe
endpoint for the ROM boot"): the CP came up ONLINE, the session ran 37
power-off cycles, and the palmtop reset again, the last line right after a
power-off ("kept the saved config"). So the hang has now landed at three
different points (in `pci_save_state()`, at the doorbell after a power-on,
after a power-off). The controller's own interrupt paths are guarded (the
control interrupt is disabled synchronously and its handler checks
`cfg_root_ok` under `cfg_lock`; the MSI queue interrupts are disabled before
isolation), so the remaining suspect is an access by cpif itself to the
modem's BAR window (shared memory, doorbell or MSI registers) racing a
power-off from another path, which the controller cannot guard. Next:
instrument cpif's BAR accesses with the link state at the time of the
access.

**G3-L1, the controller's own steps traced (2026-11-01, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).**
The same pair with a trace line after each step of the controller's
`cp_link_down()` and `cp_link_try()`, the modem started after the boot's
bring-up had finished: 299 power-off cycles before the reset (the runs
before stopped after 8 to 53). The last lines: cycle 292's power-down ran
every step (interrupts off, LTSSM off, soft reset, PHY off, isolated), its
power-up trained ("L0", "settled"), and nothing after it, not even the
"link up: GenN" line, which the controller prints after one PCS write and
two DBI reads of its own registers. So the hang point moves from run to
run (inside cpif's config save, the doorbell, the start of
`cp_link_down()`, and now just after the link settles), and at least once
it is an access to the controller's own registers with the PHY powered and
the link trained. That points at something outside these two drivers
racing them, not at one bad access in their order: candidates are the
Wi-Fi bring-up module on the same boot (PCIe channel 1, its own PMU
isolation register and HSI2 parts), or a PMU or clock change from another
path. Next: one session with Wi-Fi left down for the whole boot.
(Superseded: the next run, with Wi-Fi down, still hung, and the racer
turned out to be the PERIC0 GPIO clock gate, below.)

**G3-L1, two more runs (2026-11-01, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).** With Wi-Fi left down
for the whole boot (the BCM4383 firmware moved aside, PCIe channel 1
unbound, no `wl*` interface) the session still hung, after 65 cycles, at
the same line as before ("settled"), so the Wi-Fi bring-up is not the
racer. With a trace line on each step after "settled": cycle 232's
power-up trained, the PCS PLL/bias write went through, the capability
walk over DBI returned 0x70, and the next access, the 16-bit DBI read of
LNKSTA at 0x82, never returned. So the SoC can hang on a read of the
controller's own register right after a good link-up, with no link-down
interrupt logged before it. Next: compare the controller's error-response
setup with Google's (`pcie-exynos-gs`: AXI slave error response, the ELBI
error enables), since a stalled access instead of an error response would
explain hangs at whatever access comes next.

**G3-L1, a hang with nothing touching the link, and the link held up (2026-11-01, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).**
With the controller holding `APP_XFER_PENDING` until the end of each
power-up, the session ran 147 power-offs and the palmtop reset. The kernel
log streamed over SSH and the console log that systemd-pstore keeps from
ramoops (`/var/lib/systemd/pstore/`) end on the same line: cycle 140's
power-down finished every step ("down: isolated") and nothing followed,
not cpif's return from the power-off nor the next cycle's "up: begin". So
the SoC hung while neither driver was touching the controller or the
endpoint. With cpif's `keep_link_up` set once the CP was ONLINE (the link
never powered off on the CP's request), the CP crashed about 80 s into the
session (`cp_active` dropped, ONLINE to CRASH_EXIT), after four refused
power-offs, and the palmtop did not reset. The CP needs its power-offs, so
holding the link is not a fix. With the CPU sleep idle state (PSCI core
power-down) disabled on all eight CPUs, the session ran 1070 cycles and
the palmtop reset, so core power-down is not the trigger. This time the
pstore console log kept what followed: cycle 1070's power-down finished
("down: isolated"), 360 ms later the CP's wake interrupt fired (cpif's
`cp2ap_wakeup` handler toggling irq 96's wake) and the power-up never
started (no "up: begin"). Then the SoC stalled piece by piece, not at
once: a Wi-Fi firmware query timed out at +5.5 s, ACPM's thermal channel
(9) timed out from +8.5 s ("Timeout! ch:9", "RX front can not keep up with
TX front"), and at +22 s RCU reported CPUs 0-3 and 7 stalled (detected by
CPU 5), before the watchdog reset. CPUs stuck one by one, with the APM
unanswering, is a stalled interconnect target, not one stuck access by
these drivers. One difference from stock stands out: stock's zumapro node
has no `use-phy-isol-en`, so Google's driver puts the PHY in bypass once
and never isolates it again (and sets PMU bit 10 at each power-on but
never clears it), while ours isolates the PHY and clears bit 10 at every
power-down, about twice a second. A controller that keeps the PHY in
bypass and bit 10 set between cycles (`isolate=0`, no PMU isolation write
in the whole session) still reset the palmtop, after 191 cycles; the
pstore log ends on cpif's "kept the saved config" with nothing after it,
the hang this time at once, in the power-off's PME_Turn_Off on the
controller's ELBI. So the runtime isolation is not the cause either. Next:
the RCU stall timeout at its 3 s minimum, so that a stall that spreads, as
in the CPU-sleep run, is reported with the stuck CPUs' tasks before the
10 s runtime watchdog resets the palmtop. That run reset after 47 cycles
with no stall report at all, and the pstore log ends as the CPU-sleep
run's did: cycle 47 "down: isolated", the CP's wake interrupt 373 ms
later, and no "up: begin". Two resets in a row now start at the CP's wake
with the link down and nothing after it in the log. Next: trace lines
through cpif's wake work and `s5100_poweron_pcie()` up to its call into
the controller.

**G3-L1 found: the PERIC0 GPIO clock gate (2026-11-01, night, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`).** With
those trace lines the next reset stopped inside
`mif_gpio_set_value(AP2CP_WAKEUP, 1, 5)`, and with cpif's `trace_lines`
on the one after logged the GPIO write itself as the last line. The AP2CP
lines are on PERIC0 (gpp8, gpp12, gpp16), and `CLK_GOUT_GPIO_PERIC0` is
the one writable GPIO gate in `clk-zumapro.c` (the APM and PERIC1 GPIO
gates are read-only). It runs in manual mode (`CLK_CON_GAT` 0x20b8 reads
`0x100000` between accesses), and the Samsung pin controller enables and
disables its pclk around every register access, so cpif's GPIO writes
switch the gate on and off about twice a second each way. With the clock
held on by a bring-up module (`tegu-gpio-pclk-hold.ko`), two 600 s
sessions ran 1325 and 1326 link cycles with no reset (550 of 557 and 558
of 564 fixed). Then the same change in the kernel
(<https://github.com/derekross/linux-omarchy-mobile/pull/172>: the gate
marked `CLK_IS_CRITICAL`, built into the daily kernel's tree, Image
`7f3674d21e92d758`, the release unchanged) with the palmtop's own daily
modem modules and nothing held by hand: two more 600 s sessions, 1335 and
1333 link cycles, no reset, 568 of 570 and 558 of 567 fixed. Every session
before reset the palmtop. A 30-minute session on that kernel followed: 3759 link
cycles, no reset, 1763 of 1765 fixed. That kernel is the daily kernel from now on
(the owner's kit pins that Image).

All three sessions on that kernel took the Location path, with the link
left to cycle: the modem started by hand (`omamobile-tegu-modem-up
--gnss`), Location turned on (`omamobile-gnss on`) and a client connected
for 600 or 1800 s, so `omamobile-gnss-nmea.socket` started
`omamobile-gnss.service` from omamobile-gnss 0.2.5
(<https://github.com/derekross/omarchy-mobile/pull/114>), whose 9a branch
runs the gnss-slsi profile and never writes cpif's `keep_link_up`. That is
`HOLD=0` in the bring-up scripts' terms; neither `tegu-gnss-session` nor
the hand units in `bringup/location/` were on the palmtop then. The clock
file built into Image `7f3674d21e92d758` has blob
`6a23897406017ab7aab70baf27ffa0c28be9accd`: the integration tree's
`clk-zumapro.c` with only the gate's flag changed from `CLK_IGNORE_UNUSED`
to `CLK_IS_CRITICAL`. The tree's copy was put back after the build, so
this was checked by rebuilding the object from that source: it matches the
Image's `clk-zumapro.o` byte for byte with debug info stripped, and the
unchanged file does not. At linux-omarchy-mobile#172's head (c36e4f49d)
the file's blob is `a2811b7fd001a50f0aabf86221326fae44dfe857`. The blobs
differ because the tested tree is the older integration tree; against each
base the change is the same flag on the same gate, and #172 adds a comment
above the table.

**The CP link under GNSS traffic, G3-L1's first step answered, and a
correction.** With GNSS running for minutes on the normal boot, the hang of
10-29 came back once (CLUSTER0_NONCPU_WDTRESET about 260 s into the boot,
170 s after ONLINE, after 62 fixes). cpif's `keep_link_up` (bring-up module
`cpif-keep-link.ko`, branch `tegu-cpif-keep-link`, 3f76f123b) set at load
keeps the CP from ever reaching ONLINE (`cbd exit 143 and the CP is
BOOTING`): the CP needs its link power cycles while it boots. Set after
ONLINE (the parameter is 0644), no hang followed, and that is as far as the
good news goes: in every one of the six boots that held the link (18:31 to
19:31), `cp_active_handler` saw PHONE_ACTIVE drop 103-108 s after ONLINE
(`ONLINE -> CRASH_EXIT`, the CP's own crash, nothing in the kernel log
before it, CHPP healthy: 9 bad checksums in thousands of frames), gnssd went
into crash handling and the modem profile stopped. The sessions first
reported as clean 3- and 10-minute runs were not: their 38-56 GGA sentences
are about a minute of fixes before that crash, which the counting (fixed of
total) hid. So: the hang is a link-down access while GNSS traffic flows, as
the 10-29 console reading said, and refusing the CP's power-down crashes
the CP about 105 s later. `keep_link_up` is a diagnostic, not an answer;
the answer is in CPIF's power-off path (G3-L1's trace: which BAR access
lands after isolation), so that the link may cycle as the CP asks.

**How the sweep got there** (runners in the owner's
`logs/tegu-review-20261029/runners/05-g3a*.sh`, not in git):
- G3-A2: 32-bit words with swap-mode; the first Image, built from the GNSS
  worktree, lacked the S2MPG15 regulator work (6 regulators instead of 28,
  no GNSS rails) and was rebuilt from the gn3 tree. The reads showed the
  reply frames intact but 2, 4 and 6 bits late in successive reads.
- SPI modes 0-3 (a `spi_mode` override in gnss_spi): mode 3 brought the link
  up once (24 frames), but marginally; the same boot again failed.
- Feedback delays 1-3 with mode 3: a stable offset per boot (1 or 3 bits),
  different from boot to boot.
- Software realign in gnss_spi: `realign=3` (offset found from each read's
  preamble) got 86 of 173 frames valid; `realign=4` (carrying the bits
  across reads) made it worse, which showed the stream isn't continuous
  across reads, so bits were being lost between transfers.
- The pins at drive 3: frames inside a read looked clean, offsets still
  changing (later shown to be no change: see cause 2).
- The flush order: offsets gone, link up, a fix.

**Left for GNSS:** the GNSS link driver (gnssif) and CPIF aren't in the
published kernel, so this runs on the owner's kernel only; linux-omarchy-mobile#150 merged on
2026-10-31 and linux-omarchy-mobile#151 is closed as unnecessary. The SoC
hang under GNSS traffic is fixed by linux-omarchy-mobile#172 (in review,
G3-L1 found): with it the CP link cycles as the CP asks, and sessions of
10 and 30 minutes ran clean; without it the cycling link hangs the SoC 170 s
to about 26 minutes after ONLINE, and holding the link crashes the CP. GNSS
still starts by hand
([`bringup/tegu-gnss-session`](bringup/tegu-gnss-session), which starts the
modem and runs the HAL for a set time, the link cycling unless `HOLD=1`;
once per boot), or through Omarchy's Location switch: omamobile-gnss 0.2.5
(<https://github.com/derekross/omarchy-mobile/pull/114>) with the modem
started by hand first, as in the fixed-kernel sessions, or the hand
units in [`bringup/location/`](bringup/location): two drop-ins that make
`omamobile-gnss.service` run the 9a's stack instead of the 7 Pro's chip
driver, and `tegu-gnss-start`, which brings the modem up with GNSS and runs
the gnss-slsi profile with its NMEA on the FIFO `omamobile-gnss-nmea` reads.
Tested on 2026-10-30: `omamobile-gnss-nmea.socket` enabled, a client's connect
starts the stack, the HAL serves NMEA to `/run/omamobile-gnss/nmea.sock` and
the fixes arrive (first fix about 80 s after the connect, 46 of 52 GGA
sentences fixed in the first run, with the link held and the wake line left
high, `HOLD=1`). With linux-omarchy-mobile#172 the cycling link is the
working setting, and `HOLD=0` is the script's default: an attended session
uses it. Without #172 the cycling link hangs the SoC, so don't run these
units on a kernel without it. `HOLD=1` (the link held with the wake line
high: the CP crashes 103-108 s after ONLINE) and `HOLD=2` (the link held
and the CP answered on ap2cp_wakeup: no data) are diagnostics only. The
fixed-kernel sessions went through the package's start, not this script,
so `tegu-gnss-start` with `HOLD=0` still needs its own run on that kernel.

**Precondition: no `systemd.mask=` for these units on the command line.** `systemctl unmask` can't lift a mask the kernel command line sets, so check `tr ' ' '\n' < /proc/cmdline | grep -E 'mask=omamobile-gnss'` prints nothing first: the daily bootargs mask none of `omamobile-gnss.service`, `omamobile-gnss-nmea.service` or the socket, but the older bring-up overlays (`public-native-root`, `public-phone-local`) mask `omamobile-gnss.service`.

**Attended only, and not for the daily boot.** With these drop-ins in place
any GeoClue client can start a session. Before the PERIC0 clock fix
(G3-L1, linux-omarchy-mobile#172) a session with the modem up hung the SoC
170 s to about 26 minutes after ONLINE while the link cycled, so a hang
could repeat at every boot; with the fix, a 30-minute session ran clean,
but the fix isn't merged yet. The daily boot doesn't mask these units, so
the safety net is the removal step below. omamobile-gnss 0.2.5's hang
marker (<https://github.com/derekross/omarchy-mobile/pull/114>) doesn't
cover this path: the drop-ins replace the package's start with
`tegu-gnss-start`, which writes no marker.
Install the drop-ins only for an attended session:

```sh
# install (attended, charger in, modem not started this boot)
tools/phone-ssh 'mkdir -p /etc/systemd/system/omamobile-gnss.service.d /etc/systemd/system/omamobile-gnss-nmea.service.d'
tools/phone-ssh 'cat > /usr/local/sbin/tegu-gnss-start' < device/tegu/bringup/location/tegu-gnss-start
tools/phone-ssh 'cat > /etc/systemd/system/omamobile-gnss.service.d/tegu.conf' < device/tegu/bringup/location/omamobile-gnss.service.d-tegu.conf
tools/phone-ssh 'cat > /etc/systemd/system/omamobile-gnss-nmea.service.d/tegu.conf' < device/tegu/bringup/location/omamobile-gnss-nmea.service.d-tegu.conf
tools/phone-ssh 'chmod 755 /usr/local/sbin/tegu-gnss-start; systemctl daemon-reload; systemctl unmask omamobile-gnss.service omamobile-gnss-nmea.service omamobile-gnss-nmea.socket; systemctl start omamobile-gnss-nmea.socket'
# the drop-ins stay until removed: remove them after the session
# remove (after the session; a reboot ends the modem anyway)
tools/phone-ssh 'systemctl stop omamobile-gnss-nmea.socket omamobile-gnss-nmea.service omamobile-gnss.service; rm -rf /etc/systemd/system/omamobile-gnss.service.d /etc/systemd/system/omamobile-gnss-nmea.service.d /usr/local/sbin/tegu-gnss-start; systemctl daemon-reload'
```

**The doorbell under the controller's lock didn't stop the hang.** The modem
driver's doorbell write and its read-back loop in the modem's BAR window were
the clearest unguarded access in the window (the read-back retries for up to
100 ms, and the CP can ask for the link down inside it), so the controller got
a doorbell access that runs under `cfg_lock`, the lock `cp_link_down()` takes
to clear `cfg_ep_ok` (branch `tegu-cpif-doorbell`, ee8ce0061 on the owner's
fork). With it, a 10-minute GNSS session ran 26 minutes into the boot before
the same hang (`CLUSTER0_NONCPU_WDTRESET`, the console ending mid-cycle right
after `wake enabled for irq 96`), so the doorbell is not it, or not all of it.
What is left in that window: the MSI set-up and `s51xx_pcie_restore_state()`
on the way up, CPIF's own status reads, and the cycle itself (PHY isolate and
un-isolate twice a second, each with its PMU write through the secure
monitor). The trace of G3-L1 is the next step, now with the doorbell ruled
out.

**The CP link, three ways, none of them good (2026-10-30 night, same
kernel plus the doorbell commit).** `keep_link_up` now takes a value, and
each one fails differently, which between them says what the link is for:

| cpif `keep_link_up` | What the link does | Result |
| --- | --- | --- |
| 0 | cycles twice a second under GNSS traffic | fixes arrive; the SoC hangs. About 170 s after ONLINE without the doorbell commit (five boots); with it, one session reached 26 minutes of uptime before the same `CLUSTER0_NONCPU_WDTRESET`, the console ending mid-cycle right after `wake enabled for irq 96` |
| 1 | held up, `ap2cp_wakeup` left high | fixes arrive for about a minute; the CP crashes 103-108 s after ONLINE (`PHONE_ACTIVE` drops, `ONLINE -> CRASH_EXIT`), six boots of six |
| 2 | held up, `ap2cp_wakeup` answered as the full path does | nothing hangs and nothing crashes: 16 minutes with the modem ONLINE, no isolation, no UFS error. And no GNSS at all: `gnss_spi` transferred nothing all boot, the HAL reported status 1 and 3 and served no sentence |

So `ap2cp_wakeup` is not a formality: high means the AP wants the link, and
the CP stops serving GNSS when it goes low, while leaving it high with the
link held makes the CP declare a fault. The link has to cycle, and the
answer is to make the cycling safe. The doorbell commit moved the hang from
170 s to 26 minutes, so that access was one of the unguarded ones but not
the last. What is left in the window: the MSI set-up and
`s51xx_pcie_restore_state()` on the way up, CPIF's own BAR reads
(`offset_boot_indicator`, the capability and magic words, the queue
head/tail if any of them sit in the window rather than in the reserved
DRAM), and the cycle itself, each step of which writes the PMU through the
secure monitor. That is G3-L1's trace, and it is next.

**G3-L1 answered (2026-10-31 morning): the link cycled because our L1
substates were a stub, and with them the session holds.** Implemented as
Google's `exynos_pcie_rc_set_l1ss()` does for the modem endpoint, behind a
`l1ss` parameter on the controller because the modem driver's last call in
`s51xx_pcie_restore_state()` is an unconditional enable that also arrives
during the ROM boot: acting on it there stops the image download (the CP
never leaves BOOTING, `cpif` reports no PCIe endpoint for the ROM boot,
three boots of three). Set after the CP is ONLINE:

| | before (10-30 night) | with L1 substates (10-31) |
| --- | --- | --- |
| isolate/un-isolate pairs under GNSS traffic | about 2 a second, thousands in a session | 2 in the first 2.5 minutes, 7 in 5 minutes |
| the SoC hang | about 170 s after ONLINE, or 26 minutes with the doorbell fix | none |
| the CP | crashed 103-108 s after ONLINE when the link was held instead | ONLINE throughout |
| fixes | about a minute's worth | 157 of 165 GGA sentences fixed at 5 minutes, still running |

So the hang was never reached, because the link stopped being torn down.
It is not the end of the story, though, and two further runs the same
morning say why:

- **L1.2 (`l1ss_mask` 0xf, Google's value): the cycling stops and the
  session holds for minutes, then the link drops on its own.** At 325 s the
  console has `link down completion timeout (IRQ0/1/2 0x0 0x400
  0x371b1000)`, with IRQ1 bit 10 (LINK_DOWN) latched, then `s51xx
  0001:01:00.0: Unable to change power state from D0 to D3hot, device
  inaccessible` and cpif's `Can't set D3 state!!!!`: the link was already
  down when the orderly power-off began, so PME_Turn_Off could not
  complete, and the SoC went with it. Our `cp_pme_turn_off()` does ask for
  an L1 exit first, so this is the link leaving L1.2 unexpectedly rather
  than a missing exit request. CLKREQ#, which L1.2 needs to remove the
  reference clock, is the first thing to check on this board.
- **L1.1 only (`l1ss_mask` 0xa): the cycling does not stop.** Without L1.2
  the modem still asks for the link to be powered off when it goes idle, so
  the isolate and un-isolate pairs continue and the original hang came back
  at 165.9 s, with the console ending right after a link-up
  (`restore_state`, the BAR0 write, the wake-irq toggle), which is the same
  shape as 10-29 and 10-30.

A third run settles the timing question and corrects a guess of mine. With
`tpoweron` raised to Google's largest value (0xfa, 3100 us) on the theory
that the endpoint needed longer to restore its clock, the cycling did not
stop at all: the trace counted **486 link cycles by 244 s**, and the
console ends mid-cycle right after `PHY isolated`, which is the original
hang. So the 200 us Google uses for this modem (0xa1) is right, and a
longer TPowerOn makes L1.2 unusable, after which the modem goes back to
asking for a full power-off.

The three configurations, all on the same kernel and session script:

| `l1ss_mask` / `tpoweron` | link cycles | result |
| --- | --- | --- |
| 0xf / 0xa1 (Google's) | 7 in 5 minutes | 157 of 165 GGA fixed, CP ONLINE throughout, then an unexpected LINK_DOWN at 325 s and the SoC with it |
| 0xa / 0xa1 (no L1.2) | continuous | the original hang at 165.9 s |
| 0xf / 0xfa (3100 us) | 486 by 244 s | the original hang |

What the pin side says: CLKREQ# is described and applied. The overlay gives
`pcie@12100000` `pinctrl-0 = <&pcie0_clkreq>, <&pcie0_perst>` under the
name "active", and the driver selects that state before the PHY, with
gph0-1 at function 2, pull-up, drive 3 and the same through power-down. Our
`MSTR_PEND_SEL_NAK`, `DBI_L1_EXIT_DISABLE` ("use aux_clk in L1.2") and the
HW L1-exit mode all match Google's. So the configuration is not obviously
wrong, and what is left is the unexpected LINK_DOWN itself: recovering from
it instead of dying with it, and reading the LTSSM and the endpoint's L1SS
status at the moment it happens.

**And then the instrumentation showed all three of those runs were measuring
nothing (2026-10-31, later).** With the link-down capture in place, every
drop printed `L1SS_CTL1 0x0, CTL2 0x0` with `LNKCTL 0x...42`: the root
port's substate control read zero while ASPM L1 was on. Two mistakes
behind that:

- The register offsets came from Google's driver (`PCIE_LINK_L1SS_CONTROL`
  0x19c, `CONTROL2` 0x1a0). On this controller the L1SS capability sits at
  **0x160** on both the root port and the endpoint, read from the hardware
  with `pci_find_ext_capability()`; 0x19c is something else, so the writes
  landed on unrelated registers and read back as zero.
- Those registers are also behind DBI's read-only lock, which a write needs
  `dw_pcie_dbi_ro_wr_en()` to lift. Lifting it alone changed nothing,
  because the offset was still wrong.

What that means for the three rows above: the `l1ss_mask` and `tpoweron`
values never reached the hardware, so the differences between those runs
are not the substates. The one real change was plain ASPM L1 on the link
control register, which does take (`LNKCTL` bit 1 set, `0x...42`), and
that alone is what the five-minute run had. The capability's own values at
that point, read live during a session with the link up:

| | capability | CTL1 | CTL2 |
| --- | --- | --- | --- |
| root port 0000:00:00.0 | 0x160 | 0x40a30a00 (substates off) | 0x79 |
| endpoint 0000:01:00.0 | 0x160 | 0x40a30000 (substates off) | 0x79 |

Decoded, both ends support everything that is needed (read live, link up):

| | CAP | supports | CTL1 enables | TCommon | LTR threshold | TPowerOn |
| --- | --- | --- | --- | --- | --- | --- |
| root port | 0x280a1f | PCI-PM L1.1/L1.2, ASPM L1.1/L1.2, L1 PM substates | 0 (none) | 10 us | 163 x scale 2 | 57 x scale 1 |
| endpoint | 0x790a1f | the same four | 0 (none) | 0 | 163 x scale 2 | 57 x scale 1 |

So the hardware is willing on both sides and the timing fields are already
populated by whoever set them; only the four enable bits are clear. An
earlier reading of mine that the endpoint had no L1SS capability was taken
with the link down, where the whole config space reads 0xffff, and is
withdrawn.

What has and has not been made to work from userspace, with `setpci` during
a session: the root port takes the enable bits (CTL1 0x4600 to 0x460f) and
ASPM L1 in its link control (0x40 to 0x42), and so does the endpoint's link
control, but a window in which both ends' config space is readable is hard
to catch once the CP is ONLINE, because the link is down most of the time:
a 1 Hz poll missed it for 120 s, and a 50 Hz poll caught one window but the
boot ended before the measurement. Inside the driver the write belongs
right after the ATU is set, which is where the implementation puts it, and
it has not yet been observed to take effect: no readback line appeared in
three runs, so the next step is a print at the entry of
`gs201_pcie_cp_l1ss()` to see whether the modem driver's request arrives at
all, rather than more guessing about the registers. The implementation now
reads both offsets from the hardware and logs CTL1 back after writing, so
the next run says whether the substates are on rather than leaving it to
be assumed. Three mistakes of
mine on the way there, all worth recording: the module built for this
palmtop must carry `google,zumapro-pcie-cp` in its match table and treat
`samsung,sysreg` as optional (the in-tree branch has neither, so a module
built from it never binds and the modem reports "no PCIe endpoint for the
ROM boot"); a module built without `LOCALVERSION=-s2mpg15-m1` is refused as
"Invalid module format", and a plain `make drivers/.../x.o` in the shared
output tree rewrites `utsrelease.h` so later module builds inherit the
wrong release; and the controller needs `allow_hw=1`, which an edit to the
start script's insmod line must not drop.

**Every register path in the cycling window, audited from the source
(2026-10-30 night, offline).** With the doorbell fixed and the hang still
there at 26 minutes, the obvious next question is which other access lands
after isolation. Reading all of them says: none that is unguarded.

- The modem driver's shared-memory reads are not in the BAR window at all.
  `mld->base` comes from `cp_shmem_get_region()` / `cp_shmem_get_nc_region()`
  (`shm_ipc.c`, `memremap()` of the reserved DRAM), so the boot indicator,
  the magic and capability words and the queue head/tail are plain DRAM and
  safe while the link is down.
- Every DBI access goes through `cp_dbi_read()` / `cp_dbi_write()`
  (`.read_dbi` / `.write_dbi` of `cp_dw_ops`), which take `dbi_lock` and do
  nothing unless `dbi_ok`. That covers the per-queue MSI handlers'
  `dw_pcie_readl_dbi()`, which fire on exactly this traffic.
- The link's own interrupt handler, `cp_ctrl_irq_handler()`, takes
  `cfg_lock` and returns `IRQ_NONE` unless `cfg_root_ok`; `cp_ctrl_irq(cp,
  false)` uses `disable_irq()`, which waits for a handler already running,
  and it runs first in `cp_link_down()`.
- Configuration space, root and endpoint, is behind `cfg_root_ok` and
  `cfg_ep_ok` under the same lock, which `cp_link_down()` clears before it
  touches PERST#, the PHY or the isolation.
- `gs201_pcie_cp_link_ok()` and `gs201_pcie_cp_dump()` read ELBI under
  `cfg_lock` with `cfg_root_ok` checked.
- The doorbell was the one exception, and it is fixed (branch
  `tegu-cpif-doorbell`, in `gs201_pcie_cp_doorbell()`).

So the remaining hang is most likely not a stray register read but
something that accumulates over the cycles themselves: about 3000 of them
in the 26 minutes that session lasted, each with a PMU write through the
secure monitor, a `phy_init()` / `phy_exit()` pair, an MSI re-arm and a
root-port window restore. G3-L1's trace should therefore number the cycles
and log each step's entry, so the console says which step of which cycle
stopped, rather than hunting a read that the audit above says is not
there. The interrupt enable and disable calls are paired behind
`ctrl_irq_on` and `msi_irqs_on`, so a plain enable/disable imbalance is
out.

**Why the link cycles twice a second at all: our L1 substates are a stub
(2026-10-30 night, offline).** `gs201_pcie_cp_l1ss()` in our controller
returns 0 and does nothing; its own comment says L1 substates are never
enabled on this link. The modem driver asks for them after every link-up
(`s51xx_pcie_restore_state()` calls `s51xx_pcie_l1ss_ctrl(1, ...)`), and
Google's driver implements that call: `exynos_pcie_rc_set_l1ss()` finds the
endpoint's L1SS capability and writes `PCI_L1SS_CTL1`/`CTL2` and the link
control register on both ends, for the Samsung modem endpoint among others,
behind a `use_l1ss` property in its device tree.

So on stock the modem can park an idle link in L1.2 and keep it up; on ours
the only way it can save power when it goes idle is to ask the AP to power
the link off, which is exactly the isolate and un-isolate pair we see about
twice a second under GNSS traffic. That is not a symptom of the hang, it is
what makes the hang reachable in minutes: every cycle is another chance at
whatever breaks, and the console shows the hang falling inside one.

That gives the next kernel change after the trace: implement
`gs201_pcie_cp_l1ss()` for real, as Google does, so an idle link parks
instead of being torn down. If the cycling stops, the hang stops mattering
for a GNSS session even before its root cause is found, and the
`keep_link_up` diagnostic can be dropped. The registers to write are the
root port's and the endpoint's `PCI_L1SS_CTL1` and `CTL2` plus
`PCI_EXP_LNKCTL`'s ASPM bits, with the endpoint's capability found through
`pci_find_ext_capability(..., PCI_EXT_CAP_ID_L1SS)`; it needs the link up
and the ATU set, which is why Google defers the request until then and
keeps a pending mask.

The bring-up start script
[`bringup/omamobile-tegu-modem-up`](bringup/omamobile-tegu-modem-up) loads
`cpif-keep-link.ko keep_link_up=0` and `gnss_spi.ko word32=2 piece=64
spi_mode=0`.

### Suspend with the modem on (2026-10-27, early morning, same kernel)

- **What ran:** s2idle on `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`
  with the CP ONLINE (CPIF, cbd and rfsd up, no SIM), the bring-up's usual
  modules loaded (AoC, Wi-Fi, Bluetooth, NFC) and neard polling for tags.
- **What happened:** the palmtop didn't wake from that sleep. It came back
  only after Power was held, at 06:44; the journal kept nothing from the
  sleep itself.
- **What it was:** later the same morning, with the modem off, a suspend
  with neard polling reset the palmtop too. With polling stopped (the
  `omamobile-tegu-nfc` sleep hook, on the palmtop only for now), 35 s2idle
  cycles with 20-30 s RTC wakes on 2026-10-27, in three runs of 3, 12 and
  20 through `systemctl suspend`, all woke. A fourth run's fourth resume
  lost the UFS link, a separate problem since fixed (kernel PR #83). NFC
  polling alone explains the failure, so the modem's part in it is
  unknown: suspend with the modem on is still unqualified on the 9a
  (AGENTS.md, "Suspend and modem").

NFC across s2idle (2026-10-28, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`):
with polling stopped by the sleep hook, the palmtop wakes, but NFC doesn't
work afterwards. The first send after the wake gets no I2C ACK (`nxp-nci_i2c
25-0008: NFC: Error -6 on I2C send`, also after the driver's 110 ms retry),
and every NCI request then times out. Powering the adapter off and on
through neard (a fresh NCI init) brings it back (#132). A hook that stops
the poll loop and powers the adapter off before the sleep, and on after it,
was tried once that day with an RTC wake: the palmtop didn't wake and
needed the power key. Whether the power-off took effect isn't known: the
hook discarded neard's errors, and none of the journals kept from that day
shows that sleep. The stop-poll hook stays until a power-off hook that checks
`Powered` wakes in attended runs.

NFC's silence is idle, not s2idle (2026-10-29, the same release
`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty` as the day before,
so the release doesn't tell the builds apart: the 10-28 runs had the earlier
modules, the set-config from linux-omarchy-mobile#100 and no NFC mode; the
runs with the fix below had `drivers/nfc/nxp-nci/core.c` blob
`77fc35b61da5`, the head of
[linux-omarchy-mobile#131](https://github.com/derekross/linux-omarchy-mobile/pull/131)).
First the power-off hook, reworked to stop the poll loop, power the adapter
off, check `Powered` and log each step, woke 1 of 1 (unattended, RTC +60 s,
the modem not started; the log read `polling=false powered=false` before the
sleep and `powered=true` after, the palmtop back after 65 s). But in that
boot NFC had already failed before any sleep (`Error -6 on I2C send` at 76 s
and 95 s, the suspend at 100 s), and it failed the same way after a plain
power off and on with no sleep: init got as far as the ST54L's proprietary
`ntf 0x107`, then the first command about 2 s later got no ACK and the poll
start timed out. The one-variable comparison, with no sleep at all
([#132](https://github.com/derekross/omarchy-mobile/issues/132)): each driver
variant powered the adapter on through neard and started polling after a set
delay.

| Driver | 1 s | 3 s | 10 s | 30 s |
| --- | --- | --- | --- | --- |
| the boot's modules | polls | NACK, no poll | NACK, no poll | NACK, no poll |
| A: no ST54L set-config | polls | NACK | NACK | NACK |
| B: 5 quick retries, 2 ms apart | polls | NACK (retries end in -6) | NACK | NACK |
| C: candidate [linux-omarchy-mobile#128](https://github.com/derekross/linux-omarchy-mobile/pull/128) | polls | no poll | NACK | no poll |

So from about 3 s of idle the first command gets no ACK, with and without the
set-config and with and without quick retries (B logged "5 quick retries,
result -6" on almost every failure). The cause: ST's HAL turns the ST54L's
NFC mode on after CORE_INIT (PROP_NFC_MODE_SET, `2f 02 02 02 01`) and then
initializes it again, and nxp-nci never did. Without that step the
controller goes silent on I2C about 2-3 s after init whenever it isn't
discovering; with discovery running it never gets there, which is why it read
cards on 10-27 and 10-28 and why it looked sleep-related. The fix is
[linux-omarchy-mobile#131](https://github.com/derekross/linux-omarchy-mobile/pull/131)
(now the palmtop's boot NFC driver). With it the palmtop polls after 3 s to
3 minutes of idle, and polled after two RTC-woken s2idle cycles, one with the
power-off hook and one without it, all with no NACK. Whether the poll loop
was stopped for the cycle without the hook isn't recorded, so that cycle
says nothing about the stop-poll rule yet (the 35 of 35 of 10-27 stand) and
must be re-run with the hook's log. Those results are from #131's first
version (`core.c` blob `77fc35b61da5`, a fixed 200 ms wait after the reset);
the merged version waits for the controller's CORE_RESET_NTF instead
(`c96704ddd480`) and was re-run the same day for six power-ons (55-60 ms
each, one 160 ms, no NACK, no timeout) and polling at 3 s and at 30 s after
power-on, no NACK. Ruled out on the way: the set-config
(A), quick retries (B; C, #128, closed), the clock pad forced on (a test
module through the kernel's SMC-backed PMU regmap, one register, 0x3e84 bit 0
set and bit 16 cleared: the NACKs went on, read back as before when it was
put back; `logs/tegu-nfc-sleep-20261029/tegu-nfc-clkpad2.c`), runtime PM and
the interrupt. So no power-off hook is needed for NFC to come back after a
wake; the stop-poll hook stays, for the reset of 10-27, which this doesn't
explain.

### Suspend with the modem on, with the sleep fixes: refused or short, and it costs the phone service (2026-11-09, night)

The first tries since 10-27, now with the UFS pin fix, C2 kept out of the
sleep and NFC polling stopped by its hook. On the charger, cable in, the CP
ONLINE and registered (home LTE, IMS voice and SMS), the modem's block
inhibitor passed on purpose with `systemctl suspend -i`, an RTC alarm armed
each time (`device/tegu/bringup/modem-sleep-test.sh`). Two kernels:
`7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty` build #100 with
the bring-up modules (four boots, 22 sleep requests), and
`7.3.0-rc6-omamobile-push1-g773b4102f5ec` with the in-tree `pcie_gs201_cp`
and CPIF (one boot, 3 requests). That second kernel is not the published
one: it is the published tip of that day (`abcd6aac51cf`) plus kernel #224,
#236 and #237 and #274's PHY config line, as in section P below, and kernel
#224, one of the sleep fixes this test rests on, was not merged. "The
in-tree build" below means it.

How it ran: five boots between 22:32 and 23:15 MST (the modem up at 22:32,
22:38, 22:44 and 22:52 on #100, and at 23:08 on the in-tree build), all on
the charger with the cable in, and all of them unattended. The owner had
gone to bed; what he had given was a standing word to keep working through
the night, not a yes for each run, and nobody was at the palmtop for any of
the five. So this was outside the 9a's sleep rule in two ways: the tests
were not attended, and they slept with the modem up. Each test boot ended
in `systemctl reboot`, and each of those stops was confirmed.

- **Nothing hung.** No reset, no silent no-wake, no UFS line, and the CP's
  state read ONLINE throughout.
- **Most sleeps are refused by CPIF.** 22 of the 25 requests failed with
  `cpif: suspend_cp: abort suspend` and `PM: failed to suspend noirq: error
  -16`: `suspend_cp()` returns -EBUSY while the CP holds `cp2ap_wakeup`
  high, and the CP raised it during the suspend sequence itself
  (`ap_wakeup_handler: cp2ap_wakeup work pending. gpio_val : 1` right after
  "Suspend prepare").
- **Three sleeps were entered, and the modem woke each within seconds.**
  Two on #100 (about 6 s and 4 s, `pm_wakeup_irq` the modem's PCIe
  interrupt and `cp2ap_wakeup`), one on the in-tree build (about 2 s,
  `cp2ap_wakeup`). So the CP's wake line does wake the palmtop from s2idle.
- **One sleep attempt, entered or refused, costs the phone service until a
  reboot.** In all five boots omamobile-sitd's requests to the CP began to
  time out within 95 s of the first attempt ("poll failed: TimeoutError")
  and never came back, on both kernels; `omamobile-sit status` went on
  showing the last state it had read, and the screen-state request
  answered "Invalid or unavailable phone request". The kernel log of the
  first attempt, the same on both link drivers: `pcieport ...: Unable to
  change power state from D0 to D3hot, device inaccessible`, then on the
  way back `Unable to change power state from D3cold to D0, device
  inaccessible` and `Data Link Layer Link Active not set in 100 msec`; the
  link driver brings the link up again (Gen3 x2), and CPIF then logs
  `s51xx_pcie_restore_state: Can't set D0 state!!!!`,
  `s51xx_pcie_send_doorbell_int: Can't send Interrupt(not setted bme_en,
  0xffff)`, `cmd reg = 0xffff`, `BME is not set`, and "link-down recovery
  requested"; on #100 the doorbell failed about 3000 times in the next 40 s.
  Our reading, not yet tested: the PCI core's system-sleep callbacks put
  the CP's root port and endpoint through D3 while CPIF, which powers this
  link up and down itself and saves and restores the endpoint's state
  itself, has the PHY down, and afterwards the endpoint's configuration
  space reads all ones to CPIF. Every `systemctl reboot` after these boots
  still logged the confirmed stop.
- **Why the CP is awake so much: nobody tells it the screen is off.** Idle
  and registered, the link came up 49 times a minute (98 `cp2ap_wakeup`
  edges, SIT indication 0906 about 51 times a minute; 25 link-ups in 30 s
  on the in-tree build too). omamobile-sitd has the request for it
  (`{"action": "screen-state", "on": false}`: SIT 0902 with 0, and the
  indication filter 0928 with 0), and nothing in the tree sends it. Sent by
  hand it took the idle link to 3 or 4 link-ups a minute (6 to 8 edges, no
  0906), and back to 49 with it on again. With it off the five sleeps of
  that boot were still refused, so the CP's wake at the moment of the
  sleep has another source, not found yet (the Wi-Fi interface going down
  for the sleep moves the default route to `rmnet0`, and sitd polls every
  30 s).
- **A refused sleep can cost Wi-Fi too.** systemd tries its sleep states in
  turn (`mem`, which is s2idle here, then `freeze`), so CPIF's refusal was
  followed 0.5 s later by a second attempt, in which `brcmfmac` failed to
  suspend (`error -5`) or lost its interface; the Wi-Fi hook then logs
  "Wi-Fi lost across sleep; unloading it around sleeps until reboot". With
  one state only (a runtime `SuspendState=freeze` drop-in for the test)
  Wi-Fi was still lost at the second refused sleep on #100, and stayed up
  through one entered and two refused sleeps on the in-tree build.

So the inhibitor `omamobile-tegu-modem-up` takes is not only about a hang:
until the link survives a sleep, a suspend with the modem up cuts the phone
service off, silently, until the next reboot. What M6's sleep part needs,
in order: the CP's PCI devices kept out of the PCI core's system sleep (or
their state restored after it), which is kernel work on the shared link
driver and so the 7 Pro's too; the shell telling sitd the screen state, so
the CP is idle when a sleep starts; one sleep state in the device's
`sleep.conf`; then the qualification itself (RTC wakes, a call and a text
waking the palmtop).

The sleep state is in `omamobile-device-tegu` 0.2.15: `SuspendState=freeze`
in its `sleep.conf` drop-in, so systemd writes `/sys/power/state` once per
sleep (omarchy-mobile#619). Tested on 2026-11-10 with the modem off, the
line coming from a drop-in in `/run/systemd/sleep.conf.d` (removed after
the test), on `7.3.0-rc6-omamobile-push1-dbg-gff4fdf58035e`:
`systemd-analyze cat-config systemd/sleep.conf` showed
`MemorySleepMode=s2idle` and `SuspendState=freeze`, and one
`systemctl suspend` with a 25 s RTC alarm logged
`PM: suspend entry (s2idle)`, lasted 30 s by the RTC and woke on the alarm
(wake irq 53), with `suspend_stats` success 0 to 1, fail 0 to 0 and no UFS
error lines. It doesn't settle the Wi-Fi loss above, which also happened
with one state.

### M2: the link only (modem link driver, `allow_hw=1`; risk: medium)

One step per run, the CPIF overlay not applied, the link overlay applied
by its activate module.

| Step | What | Pass | Stop / rollback |
| --- | --- | --- | --- |
| M2.0 | bind, no hardware access | "2 lanes, steps disabled"; status: lines as M0.3, PMU 0x3ec4 0x0 | any controller read; rollback: reboot (no unload test yet) |
| M2.1 | `cp_on`, then `cp_off` (lines only, ~130 ms) | outputs 1 then 0; cp2ap-wakeup → 1 within 2 s (cheetah M2.1) | UFS handler pass; rollback `cp_off` |
| M2.2 | PMU 0x3ec4 bit 0 round trip, nothing else (as WIFI-PLAN W4a) | reads back 1 then 0 | readback mismatch: stop, reboot |
| M2.3 | `cp_on`, `link_up 1`, `id`, `link_down`, `cp_off` | "link up: Gen1 x1", LTSSM 0x11, endpoint `144d:a5a5` [I: S5300 ID as cheetah], 0x3ec4 back to 0 | "no L0" ×3: dump status, `link_down`, `cp_off`; a hang: watchdog |
| M2.4 | `bus`: host bridge, MSI at 0xf6200000, config read with the link down → all-ones | as cheetah M3.1.1-M3.1.3 | a hang on a down link: the DBI guard failed; stop |

Dead-man for M2.1-M2.4: `systemd-run --unit=x-deadman --on-active=120 sh -c 'echo link_down > …/ctl; echo cp_off > …/ctl'`,
stopped after a fresh SSH login confirms the step.

### M3: bind CPIF, no modem power (risk: low)

Blacklist first (the reinstall of `omamobile-device-tegu`), then apply the
CPIF overlay, load the link module **without** `allow_hw`, then `shm_ipc`
and `cpif`. Pass: probe without "xxx" or an Oops; `/dev/umts_boot0`,
`umts_ipc0/1`, `umts_rfs0`, `umts_router`, **`/dev/gnss_boot`**,
`gnss_dump`; 30 rmnet devices; "gnss_v_base=" logged (GNSS_FW mapped); every
AP2CP line low; PMU 0x3ec4 0x0; 60 s later nothing changed. Stop: a
"poweron" or "link up" line. Rollback: reboot (cpif is permanent).

### M4: rfsd alone on RAM copies (risk: low)

As cheetah M3.4.4 on the tegu chroot image: the five RAM copies match the
backup, the salted NV checksums match, the baseband version is recorded,
rfsd logs Touch/Verified and no Expand/Create/Clear. Stop lines and the
"never go on" list are cheetah's, unchanged. The CP stays unpowered.

### M5: first boot to ONLINE, left on (risk: medium-high)

As cheetah M3.4.5 (link at Gen1 for the ROM, BOOT image, Gen3 x2 for the
main firmware, "CP ONLINE (cbd exit 0)"), `ro.boot.cdt_hwid` from the
private capture in the per-phone props (cheetah M4.1h: without it the main
firmware hung). Pass also: no SysMMU/S2MPU fault at the first DMA (F1's
[I]); UFS count unchanged. Stop: a CP crash before ONLINE (record crash
reason and boot log, leave the CP, reboot); any NV stop line. Afterwards
M0.1 again: the real partitions unchanged.

### M6: reboot with the modem up (risk: medium)

Two reboots with the CP ONLINE, as cheetah M4.1j/M4.1k: back on its own,
no WARN, NV unchanged. Until both pass, reboot only with the human at the
palmtop. After that, the SIM stage follows cheetah's "M4.2-M4.7" runbook.

### G0: where gnssd's NMEA goes (offline; risk: none)

From V/'s `gnssd` and `gps.cfg` (strings and disassembly, offline): the
`%s/nmea` path and the HAL socket's protocol, and which `gps.cfg` keys turn
the NMEA output on. Pass: a named output the bridge can read without the
framework HAL (a FIFO or file, or a socket whose framing is known). If
none: the fallback is a small client of gnssd's HAL socket in U3.

### G1: the SPI and gnssif, CP off (risk: low)

K5/K6 on the GNSS branch; enable `spi21` and the gnssif node by overlay
after FAR-ALIVE-PLAN settles GPA5's pin 4. Pass: `gnss_spi` and `gnssif`
bound, `/dev/gnss_ipc` present, gpp2-3 output low, no gpa5-4 interrupts
while the CP is off. Stop: an interrupt storm on gpa5-4 or any change on
the WLAN/BT/TAS pins of GPA5.

### G2: Kepler firmware and first NMEA, CP ONLINE (risk: medium)

gnssd in its chroot (profile `gnss-kepler`, own `/data/vendor/gps` in tmpfs
first), started after M5's ONLINE: `IOCTL_LOAD_GNSS_IMAGE` copies
`kepler.bin` into GNSS_FW (RAM only; no partition is touched), then CHPP
over `/dev/gnss_ipc`. Pass, indoors: "codeload" without error, CHPP
discovery, NMEA sentences (GSV with satellites by 5 minutes near a window).
Stop: a CP crash (record, reboot), gnssd retrying the codeload, a UFS
event. Rollback: stop gnssd; the CP stays on. **Open: gnssd opening
`umts_ipc0`** while our SIT client holds it (check in G0 whether it does
without SUPL/control-plane assistance; if it does, give gnssd the SIT
channel only through the SIT client, or keep the SIT client off for G2).

### G3: Location on demand, outdoors (risk: low)

U3 installed: the Location tile starts gnssd through the package, NMEA
reaches gpsd and GeoClue, GNOME Maps shows a fix outdoors. Pass: a 3D fix,
HDOP recorded, gnssd stopped when Location is off (the CP stays on).

### G4: settings (risk: low)

Constellations, SGEE/assistance over the network (gnssd uses libcurl),
power: as cheetah's GNSS-PLAN section 7, adapted to gps.cfg's keys.

### P: publishing the 9a's modem link (offline; risk: none until a boot)

GNSS and the modem run only on the owner's kernel: the link driver
(`tegu-pcie0-cp.ko`) and cpif are out-of-tree modules built against it.
The gs201 versions of both are in review as
<https://github.com/derekross/linux-omarchy-mobile/pull/144> (the 7 Pro's
curated modem stack, `pcie-gs201-cp.c` and `drivers/soc/google/cpif`), and
the 9a's link driver began as a copy of that controller, so the 9a goes in
as a second compatible of the same driver, stacked on #144, not as a new
driver. What `google,zumapro-pcie-cp` has to add, from a diff of the two
(2026-11-01):

- **PHY:** no PHY driver on zumapro: channel 0's sequences run from tables
  (power-down clear, configuration, power-down; `tegu-pcie0-seq.h`, from
  Google's GPL zuma CAL), plus the host's channel 0 extras: SOC_CTRL
  0x4000 = 0x15, PMU PHY control bit 10 set at power-on, UDBG 0xC800 bits
  6:5 cleared, PMA 0x32C = 0, PCS 0x150 = 0x300d5 after training.
- **iATU:** no secure-ATU SMC: the host writes the unrolled outbound iATU
  (DBI + 0x300000): region 0 CFG0 to bus 1 at the config window, region 1
  the first 2 MiB of the memory window.
- **APP_XFER_PENDING** (ELBI 0x74) raised before training and dropped at
  the end of link-up; two lanes set in the port logic.
- **No clocks:** stock describes none, and a read of CMU_HSI1's PCIe gate
  hung the SoC (M0.4).
- **PHY isolation:** set bypass once and keep it, as stock (no
  `use-phy-isol-en` on zumapro); the experiments ran both ways (G3-L1).
- **The doorbell** as a posted write under `cfg_lock` with no read-back
  (G3-L1), which suits gs201 too.
- Left out: the L1 substates parameters and the cycle trace, bring-up
  only.

The device tree: HSI1 GEN3A_0 and the modem node from
`device/tegu/overlays/tegu-modem-link.dtso` and `tegu-modem-cpif.dtso`
into `zumapro.dtsi` and `zumapro-tegu.dts`, and the binding extended.
The PERIC0 clock fix (#172) goes in first. Test: a published-style kernel
from #144 plus this, cpif built in-tree, then the G3 session runbook.
The driver and binding are drafted as
<https://github.com/derekross/linux-omarchy-mobile/pull/173> (stacked on
#144, `W=1` and checkpatch clean, not booted yet); the DT nodes follow once
#144 is on `omamobile`, whose zumapro board DT the stack's base lacks.

**P, run on the palmtop (2026-11-09, `7.3.0-rc6-omamobile-push1-g773b4102f5ec`, on the charger).** The modem and GNSS from the in-tree drivers, on a kernel that is the published tip plus four things that were all still open that day, so not yet what a build from the tree gives: `omamobile` at `abcd6aac51cf` plus linux-omarchy-mobile#224 (the UFS pin state), #236 (the main PMIC's interrupt) and the 9a's GNSS nodes (the SPI device on `spi21` and the handshake node, linux-omarchy-mobile#237), built with defconfig, `kernel/configs/omamobile.config`, `CONFIG_PHY_ZUMA_PCIE=m` (#274) and `CONFIG_EXYNOS_GNSS_IF_SPI=m`; the published `zumapro-tegu.dtb` with `device/tegu/overlays/modem-cpif.dtso` from the descriptor's `DTB_OVERLAYS` (and a ramoops overlay for the test). The board's device tree has only the `modem` node under the PCIe link, which the link driver would use; the overlay disables it and adds CPIF's `cpif` and `cp-shmem` nodes, the published form of the bring-up `tegu-modem-cpif.dtso` with paths instead of labels, so the bring-up activation module isn't needed.

- **The start.** #372's boot unit (`omamobile-tegu-modem-up --phone --gnss`, enabled on the owner's palmtop) took its in-tree branch by itself on four boots ("drivers: the running kernel's": `modprobe pcie_gs201_cp allow_hw=1`, `shm_ipc`, `cpif`, `gnss_spi`, `gnssif`): CP ONLINE 8 s after the unit started, the phone service and the bridge up, registered at home on LTE, `/dev/umts_ipc0` and `/dev/gnss_ipc` there, no UFS error-handler pass, Wi-Fi up beside it.
- **The stop.** `systemctl reboot` with the modem up: "CP OFFLINE", then "modem stopped (success, the CP OFFLINE before the daemons went)", the latch removed; the next boot, with the unit masked, started nothing and left no latch.
- **GNSS.** Four 150 s sessions through the Location switch's socket, indoors by a window: 108 of 113, 142 of 143, 105 of 107 and 142 of 144 GGA sentences with a fix, up to 24 satellites; each session's service stopped on its idle lease with the marker gone and the CP still ONLINE.
- **The GNSS bus keeps zumapro's SPI port configuration.** The first two sessions ran with the bus on gs101's compatible alone (the controller's automatic chip select, as stock uses for this device): spi-s3c64xx then cut every 64-byte block into 60 and 4 bytes, and 12 of those reads timed out (`I/O Error ... len-4 ... res-(-110)`, then `len-60`) in 13 minutes. With zumapro's compatible kept (a 64-byte block in one piece, polled; the chip select held per message) the other two sessions and 10 minutes of the modem's link cycling logged none. The feedback delay is stock's 0 in both.
- **The handshake pins as the bootloader leaves them.** The tree's GNSS nodes give the two handshake lines no pin group (linux-omarchy-mobile#237), so they run on what the bootloader set. Read on 2026-11-10 from the pin controllers' debugfs `pins` files, one controller per read, on `7.3.0-rc6-omamobile-push1-dbg-gff4fdf58035e` (the published tree plus #224, this overlay applied, the modem unit masked, so before any GNSS driver had requested them): gnss2ap_spi, `pin 4 (gpa5-4)` on `154e0000.pinctrl`, `CON(0x0) DAT(0x0) PUD(0x1) DRV(0x0)`, an input with the pull-down, which is stock's pull; ap2gnss_spi, `pin 12 (gpp2-3)` on `10840000.pinctrl`, `CON(0x0) DAT(0x0) PUD(0x1) DRV(0x0) CON_PDN(0x2) PUD_PDN(0x1)`, an input with a pull-down, where stock's group has an output with no pull at drive 0. The driver makes gpp2-3 an output when it loads, and nothing in the tree sets its pull, so the four sessions above most likely ran with that pull-down under a driven line. Not read: the two pins with the drivers loaded.
- **The guards.** With the nodes in the device tree udev loaded `gnss_spi` and `gnssif` on a boot without the modem; `omamobile-device-tegu`'s guards now blacklist them with CPIF's modules, so only the modem start loads them. Checked on a boot with the unit masked and the package with the new lines installed: the `cpif`, `/gnss` and SPI device nodes there, none of the five modules loaded, no latch; on the boots with the modem the starter loaded all five by name.
- **A call, data and the NV check.** On the fourth boot by the unit: an incoming call, accepted through the bridge, active for 8 s, hung up, the release confirmed 272 ms after the hang-up (omarchy-mobile#461), the CP ONLINE after; `omamobile-sit-data` brought `rmnet0` up and three of three pings went out over it; `omamobile-sit status` on each boot read SIM ready, home LTE, IMS voice and SMS, data bearer up. Three `systemctl reboot`s with the modem up were each confirmed. After all of it `tools/nv-backup -d tegu --check` read efs, efs_backup, modem_userdata, persist, modem_a, modem_b and metadata SAME as the 2026-10-28 backup (devinfo different, as expected). Texts, later the same evening on a sixth boot of this kernel (the modem up at 20:37 MST, the texts at about 20:40): one sent from the palmtop with `omamobile-sit sms send` (`AIMS_SEND_SMS`, error 0) arrived on the owner's phone, and his reply reached the palmtop 22 s after the send ("SMS stored and acknowledged", then the bridge's `SMS/0 received`).
- **What a build from the tree has, and when.** Of the four, kernel #236 and #237 and the PHY's config line (#274) were merged on 2026-11-10, and this overlay with the GNSS link driver's config line (#594) on 2026-11-11 (UTC). So a 9a kernel built from the tree from then on has everything the in-tree start needs: the `cpif` node from this overlay, `phy_zuma_pcie` and the two GNSS modules. Only kernel #224 is open, and the modem and GNSS don't need it: it is the UFS pin state, a sleep fix.
- **Who was there.** Six boots by the unit on this kernel, by the palmtop's journal: the modem up at 18:32, 18:50, 19:12, 19:26, 20:26 and 20:37 MST. The first two ran with the owner out of the house, watched only over SSH from the laptop; that includes the first start of the link driver with `allow_hw=1` through the starter. The third ran with him home again but not at the palmtop. The fourth was the call: he rang it from his own phone and saw its screen take the call. The fifth and sixth he was at the laptop for, and the texts on the sixth went to and from the phone in his hand. Each boot was on the charger with the cable in.
- **On the owner's daily kernel (build #100) the overlay doesn't apply, and nothing changes there.** That kernel's base DTB is the integration tree's, with no `modem` node under `pcie@12100000`, so `fdtoverlay` fails on it with `FDT_ERR_NOTFOUND` (tried on the laptop, 2026-11-10); it is built by the owner's kit with the kit's own overlay list, not this descriptor's. Its running tree has a disabled `modem` node, `cpif` and `cp-shmem` all the same, from the bring-up overlay, and its module tree has none of the CP drivers (`modinfo cpif`: not found), so the starter takes the bring-up modules there ("drivers: the bring-up modules in /var/lib/omamobile-tegu/modem", read on 2026-11-10).

### SIM test (M-SIM), 2026-11-03 (gated runbook, written 2026-10-29)

**The runbook to follow when the SIM arrives:** a prepaid physical nano-SIM
from the carrier, PIN lock off, activated in another phone. It is
cheetah's "M4.2-M4.7: the first SIM test" (cheetah MODEM-PLAN) with the
9a's names and gaps, in raven's order (SIM, registration, data, SMS;
raven's D-series is the only run of calls, texts and data on a Tensor phone
here). Every step has its command, Expect/Pass, a stop condition, a
rollback and a risk; the read-only steps come first. The human runs or
approves each step. Two rules above all. **A second CP start in the same
Linux boot stalls in the ROM (M5 results), and nothing may restart or stop
the modem in place (AGENTS.md, "Suspend and modem"; a profile stop by hand
hard-reset the palmtop once, M5 results above, "gnssd's exit took the modem
down"): after any failed step, an attended reboot, whose shutdown runs the
unit's stop, then start again from SIM-5.** And **the session's budget is
one reboot cycle beyond the final one: one hang or unexpected reset ends
the session for the day.** This is the riskiest session the palmtop has
had (a SIM, a transmitting radio, an unqualified power-off path), so the
room for retries is smaller than the GNSS sessions had.

Preconditions, as SLEEP-PLAN's:

- **Slot B.** Stop if slot B isn't marked successful; this runbook doesn't
  mark it (marking is a `devinfo` write, on hold on the 9a: AGENTS.md,
  "Pixel 9a: a fallback to slot A costs the Linux root", from
  <https://github.com/derekross/omarchy-mobile/pull/125>). An unmarked B
  burns an ABL retry on every boot, and a reboot cycle, a power-off round
  or a hang each count as one; at zero, ABL boots stock on slot A and the
  Linux root is gone.
- **The modem package is a real install** (SIM-1): not the palmtop's
  `omamobile-modem` 0.1.4 with newer profile files copied over it by hand.
- **Charger in** for the whole session, Wi-Fi up (the default route stays
  on Wi-Fi), another phone at hand, and nobody calls the palmtop's number
  during the test (SIM-10).

**What the 9a has and lacks for this test (checked on the palmtop,
2026-10-29 night):**

| Piece | State | What it means here |
| --- | --- | --- |
| Modem to ONLINE | `omamobile-tegu-modem-up` from `omamobile-device-tegu` (#372; before it, a bring-up copy in `/usr/local/bin`): once per boot, refuses a second start and a boot that finds the latch, arms the sleep inhibitor `omamobile-tegu-modem-nosleep`; `omamobile-tegu-modem-boot` runs it at boot when enabled (TELEPHONY-PLAN 2.7) | the start is this script, not `omamobile-modem.service`, which is `masked-runtime` on the palmtop; the transient unit's ExecStop (the profile's stop, which powers the CP off) runs at shutdown, so the way to stop the modem is an attended reboot, never a stop by hand |
| NV safety | `pacman -Q` says `omamobile-modem` 0.1.4, but the profile files under `/usr/lib/omamobile-vendor` were copied by hand from newer trees (the 27th GNSS try ran 0.1.9's watcher; 0.1.4 predates the 9a's chroot support), so `pacman -Qkk omamobile-modem` is not clean; `/etc/omamobile/modem-nv.sha256` from the 2026-10-28 backup; the profile's `check` runs inside the start script | the NV checks live in that profile, so SIM-1 installs the package from main for real and records the version and the profile's sha256; a stock boot since 2026-10-28 would make `check` refuse; then a fresh read-only backup and a new checksum file come first (AGENTS.md §1) |
| The RIL | `omamobile-modem-sit` 0.3.3 installed 2026-10-29 (SIM-1), both units disabled; 0.3.4 (<https://github.com/derekross/omarchy-mobile/pull/156>) reads the CP state on one open file | 0.3.3's watcher opens and closes the boot device about thirty times a minute, and that cycles the CP link on the 9a (the 10-29 hangs); the run uses 0.3.4 (SIM-1). Its unit `Requires=omamobile-modem.service`, which is masked here, so `systemctl start omamobile-sitd` would fail until SIM-2's unit copy removes that requirement (done 2026-10-29) |
| The bridge for apps | `omamobile-mmd` not installed | not part of this test (T2 follows a passing run) |
| The link watcher | `omamobile-modem` 0.1.9 (<https://github.com/derekross/omarchy-mobile/pull/148>) keeps one open file on the boot device, which retires the old open-and-close watcher that woke the CP link every half second; 0.1.10 (<https://github.com/derekross/omarchy-mobile/pull/163>) adds the once-per-boot refusal | with the CP ONLINE the link idles and cycles on its own; on 2026-10-29 the palmtop hung eight times in a morning with the modem up for hours, the early ones tied to the watcher's open and close of the boot device (the console logs end on CPIF's `cp2ap_wakeup` wake toggles; `logs/tegu-review-20261029/hangs/`). The run uses 0.1.10 (SIM-1). Keep the session short (under an hour) and attended; `cpif-keep-link.ko` (G3-L1 step 1, untested) is the candidate fix, not part of this run |
| Call audio | the AoC card is `google,tegu-aoc-snd-card` with its EP PCMs, but `omamobile-speaker-protection` is inactive and the amplifiers are TAS2572, which `voice_audio.py`'s earpiece checks (CS35L41 controls) don't know | **no audio routing exists on the 9a: calls are not part of this test.** `[audio] card = none` stays; a signalling-only call (cheetah's S10) is a later, separate step |
| Suspend | unqualified with the modem on (section "Suspend with the modem on"); the start script's inhibitor blocks `systemctl suspend` for the boot | charger in for the whole test |
| Identifiers | the ICCID (printed on the card), IMSI, IMEI, phone number, the carrier's name, its APN, IP addresses and message text never go into the repository, a log excerpt or a screenshot | sitd logs states and codes only; before quoting a log: `grep -nE '[0-9]{7,}|\+[0-9]|[0-9a-f]{2}(:[0-9a-f]{2}){5}|@' logs/<file>` must show nothing you would quote |

**What to expect, honestly:** SIM detection likely (GET_SIM_STATUS has
answered on this CP since M5); LTE registration likely on
this network (the start-up order registered cheetah on it); data likely if the
bearer has IPv4 (`rmnet` is IPv4 only); IMS and so SMS possible (proven on
that one network); emergency calls never (refused by the RIL; keep another
phone). About one fresh CP start in twenty crashed during registration on
cheetah: a crash is recorded, a reboot recovers it.

```sh
# SIM-0 laptop, before the SIM (risk: none). The package and its tests, on main.
packages/omamobile-modem-sit/test/all && tools/pr-check
#   pass: all ok. Nothing on the palmtop changes.

# SIM-1 real package installs, palmtop without the SIM, modem not started this boot (risk: low; nothing starts)
tools/phone-ssh 'test -d /sys/module/cpif && echo cpif-loaded || echo cpif-not-loaded; systemctl is-active omamobile-tegu-modem'
#   pass: cpif-not-loaded; inactive.  stop: cpif-loaded or active: the modem ran this boot; reboot first
#   the modem profile: a real install from main, not the hand copies. 0.1.10 once #148 and #163 have merged
#   (the single open file instead of the open-and-close watcher, and the once-per-boot refusal); if they haven't
#   by 11-03, main's 0.1.8 with the hand-copied 0.1.9 profile is NOT acceptable either: record why and wait
#   (0.1.8 starts the old watcher unconditionally, so it can't be turned off without a hand edit)
tools/phone-install-package packages/omamobile-modem
tools/phone-ssh 'pacman -Q omamobile-modem; pacman -Qkk omamobile-modem && echo pkg-clean; sha256sum /usr/lib/omamobile-vendor/profiles/modem.conf'
#   pass: omamobile-modem 0.1.10; pkg-clean (no file altered); record the version and the profile's sha256 in this
#     plan's record block. stop: Qkk reports altered or missing files: find the hand copy, reinstall, repeat
#   the RIL: 0.3.4 (#156, the CP state on one open file); 0.3.3 is on the palmtop since 2026-10-29 and would
#   cycle the link about thirty times a minute
tools/phone-install-package packages/omamobile-modem-sit
tools/phone-ssh 'pacman -Q omamobile-modem-sit; systemctl is-enabled omamobile-sitd omamobile-sit-data; ls /etc/omamobile/modem-sit.conf;
  diff <(sed -e "/^Requires=omamobile-modem.service/d" -e "s/omamobile-modem.service/omamobile-tegu-modem.service/" /usr/lib/systemd/system/omamobile-sitd.service) /etc/systemd/system/omamobile-sitd.service && echo unit-copy-current'
#   pass: 0.3.4; disabled x2 (nothing starts at boot); the conf exists; unit-copy-current (SIM-2's copy still
#     matches the package's unit: the copy in /etc is temporary and hides future package versions, so re-check
#     it after every upgrade of omamobile-modem-sit, and redo SIM-2 if it differs)
#   rollback: pacman -R omamobile-modem-sit; the modem package stays (it is what main ships)

# SIM-2 wire sitd to the 9a's modem start, and the APN (risk: none; nothing runs)
#   omamobile-sitd.service requires omamobile-modem.service (cheetah's start), masked on the 9a. A drop-in can't
#   drop a Requires= (systemd never resets a dependency list to empty; checked on the palmtop 2026-10-29: the
#   drop-in left Requires=omamobile-modem.service in place), so the unit is copied whole into /etc with that line
#   removed and omamobile-tegu-modem.service, the transient unit the 9a's start script creates, in its place.
tools/phone-ssh 'u=omamobile-sitd; sed -e "/^Requires=omamobile-modem.service/d" \
  -e "s/^After=\(.*\)omamobile-modem.service/After=\1omamobile-tegu-modem.service/" \
  /usr/lib/systemd/system/$u.service > /etc/systemd/system/$u.service; systemctl daemon-reload; \
  systemctl show $u -p Requires -p After'
#   pass: Requires= has no omamobile-modem.service, After= lists omamobile-tegu-modem.service and omamobile-audio.service
#   (ConditionPathExists=/dev/umts_ipc0 stays); omamobile-sit-data needs nothing (it requires omamobile-sitd only)
#   done on the palmtop 2026-10-29 evening, with SIM-0 and SIM-1 (omamobile-modem-sit 0.3.3 installed, both units disabled)
# the APN: the carrier's published internet APN, typed by the human over ssh; never pasted into a log or this plan
tools/phone-ssh 'sed -i "s/^apn =.*/apn = <APN>/" /etc/omamobile/modem-sit.conf'
tools/phone-ssh 'grep -cE "^apn = .+" /etc/omamobile/modem-sit.conf; grep -E "^(ims|ims_apn|ims_required|nr|card|ip_type) " /etc/omamobile/modem-sit.conf'
#   pass: 1; ims = yes, ims_apn = ims (or the carrier's), ims_required = no, nr = off, card = none, ip_type = ipv4v6
#   stop: card is anything but none (no earpiece mode on the 9a)
#   the unit copy is temporary: it hides future package versions of omamobile-sitd.service (SIM-1 re-checks it)
#   rollback: rm /etc/systemd/system/omamobile-sitd.service, daemon-reload; apn back to empty

# SIM-3 the backups (read-only; risk: none). M0.1 against the newest backup, as 2026-10-27.
#   pass: the six partitions match, every NV partition ro=1 and unmounted.
#   stop: any mismatch, or a stock Android boot since the backup (slot A fallback): fresh read-only backup,
#     new /etc/omamobile/modem-nv.sha256, then back here. The start script's own check (SIM-5) repeats this.

# SIM-4 insert the SIM (the human; risk: low). The palmtop stays ON, in Linux, with the modem NOT started this boot
#   (SIM-1's check): with the CP unpowered the card is seen for the first time at SIM-5's power-on, which is what
#   a cold insertion gives it, and the AP has no SIM line. Eject the tray with the SIM tool (right edge, bottom),
#   nano-SIM in the tray as its outline shows, tray fully in.
#   No hot insertion with the CP up (never tried under Linux), and no power-off round unless the CP does not
#   see the card at SIM-6: a 9a boot cycle costs a slot-B try when B is unmarked, and a fallback to slot A
#   costs the Linux root (AGENTS.md, "Pixel 9a: a fallback to slot A costs the Linux root"; the precondition
#   above: B marked, one hang ends the day). Charger in from here to the end.
tools/phone-ssh 'cat /sys/class/power_supply/max77779-charger/online; systemctl --failed --no-legend | wc -l; dmesg | grep -c ufshcd_err_handler'
#   pass: 1; 0; note the UFS count (U0)

# SIM-5 streams, then the modem to ONLINE (announce: the modem powers on and stays on until the reboot; risk: medium)
tools/phone-ssh 'dmesg -w' | tee logs/tegu-sim-kmsg.log                         # terminal 2, first
tools/phone-ssh 'journalctl -f -o short-monotonic -u omamobile-tegu-modem -u omamobile-sitd -u omamobile-sit-data' \
  | tee logs/tegu-sim-journal.log                                               # terminal 3
tools/phone-ssh 'systemd-run --unit=x-modem-deadman --on-active=300 systemctl reboot'   # an attended reboot, never a stop
tools/phone-ssh '/usr/local/bin/omamobile-tegu-modem-up; /usr/lib/omamobile-vendor/omamobile-modem-cp state; dmesg | grep -c ufshcd_err_handler;
  systemctl is-active omamobile-tegu-modem-nosleep'
#   pass: "modem OK: CP ONLINE" (ROM link Gen1 x1, main link Gen3 x2, "CP ONLINE (cbd exit 0)", as M5); ONLINE;
#     UFS count = U0; the inhibitor active
tools/phone-ssh 'systemctl stop x-modem-deadman.timer'                            # only once ONLINE was seen
#   stop: not ONLINE within 5 minutes: the dead-man reboots the palmtop (its shutdown runs the unit's stop, which
#     powers the CP off: expect one UFS pass on the way down); the human is at the palmtop for it (M6 isn't
#     passed; Power + Volume Up 15-30 s if it doesn't come back); collect /var/log/omamobile/modem.log as M5.
#     "check" refused: SIM-3's stop. A hang (no SSH, no console): it ends in the cluster watchdog reset
#     (CLUSTER0_NONCPU_WDTRESET, as the eight 10-29 hangs did; RebootWatchdogSec covers only a hung shutdown);
#     wait for it, nothing more is sent to a silent palmtop, and the session is over for the day.
#   rollback: an attended reboot (systemctl reboot: the unit's stop powers the CP off during shutdown; one UFS
#     pass). Never "systemctl stop omamobile-tegu-modem" by hand: a profile stop hard-reset the palmtop once
#     (M5 results, "gnssd's exit took the modem down"), and the power-off path is unqualified until M6.

# SIM-6 the read-only probe: SIM state, radio off (risk: low)
tools/phone-ssh 'timeout 60 omamobile-sitd --probe' 2>&1 | tee logs/tegu-sim-probe.log
#   expect: every request "error=0"; "SIM card state 1 applications [(2, 5), ...]" (a USIM, READY; an ISIM (5, x)
#     may follow); radio state 3 or 1; packet registration state 0; "SMSC present True"
#   record: the application list (types and states only), radio state, NR mode. Never the ICCID or IMSI:
#     the probe prints states and codes; if a build ever prints more, don't quote it.
#   stop: card state 0 (no SIM seen: tray seated? then, and only then, one power-off round, which spends the
#     session's one spare cycle: an attended "systemctl poweroff" (its shutdown runs the unit's stop, so the CP
#     is powered off before the AP), reseat the tray, Power to boot slot B, back to SIM-1's checks. A plain
#     poweroff from Linux hasn't been tried on the 9a under our kernel: the reboot path needed reboot-to
#     (NOTES), so the final power-off call may hang the same way; if the screen is still on 90 s after the
#     units have stopped, hold Power about 30 s, and treat it as the day's hang. The bootloader-menu route
#     (Volume Down + Power about 20 s, Power off) is the fallback only if the Linux poweroff doesn't power off
#     at all); (2, 2) = PIN lock on: turn it off in another phone, never here; (2, 3) = PUK:
#     the carrier's PUK in another phone; (2, 4) = network lock: the carrier. A timeout or a CP crash: collect, reboot.
#   rollback: none (read-only)

# SIM-7 registration and IMS (announce: the radio transmits from now until the reboot; risk: medium)
tools/phone-ssh 'systemctl start --no-block omamobile-sitd'
#   watch terminal 3 up to ~7 minutes (SIM 120 s, registration 180 s, IMS 120 s). Expect, in order: the SIM
#   application list; "SIT SET_INITIAL_ATTACH_APN: error=0", "SIT SET_DATA_PROFILE: error=0"; "waiting for packet
#   registration"; "verified NR mode 0"; "data-call status 0 CID 1 active ... PDP type <n>" (record n: 3 IPv4v6,
#   1 IPv4, 2 IPv6 only); the AIMS requests "error=0"; then "Startup: LTE, IMS voice and SMS registered" OR
#   "Startup: IMS did not register (...); serving data only" (record which); "Calls and SMS service ready"
tools/phone-ssh 'omamobile-sit status; systemctl is-active omamobile-sitd; /usr/lib/omamobile-vendor/omamobile-modem-cp state;
  dmesg | grep -c ufshcd_err_handler'
#   pass: "SIM: ready (...)"; "network: home LTE ..." (or roaming); "data bearer: up"; active; ONLINE; UFS count = U0
#   record: the RAT, the PDP type, IMS registered or the step it failed at, the time from start to "ready".
#     Not the PLMN, the carrier or any number.
#   stop: the unit fails before "ready"; the journal names the step ("No ready USIM within 120 s", "Modem
#     registration deadline exceeded": coverage, activation or the APN; "data call did not become active" with
#     its status (Android DataFailCause numbers: 36 is REGULAR_DEACTIVATION, not a refused APN, which is 27
#     or 33); a CP crash). Record step and code, reboot before another try (SIM-5).
#   rollback: omamobile-sit radio off (deregisters; the radio may not come back until a reboot), then
#     systemctl stop omamobile-sitd; or the reboot

# SIM-8 data (risk: low-medium: mobile data use; Wi-Fi keeps the default route, USB its own subnet)
tools/phone-ssh 'systemd-run --unit=x-data-deadman --on-active=600 systemctl stop omamobile-sit-data'
tools/phone-ssh 'omamobile-sit data on; sleep 5; systemctl is-active omamobile-sit-data; ip -br addr show rmnet0 | wc -l;
  ip route show default | grep -c "dev rmnet0 .*metric 700"; ping -c3 -I rmnet0 9.9.9.9 | tail -2;
  curl -sS --interface rmnet0 -o /dev/null -w "%{http_code}\n" https://example.org/'
#   pass: active; 1 (rmnet0 UP with its address: don't paste it); 1; "3 received"; 200
#   stop: "An active IPv4 internet bearer is required" (PDP type 2, a known gap: record it, go to SIM-9);
#     no replies with the bearer up (record "bearer carries nothing"); a UFS pass
#   rollback: omamobile-sit data off; systemctl stop x-data-deadman.timer

# SIM-9 SMS (risk: low; sending costs what the plan charges). Needs "SMS: yes" from SIM-7.
#   receive: the human texts the palmtop from another phone
tools/phone-ssh 'omamobile-sit sms list --json | python3 -c "import json,sys; print(len(json.load(sys.stdin)))"'
#   pass: the journal says "SMS stored and acknowledged"; the count is 1 (read the text on the palmtop only)
#   send, on the human's go, to a number of theirs (international form):
tools/phone-ssh 'omamobile-sit sms send <NUMBER> "omamobile test"'
#   pass: "sent", and it arrives. "unknown": don't resend blindly, ask the recipient. "failed": record the code.
#   IMS not registered: receiving may still work over the network's SMS path; sending is refused by design.

# SIM-10 calls: NOT in this test. No audio route exists on the 9a (table above). A signalling-only call
#   (ring, answer, hang up, silence both ways, as cheetah's S10) is its own later step, after this runbook passes.
#   Nobody calls the palmtop's number during the test: an incoming call that sitd can't release makes it
#   turn the radio off and exit for an attended reboot (since #364; before it, its safety stop targeted
#   omamobile-modem.service, masked on the 9a). If the journal says "Call release not confirmed" or
#   "attended reboot required": don't
#   stop anything by hand; "omamobile-sit radio off", record the journal lines (states and codes), and end
#   the session with SIM-11's attended reboot.

# SIM-11 end: radio off, the attended reboot, then the checksums (asks the human; one UFS pass; risk: low-medium)
tools/phone-ssh 'omamobile-sit radio off; systemctl stop omamobile-sit-data omamobile-sitd'     # the RIL, not the modem
tools/phone-ssh 'dmesg | grep -c ufshcd_err_handler; sync'
#   record the UFS count; the modem unit is NOT stopped by hand (the rule above): its stop runs at shutdown
tools/phone-ssh 'systemctl reboot'
#   the human stays at the palmtop (M6 isn't passed): the shutdown runs the unit's stop, which powers the CP off
#   (one UFS pass, M2.5), then the kernel restarts. The plain reboot call has hung on the 9a before (NOTES: reboot-to);
#   if the screen stays on past 90 s, RebootWatchdogSec resets the palmtop a minute into the hung shutdown; if
#   nothing after 3 minutes, Power + Volume Up 15-30 s. Either counts as the day's one spare cycle.
#   after the boot, before anything starts the modem (units disabled, the start script is by hand):
#   M0.1 once more (read-only): the six partitions unchanged against SIM-3. stop: any diff: all modem work stops
tools/phone-ssh 'test -d /sys/module/cpif && echo cpif-loaded || echo cpif-not-loaded; dmesg | grep -c ufshcd_err_handler'
#   pass: cpif-not-loaded; the SIM can stay in the tray
```

#### SIM test results (2026-11-02, `7.3.0-rc6-omamobile-tegu-s2mpg15-m1-g991042e2eff3-dirty`)

The prepaid nano-SIM arrived a day early and the test ran the same
afternoon, six CP starts over six boots, all attended on the charger, with
`omamobile-modem` 0.1.10 (installed with `pacman -U -dd`: the package
depends on `omamobile-device-cheetah`, which conflicts with
`omamobile-device-tegu`; the `omamobile-modem-policy` virtual planned in
raven's plan is the fix) and the carrier's published APN, IPv4v6, no
authentication, `ims = yes`, `nr = off`. No identifiers here: the carrier
is a US MVNO on a large LTE network.

- **SIM-0 to SIM-4 passed.** The NV partitions matched the 2026-10-28
  backup and read `ro=1`, unmounted, before and after every boot.
- **SIM-5 passed six times:** CP ONLINE in about 9 s, UFS error handler 0.
- **SIM-6:** the first probe timed out on GET_SIM_STATUS and the CP
  answered it 9.4 s later, so the probe's first request now waits 20 s
  (0.3.6). Then: card state 1, applications (2, 5) and (5, 5) (a USIM and an
  ISIM, both ready), radio state 10, SMSC present.
- **SIM-7 failed five times the same way, then passed.** Each time: PS
  registration state 1, reject 0, RAT 14 (LTE, at home) within a few
  seconds; `SET_INITIAL_ATTACH_APN` and `SET_DATA_PROFILE` error 0; NR mode
  set to 0; then `SETUP_DATA_CALL` answered within 150 ms with status 36
  (Android's REGULAR_DEACTIVATION, not "APN refused"), CID 1, active 0,
  and `GET_DATA_CALL_LIST` empty before and after. Three changes were
  tried one at a time, each on its own boot:
  1. 0.3.5: no PDU session ID on cellular bearers (stock sends 0; sitd
     reserved one). Still 36.
  2. 0.3.7: the APN-type bitmap at 0xf1 of the setup request (stock sends
     the APN's types; sitd sent 0, taken for an MTU). Still 36.
  3. 0.3.8: the recording build (0.3.6) had shown that about a second
     after every refusal the modem sent three IND_REG_FAILED, two
     IND_NTW_STATE_CHANGED and an empty data-call list. With 0.3.8 the
     same indications arrived after the data permission
     (SET_MOBILE_DATA_STATE, SET_PS_SERVICE) and before the setup; the
     three IND_REG_FAILED read domain CS+PS, PS, PS, each with LTE cause
     10 (implicitly detached) and additional cause 0 (decoded with the
     stock library's layout). Whether the permission writes trigger the
     detach isn't proven; the setup succeeds once it is over. The RIL now waits until the modem has
     been quiet for 3 s after the permission (at most 20 s), reads the
     registration again, and then sends the setup. On its first run the
     six indications came and went in the wait, the registration read 1,
     0, 14 again, and the setup answered status 0, CID 1, active 1, PDP
     type 3 (IPv4v6). The IMS bearer followed (status 0, CID 2, PDP type
     2), AIMS registration came back "LTE, IMS voice and SMS registered",
     and the RIL reported "Calls and SMS service ready".
  The first two changes stay in: they match stock's requests, and the
  9a's stock libraries (verified against the owner's `vendor_a.img`) write
  both fields that way.
- **SIM-8 passed:** `omamobile-sit data on` brought `rmnet0` up with an
  address and the default route at metric 700; three pings over it to
  9.9.9.9 answered (78 ms average); an HTTPS GET over it returned 200.
- **SIM-9 passed:** the carrier's welcome text had already arrived during
  SIM-7 ("SMS stored and acknowledged"), the owner's text from another
  phone arrived within seconds, and a text sent from the palmtop
  (`omamobile-sit sms send`) reached the owner's phone. A text sent to
  the palmtop's own number was accepted ("sent") and never came back,
  which is common on this network.
- **SIM-10:** no call on 11-02; the 9a had no audio route. See "Calls"
  below.
- **SIM-11 passed:** radio off, the RIL stopped, an attended reboot
  (the unit's stop powered the CP off during shutdown), then M0.1: the
  six partitions unchanged, `cpif` not loaded, UFS error handler 0.

#### Calls (2026-11-03)

With `omamobile-modem-sit` 0.3.11 (speakerphone audio for the 9a's AoC
card, omarchy-mobile #367, on #364 and #356) and `[audio] card = auto`:

- **On the daily kernel:** an outgoing call to the owner's phone, answered;
  the far end's voice came out of the palmtop's speaker, and the palmtop's
  microphone carried it back (heard at the far end as an echo: there is no
  echo cancellation yet). A second outgoing call and an incoming call
  (`omamobile-sit answer` while it rang) behaved the same. sitd logged
  "AoC tegu speakerphone prepared at conservative TAS gain" at each start
  and "AoC call routes restored" after each hang-up; UFS error handler 0.
- **On in-tree drivers end to end** (`7.3.0-rc6-omamobile-push1-g253ddb231a89`:
  `omamobile` plus the open kernel PRs: the modem link #187 with its PCIe
  stack, GNSS #185, and #162's AoC, GSA and Trusty from the device tree):
  the AoC up with 93 services and the `google,tegu-aoc-snd-card` card,
  CPIF and the in-tree host booted the CP to ONLINE, and then an outgoing
  and an incoming call with audio both ways, mobile data over `rmnet0`
  (pings, HTTPS 200) and a text that arrived. The TAS gains read back at
  -20 dB during the calls, the mixer routes matched their saved state
  after, the AoC kept 93 services with nothing in its log, the same boot
  throughout, no oops or WARN, no UFS errors.

Left for calls: echo cancellation on speakerphone, an earpiece mode, the
Phone app (through `omamobile-mmd`), and starting the modem at boot.

The run kept the full refused record (292 bytes: status 36, CID 1, the
IPC extension version at 132, an unidentified extension byte at 133, the
suggested retry time at 235-242 as an s64) and the raw indications of the passing run in
`logs/tegu-sim-20261102/private/` (off the repository). The open
question is what triggers the implicit detach. Stock's handlers send the
two permission requests separately (SET_PS_SERVICE's success path then
sleeps 500 ms) and its setup path doesn't send them; the libraries don't
show when Android's callers do. Sending them earlier, before the last
registration check, is a reasonable next try, with the wait kept.

**Unqualified after a passing run:** suspend with the modem on (the
inhibitor stays; M6, two reboots with the CP up: this runbook's attended
reboots count toward it but don't pass it; a power-off from Linux with the
CP up; the modem at boot, which makes every boot power it); calls (no audio route; signalling-only first);
the bridge and the apps (T2, `omamobile-mmd`); hours-long sessions (the
link-cycling hangs of 2026-10-29 until `cpif-keep-link` or the watcher is
in). **Record** here, one block per run: the date, `uname -r`, the package
versions; per step pass/fail, the failing step's journal line (states and
codes only), the SIM application list (types and states), the RAT, the
bearer's PDP type, IMS registered or the step it failed at, the time from
`systemctl start omamobile-sitd` to "ready", the UFS handler count at
each step, CP crashes. Not the carrier, the APN, the PLMN or any number.

## Top risks

1. **The first channel 0 accesses.** A new PHY sequence (two lanes,
   external PLL) on a block Linux has never touched, and the AGENTS rule
   that an ELBI/DBI access with the PHY isolated hangs the SoC. Mitigation:
   isolation round trip alone first (M2.2), controller reads only between
   release and re-isolation, the DBI guard from cheetah in the driver from
   the start, watchdog.
2. **GPA5 interrupt ownership.** CPIF needs gpa5-1/2 and gnssif gpa5-4 as
   interrupts on a bank whose EINT setup masks every pin (FAR-ALIVE-PLAN),
   shared with Wi-Fi, Bluetooth and the speaker amplifier. A wrong move
   loses those wakes or storms. Settle it in FAR-ALIVE-PLAN before M3.
3. **DMA and the HSI1 translation units, and UFS.** Stock runs the modem
   behind `sysmmu_hsi1` with CPIF's PCIe IOMMU; we rely on the SysMMU and
   S2MPU passing DMA untranslated (true for HSI2 Wi-Fi here and for gs201's
   modem). If not, the first boot fails at the ROM's DMA (M5) and the CPIF
   IOMMU becomes a port stage. Cheetah also lost one UFS handler pass per
   modem power-off; the UFS check runs after every step here.

## Open questions

1. Does the CP stay off from the bootloader on tegu (M0.3)?
2. Do the CMU_HSI1 PCIe gates read as on with `clk_ignore_unused` (M0.4),
   and does channel 0 train with no clock driver, as gs201 and stock
   (`pcie-clk-num = 0`)?
3. gnssd's NMEA output and its use of `umts_ipc0` (G0).
4. Does the S5910's off sequence matter for the UFS disturbance seen on
   cheetah at modem power-off? Only relevant once a power-off is tested.

## What needs the human

Nothing before the SIM: every step above is offline, read-only, or a
kernel/module/daemon action on the palmtop with its own rollback. With
the SIM: the tray (SIM-4), the APN typed over ssh (SIM-2), the texts and
the go for sending one (SIM-9), and the reboot at the end (SIM-11). The only
physical action is a forced restart if a step hangs and the watchdog
doesn't bring the palmtop back. The per-phone `cdt_hwid` comes from the
private getprop capture already on disk.
